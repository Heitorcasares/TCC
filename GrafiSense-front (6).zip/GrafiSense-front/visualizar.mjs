// Abre a versão pronta usando apenas o Node.js, sem npm install.
// Disponível somente neste computador; serve apenas os arquivos de dist/.
import { createServer } from "node:http";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join, extname } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("./dist/", import.meta.url));
const port = Number(process.argv[2] ?? 5173);
if (!Number.isInteger(port) || port < 1024 || port > 65535) {
  console.error("Use uma porta entre 1024 e 65535. Exemplo: node visualizar.mjs 5174");
  process.exit(1);
}
if (!existsSync(join(root, "index.html"))) {
  console.error("A pasta dist não foi encontrada. Extraia o ZIP completo ou execute npm run build.");
  process.exit(1);
}

const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".woff2": "font/woff2",
};
const files = new Map();
function loadFiles(directory, prefix = "") {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const local = join(directory, entry.name);
    const route = `${prefix}/${entry.name}`;
    if (entry.isDirectory()) loadFiles(local, route);
    else if (entry.isFile()) files.set(route, {
      body: readFileSync(local),
      type: mime[extname(entry.name)] ?? "application/octet-stream",
    });
  }
}
loadFiles(root);
files.set("/", files.get("/index.html"));

const server = createServer((request, response) => {
  if (!["GET", "HEAD"].includes(request.method)) {
    response.writeHead(405, { Allow: "GET, HEAD" });
    response.end();
    return;
  }
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
  } catch {
    response.writeHead(400);
    response.end();
    return;
  }
  const file = files.get(pathname);
  if (!file) {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end(request.method === "HEAD" ? undefined : "Arquivo não encontrado.");
    return;
  }
  response.writeHead(200, {
    "Content-Type": file.type,
    "Content-Length": file.body.length,
    "Cache-Control": "no-cache",
    "X-Content-Type-Options": "nosniff",
  });
  response.end(request.method === "HEAD" ? undefined : file.body);
});

server.on("error", error => {
  console.error(error.code === "EADDRINUSE"
    ? `A porta ${port} está ocupada. Tente outra: node visualizar.mjs ${port === 65535 ? 5173 : port + 1}`
    : `Não foi possível iniciar a prévia: ${error.message}`);
  process.exitCode = 1;
});
server.listen(port, "127.0.0.1", () => {
  console.log(`GrafiSense: abra http://127.0.0.1:${port} no navegador.`);
  console.log("Mantenha este terminal aberto. Para encerrar, pressione Ctrl+C.");
});
process.on("SIGINT", () => server.close());
