"use client";

import { type FormEvent, type ReactNode, useRef, useState } from "react";
import { Activity, ArrowLeft, ArrowRight, BarChart3, CalendarDays, Check, CheckCircle2, ChevronRight, ClipboardCheck, Clock3, Hand, History, Home, Info, Mail, PenLine, Phone, Plus, Search, ShieldCheck, TrendingUp, UserRound, UsersRound, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from "@/components/ui/empty";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Toaster } from "@/components/ui/sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MediaInput } from "./media-input";
import { type Draft, type Patient, type PatientForm, type Professional, emptyPatientForm, emptyProfessional, initials, maskCpf, maskPhone, normalize, validatePerson } from "@/lib/grafisense";

type View = "inicio" | "pacientes" | "avaliacao" | "resultados" | "historico";
const navItems: { id: View; label: string; icon: typeof Home }[] = [
  { id: "inicio", label: "Visão geral", icon: Home },
  { id: "pacientes", label: "Pacientes", icon: UsersRound },
  { id: "avaliacao", label: "Nova avaliação", icon: ClipboardCheck },
  { id: "resultados", label: "Resultados", icon: BarChart3 },
  { id: "historico", label: "Histórico", icon: History },
];
const viewCopy: Record<View, { title: string; description: string }> = {
  inicio: { title: "Seu olhar. Cada trajetória.", description: "Um olhar para cada paciente. Um lugar para acompanhar cada etapa." },
  pacientes: { title: "Pessoas que você acompanha.", description: "Encontre um paciente para iniciar uma avaliação ou consultar o histórico." },
  avaliacao: { title: "Um novo olhar sobre a escrita.", description: "Grave a mão pela câmera e envie a fotografia da escrita do paciente." },
  resultados: { title: "Os detalhes, lado a lado.", description: "Indicadores da mão e da escrita para apoiar o seu acompanhamento." },
  historico: { title: "Cada etapa faz parte.", description: "Acompanhe as avaliações de cada paciente ao longo do tempo." },
};

function Brand() {
  return <div className="brand"><span className="brand-symbol" aria-hidden="true"><span>g</span><i /></span><span><strong>Grafi<span>Sense</span></strong><small>Cuidado em cada traço</small></span></div>;
}

function Signature() {
  return <svg className="signature-mark" viewBox="0 0 680 300" fill="none" aria-hidden="true" focusable="false"><path d="M-20 208C52 175 76 67 120 78c47 12-61 193-78 143C22 164 230 105 213 48c-18-62-153 239-51 202 48-18 92-121 76-111-42 26-56 127-9 99 73-44 119-195 86-169-31 24-63 173-18 155 55-22 49-94 66-83 23 16-29 97 5 77 44-25 56-78 68-64 9 11-21 46 0 49 25 5 54-56 63-47 14 16-10 59 15 44 47-30 126-79 181-44" /><path d="M209 269c104-25 278-46 392-31" /></svg>;
}

function Notice({ children, attention = false }: { children: ReactNode; attention?: boolean }) {
  return <div className={"notice " + (attention ? "attention" : "")}><Info aria-hidden="true" /><p>{children}</p></div>;
}

function Blank({ icon: Icon, title, description, children, compact = false }: { icon: typeof Home; title: string; description: string; children?: ReactNode; compact?: boolean }) {
  return <Empty className={"blank " + (compact ? "compact" : "")}><EmptyHeader><EmptyMedia className="blank-icon"><Icon aria-hidden="true" /></EmptyMedia><EmptyTitle className="blank-title">{title}</EmptyTitle><EmptyDescription className="blank-description">{description}</EmptyDescription></EmptyHeader>{children}</Empty>;
}

function PersonFields<T extends PatientForm & { cpf?: string }>({ value, onChange, professional = false, errors, prefix }: { value: T; onChange: (person: T) => void; professional?: boolean; errors: Record<string, string>; prefix: string }) {
  const fields: { key: keyof Professional; label: string; placeholder: string; type?: string }[] = [
    { key: "name", label: "Nome completo", placeholder: professional ? "Seu nome completo" : "Nome completo do paciente" },
    ...(professional ? [{ key: "cpf" as const, label: "CPF", placeholder: "000.000.000-00" }] : []),
    { key: "phone", label: professional ? "Telefone" : "Telefone do responsável", placeholder: "(11) 90000-0000", type: "tel" },
    { key: "email", label: professional ? "E-mail" : "E-mail do paciente", placeholder: "nome@exemplo.com", type: "email" },
  ];
  return <div className="form-grid">{fields.map(field => <div className={"form-field " + (!professional || ["name", "email"].includes(field.key) ? "full" : "")} key={field.key}>
    <Label htmlFor={prefix + field.key}>{field.label}</Label>
    <Input id={prefix + field.key} type={field.type || "text"} inputMode={field.key === "cpf" ? "numeric" : field.key === "phone" ? "tel" : field.key === "email" ? "email" : "text"} autoComplete="off" maxLength={field.key === "name" ? 120 : field.key === "email" ? 254 : field.key === "cpf" ? 14 : 15} value={value[field.key] ?? ""} placeholder={field.placeholder} aria-invalid={!!errors[field.key]} aria-describedby={errors[field.key] ? prefix + field.key + "-error" : undefined} onChange={event => onChange({ ...value, [field.key]: field.key === "cpf" ? maskCpf(event.target.value) : field.key === "phone" ? maskPhone(event.target.value) : event.target.value })} />
    {errors[field.key] && <p id={prefix + field.key + "-error"} className="field-error">{errors[field.key]}</p>}
  </div>)}</div>;
}

function ProfessionalEntry({ initial, onContinue, onExplore }: { initial: Professional; onContinue: (value: Professional) => void; onExplore: () => void }) {
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validatePerson(form);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("pro-" + Object.keys(nextErrors)[0])?.focus(); return; }
    onContinue({ ...form, name: form.name.trim(), email: form.email.trim().toLowerCase() });
  }
  return <div className="entry-layout">
    <header className="entry-header"><Brand /><Button variant="ghost" className="text-action" onClick={onExplore}>Explorar as telas <ArrowRight /></Button></header>
    <main>
      <section className="entry-hero">
        <Signature />
        <span className="eyebrow">TERAPIA OCUPACIONAL · ACOMPANHAMENTO DA ESCRITA</span>
        <h1>Todo traço tem<br /><em>uma história.</em></h1>
        <p>Um espaço para observar com atenção.<br />E acompanhar cada paciente no seu próprio ritmo.</p>
        <div className="hero-caption"><span>O olhar é seu.</span><span>Os registros ficam juntos.</span></div>
      </section>
      <section className="entry-registration" aria-labelledby="entry-form-title">
        <div className="entry-form-heading"><div><span className="eyebrow">01 / ÁREA DO PROFISSIONAL</span><h2 id="entry-form-title">{initial.name ? "Seu cadastro." : "Seu cuidado começa aqui."}</h2></div><span className="entry-form-context"><UserRound /> Cadastro profissional</span></div>
        <form onSubmit={submit} noValidate>
          <PersonFields value={form} onChange={setForm} errors={errors} prefix="pro-" professional />
          <div className="entry-form-bottom"><div className="demo-note"><ShieldCheck /><p>Use dados fictícios nesta demonstração.<br />As informações são descartadas ao atualizar a página.</p></div><Button type="submit" className="action">{initial.name ? "Salvar e voltar ao painel" : "Cadastrar e acessar"}<ArrowRight /></Button></div>
        </form>
      </section>
      <section className="entry-chapters" aria-label="Etapas do acompanhamento">
        {[{ n: "01", title: "Uma pessoa.", text: "Reúna os dados de cada paciente e encontre tudo em um só lugar.", icon: UsersRound }, { n: "02", title: "Muitos detalhes.", text: "Registre os movimentos da mão e a fotografia da escrita.", icon: Hand }, { n: "03", title: "Novas perspectivas.", text: "Consulte os resultados disponíveis e o histórico de avaliações.", icon: TrendingUp }].map(item => <article key={item.n}><div className="chapter-top"><span>{item.n}</span><item.icon aria-hidden="true" /></div><h2>{item.title}</h2><p>{item.text}</p></article>)}
      </section>
    </main>
    <footer className="entry-foot"><span>GrafiSense / Cuidado em cada traço</span><span>Uma ferramenta de apoio à avaliação profissional.</span></footer>
    <Toaster theme="light" position="top-right" closeButton />
  </div>;
}

function AppHeader({ view, navigate, professional, editProfessional, count }: { view: View; navigate: (view: View) => void; professional: Professional; editProfessional: () => void; count: number }) {
  return <header className="app-header"><div className="app-header-inner">
    <Brand />
    <nav className="primary-nav" aria-label="Navegação principal">{navItems.map(item => <button key={item.id} type="button" aria-current={view === item.id ? "page" : undefined} onClick={() => navigate(item.id)}><item.icon aria-hidden="true" /><span>{item.label}</span>{item.id === "pacientes" && count > 0 && <span className="nav-count">{count}</span>}</button>)}</nav>
    <button className="profile-button" onClick={editProfessional} aria-label={professional.name ? "Editar cadastro de " + professional.name : "Completar cadastro profissional"}><span className="avatar">{professional.name ? initials(professional.name) : <UserRound />}</span><span><strong>{professional.name || "Meu espaço"}</strong><small>{professional.name ? "Meu cadastro" : "Completar cadastro"}</small></span><ChevronRight aria-hidden="true" /></button>
  </div></header>;
}

function Metric({ label, value, note, icon: Icon, success = false }: { label: string; value: string; note: string; icon: typeof Home; success?: boolean }) {
  return <div className="metric"><div><p>{label}</p><strong>{value}</strong><small>{note}</small></div><span className={"metric-icon " + (success ? "green" : "")}><Icon /></span></div>;
}

function Dashboard({ patients, professional, navigate, addPatient, selectPatient }: { patients: Patient[]; professional: Professional; navigate: (view: View) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  return <div className="dashboard">
    <section className="dashboard-cover">
      <div className="cover-story"><Signature /><span className="eyebrow">{professional.name ? "BOAS-VINDAS, " + professional.name.split(" ")[0].toLocaleUpperCase("pt-BR") : "UM OLHAR ATENTO FAZ A DIFERENÇA"}</span><h2>A escrita muda.<br /><em>O cuidado acompanha.</em></h2><p>Registre os pequenos detalhes de hoje.<br />Construa o acompanhamento de amanhã.</p><Button variant="outline" className="action cover-action" onClick={() => navigate(patients.length ? "avaliacao" : "pacientes")}>Iniciar uma avaliação <ArrowRight /></Button><span className="cover-caption">MÃO · ESCRITA · EVOLUÇÃO</span></div>
      <div className="cover-next"><span className="eyebrow">O PRÓXIMO ENCONTRO</span><span className="cover-plus" aria-hidden="true"><Plus /></span><h3>{patients.length ? "Mais uma história para acompanhar." : "Comece por alguém."}</h3><p>{patients.length ? "Adicione um paciente ao seu espaço de acompanhamento." : "Cadastre seu primeiro paciente. Cada trajetória merece o seu próprio registro."}</p><Button variant="ghost" className="text-action" onClick={addPatient}>Cadastrar paciente <ArrowRight /></Button></div>
    </section>
    <section className="overview-section" aria-labelledby="overview-title"><div className="section-kicker"><span>01 / VISÃO DO ACOMPANHAMENTO</span><h2 id="overview-title">Seu trabalho, em perspectiva.</h2></div><div className="metrics-grid">
      <Metric label="Pacientes cadastrados" value={String(patients.length).padStart(2, "0")} note="Nesta sessão" icon={UsersRound} />
      <Metric label="Avaliações concluídas" value="00" note="Aguardando a primeira avaliação" icon={ClipboardCheck} />
      <Metric label="Em evolução" value="00" note="Aguardando resultados" icon={TrendingUp} success />
      <Metric label="Média geral" value="—" note="Sem dados para calcular" icon={Activity} />
    </div></section>
    <section className="recent-section" aria-labelledby="recent-title"><div className="section-heading"><div><span className="eyebrow">02 / PESSOAS, ANTES DOS NÚMEROS</span><h2 id="recent-title">Pacientes recentes.</h2></div><Button variant="ghost" className="text-action" onClick={() => navigate("pacientes")}>Ver todos os pacientes <ArrowRight /></Button></div>
      {patients.length ? <div className="recent-patients">{patients.slice(-4).reverse().map((patient, index) => <button key={patient.id} onClick={() => selectPatient(patient.id, "avaliacao")}><span className="row-number">{String(index + 1).padStart(2, "0")}</span><span className="avatar">{initials(patient.name)}</span><span className="recent-person"><strong>{patient.name}</strong><small>{patient.email}</small></span><span className="status"><Clock3 /> Sem avaliação</span><span className="recent-patient-action">Avaliar <ArrowRight /></span></button>)}</div> : <div className="first-patient"><span className="empty-portrait" aria-hidden="true"><UsersRound /></span><div><h3>Um espaço esperando a primeira história.</h3><p>Cadastre um paciente para começar a organizar suas avaliações.</p></div><Button variant="outline" className="action secondary" onClick={addPatient}><Plus /> Primeiro paciente</Button></div>}
    </section>
    <nav className="workflow-links" aria-label="Etapas do acompanhamento">{[{ n: "01", label: "Organizar pacientes", target: "pacientes" as View }, { n: "02", label: "Observar a escrita", target: "avaliacao" as View }, { n: "03", label: "Acompanhar a evolução", target: "historico" as View }].map(item => <button key={item.n} onClick={() => navigate(item.target)}><span>{item.n}</span><strong>{item.label}</strong><ArrowRight /></button>)}</nav>
  </div>;
}

function PatientsView({ patients, selectedId, search, setSearch, addPatient, selectPatient }: { patients: Patient[]; selectedId: string; search: string; setSearch: (search: string) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  const query = normalize(search.trim());
  const filtered = patients.filter(patient => normalize(patient.name).includes(query) || normalize(patient.email).includes(query));
  return <section className="patients-view" aria-label="Lista de pacientes">
    <div className="patient-toolbar"><div className="patient-total"><strong>{String(patients.length).padStart(2, "0")}</strong><span>{patients.length === 1 ? "paciente cadastrado" : "pacientes cadastrados"}</span></div><div className="search-field"><Search /><Input aria-label="Buscar paciente por nome ou e-mail" placeholder="Buscar nome ou e-mail" value={search} onChange={event => setSearch(event.target.value)} />{search && <button onClick={() => setSearch("")} aria-label="Limpar busca"><X /></button>}</div></div>
    {!filtered.length ? <div className="panel directory-empty"><Blank icon={patients.length ? Search : UsersRound} title={patients.length ? "Nenhum paciente encontrado." : "A primeira história começa aqui."} description={patients.length ? "Tente outro nome ou e-mail para encontrar o paciente." : "Adicione os dados do paciente. Os registros e as avaliações ganham um lugar para ficar juntos."}>{patients.length ? <Button variant="outline" className="action secondary" onClick={() => setSearch("")}>Limpar busca</Button> : <Button className="action" onClick={addPatient}><Plus /> Cadastrar primeiro paciente</Button>}</Blank></div> : <div className="patient-directory">{filtered.map((patient, index) => <article key={patient.id} className={"directory-row " + (selectedId === patient.id ? "selected" : "")}>
      <span className="row-number">{String(index + 1).padStart(2, "0")}</span>
      <div className="directory-person"><span className="avatar">{initials(patient.name)}</span><div><h2>{patient.name}</h2><span className="status"><Clock3 /> Sem avaliação</span></div></div>
      <dl className="patient-contact"><div><dt><Mail /><span className="sr-only">E-mail</span></dt><dd title={patient.email}>{patient.email}</dd></div><div><dt><Phone /><span className="sr-only">Telefone do responsável</span></dt><dd>{patient.phone}</dd></div></dl>
      <div className="directory-actions"><Button variant="ghost" className="text-action" onClick={() => selectPatient(patient.id, "historico")}><History /> Histórico</Button><Button className="action" onClick={() => selectPatient(patient.id, "avaliacao")}>Avaliar <ArrowRight /></Button></div>
    </article>)}</div>}
  </section>;
}

function PatientPicker({ patients, selectedId, onSelect, addPatient }: { patients: Patient[]; selectedId: string; onSelect: (id: string) => void; addPatient: () => void }) {
  return <div className="patient-picker"><span className="section-icon"><UserRound /></span><div className="picker-field"><Label htmlFor="active-patient">Paciente selecionado</Label><Select value={selectedId} onValueChange={onSelect} disabled={!patients.length}><SelectTrigger id="active-patient"><SelectValue placeholder="Cadastre um paciente para começar" /></SelectTrigger><SelectContent>{patients.map(patient => <SelectItem key={patient.id} value={patient.id}>{patient.name}</SelectItem>)}</SelectContent></Select></div><Button variant="ghost" className="text-action" onClick={addPatient}><Plus /> Novo paciente</Button></div>;
}

function AssessmentView({ selected, draft, updateDraft, showResults, addPatient }: { selected?: Patient; draft: Draft; updateDraft: (draft: Draft) => void; showResults: () => void; addPatient: () => void }) {
  const readyCount = Number(!!draft.video) + Number(!!draft.image);
  return <div className="view-stack">{!selected && <Notice>Cadastre ou selecione um paciente para habilitar a câmera e o envio da fotografia. <button className="inline-link" onClick={addPatient}>Cadastrar paciente</button></Notice>}
    <div className="assessment-progress"><span className={selected ? "complete" : ""}>{selected ? <CheckCircle2 /> : <span className="step-dot">1</span>} Paciente</span><i /><span className={selected ? "current" : ""}><span className="step-dot">2</span> Vídeo e fotografia</span><i /><span><span className="step-dot">3</span> Resultados</span></div>
    <div className="assessment-columns"><section className="panel collection-panel"><div className="collection-heading"><span className="section-icon"><Hand /></span><div><span className="eyebrow">ETAPA 01 · VÍDEO</span><h2>Mão e movimentos</h2></div>{draft.video && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Registre a posição e os movimentos da mão durante a atividade de escrita.</p><MediaInput kind="video" file={draft.video} disabled={!selected} onChange={file => updateDraft({ ...draft, video: file })} /><div className="collection-tip"><Check /> Mão, lápis e papel visíveis; câmera estável.</div></section>
    <section className="panel collection-panel writing-panel"><div className="collection-heading"><span className="section-icon"><PenLine /></span><div><span className="eyebrow">ETAPA 02 · FOTOGRAFIA</span><h2>Espaçamento e legibilidade</h2></div>{draft.image && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Fotografe a folha para observar o espaçamento e a legibilidade da escrita.</p><MediaInput kind="image" file={draft.image} disabled={!selected} onChange={file => updateDraft({ ...draft, image: file })} /><div className="collection-tip"><Check /> Texto nítido, folha enquadrada e sem sombras.</div></section></div>
    <div className="assessment-bottom"><div><span className={"ready-pill " + (readyCount === 2 ? "ready" : "")}>{readyCount === 2 ? <CheckCircle2 /> : <ClipboardCheck />}{readyCount}/2 etapas concluídas</span><p>Prévia local. O processamento será integrado em uma próxima etapa.</p></div><Button className="action" disabled={readyCount !== 2 || !selected} onClick={showResults}>Conferir avaliação <ArrowRight /></Button></div>
  </div>;
}

function ResultsView({ selected, draft, navigate }: { selected?: Patient; draft: Draft; navigate: (view: View) => void }) {
  const ready = !!draft.video && !!draft.image;
  return <div className="view-stack"><section className="results-metrics" aria-label="Indicadores de resultados" tabIndex={0}><Metric label="Mão e movimentos" value="—" note="Média indisponível" icon={Hand} /><Metric label="Espaçamento e legibilidade" value="—" note="Média indisponível" icon={PenLine} /><Metric label="Média geral" value="—" note="Aguardando análise" icon={Activity} /></section>
    <div className="panel"><Blank icon={ready ? ClipboardCheck : BarChart3} title={ready ? "Arquivos prontos para análise" : "Ainda não há resultados"} description={ready ? "O vídeo foi gravado e a fotografia foi selecionada. As médias serão exibidas quando o processamento estiver integrado ao GrafiSense." : selected ? selected.name + " ainda não possui avaliações concluídas." : "Selecione um paciente para acompanhar os resultados das avaliações."}>{ready && <div className="review-files"><span><CheckCircle2 /><strong>{draft.video?.name}</strong></span><span><CheckCircle2 /><strong>{draft.image?.name}</strong></span></div>}<Button variant="outline" className="action secondary" onClick={() => navigate(selected ? "avaliacao" : "pacientes")}>{ready ? <ArrowLeft /> : <Plus />}{ready ? "Voltar à avaliação" : selected ? "Iniciar avaliação" : "Ir para pacientes"}</Button></Blank></div><Notice attention>Os indicadores apoiam a observação do profissional. O GrafiSense não emite diagnóstico ou porcentagem de disgrafia.</Notice>
  </div>;
}

function HistoryView({ selected, navigate }: { selected?: Patient; navigate: (view: View) => void }) {
  const [date, setDate] = useState("");
  return <div className="view-stack"><Tabs defaultValue="evolucao" className="history-tabs"><div className="history-controls"><TabsList className="gs-tabs"><TabsTrigger value="evolucao"><TrendingUp /> Evolução</TabsTrigger><TabsTrigger value="registros"><History /> Avaliações</TabsTrigger></TabsList><div className="date-filter"><Label htmlFor="history-date"><CalendarDays /> Data</Label><Input id="history-date" type="date" value={date} onChange={event => setDate(event.target.value)} />{date && <Button variant="ghost" size="icon" aria-label="Limpar filtro de data" onClick={() => setDate("")}><X /></Button>}</div></div>
    <TabsContent value="evolucao"><div className="panel"><div className="panel-heading"><h2>Evolução ao longo do tempo</h2><span className="pill">0 avaliações</span></div><Blank icon={TrendingUp} title={date ? "Nenhuma avaliação nesta data" : "O histórico começa na primeira avaliação"} description={selected ? selected.name + " ainda não possui resultados para comparação." : "Selecione um paciente para consultar as avaliações e suas médias."}><Button variant="outline" className="action secondary" onClick={() => date ? setDate("") : navigate(selected ? "avaliacao" : "pacientes")}>{date ? "Limpar filtro" : selected ? "Iniciar avaliação" : "Ir para pacientes"}<ArrowRight /></Button></Blank><div className="chart-legend"><span><i />Mão e movimentos</span><span><i className="green" />Espaçamento e legibilidade</span></div></div></TabsContent>
    <TabsContent value="registros"><div className="panel"><Table><TableHeader><TableRow><TableHead>Data da avaliação</TableHead><TableHead>Mão e movimentos</TableHead><TableHead>Escrita</TableHead><TableHead>Média geral</TableHead><TableHead>Evolução</TableHead></TableRow></TableHeader><TableBody><TableRow><TableCell colSpan={5}><Blank icon={History} title="Nenhuma avaliação registrada" description={date ? "Não existem registros para a data selecionada." : "As avaliações concluídas aparecerão aqui, organizadas por data."} compact /></TableCell></TableRow></TableBody></Table></div></TabsContent></Tabs></div>;
}

export default function HomePage() {
  const [started, setStarted] = useState(false);
  const [professional, setProfessional] = useState<Professional>(emptyProfessional);
  const [view, setView] = useState<View>("inicio");
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [search, setSearch] = useState("");
  const [dialog, setDialog] = useState(false);
  const [patientForm, setPatientForm] = useState<PatientForm>(emptyPatientForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const heading = useRef<HTMLHeadingElement>(null);
  const selected = patients.find(patient => patient.id === selectedId);
  const draft = drafts[selectedId] || {};
  const navigate = (next: View) => { setView(next); requestAnimationFrame(() => { heading.current?.focus(); window.scrollTo({ top: 0, behavior: "instant" }); }); };
  const addPatient = () => { setPatientForm(emptyPatientForm); setErrors({}); setDialog(true); };
  const selectPatient = (id: string, next: View) => { setSelectedId(id); navigate(next); };
  function submitPatient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const { name, email, phone } = patientForm;
    const nextErrors = validatePerson({ name, email, phone });
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("patient-" + Object.keys(nextErrors)[0])?.focus(); return; }
    const newPatient: Patient = { id: crypto.randomUUID(), name: name.trim(), email: email.trim().toLowerCase(), phone };
    setPatients(current => [...current, newPatient]); setSelectedId(newPatient.id); setDialog(false); toast.success("Paciente adicionado à demonstração.");
  }
  const enterDashboard = () => { setStarted(true); requestAnimationFrame(() => { heading.current?.focus(); window.scrollTo({ top: 0, behavior: "instant" }); }); };
  if (!started) return <ProfessionalEntry initial={professional} onContinue={value => { setProfessional(value); enterDashboard(); toast.success("Cadastro profissional preenchido."); }} onExplore={enterDashboard} />;
  return <div className="app-shell"><a href="#page-heading" className="skip-link">Ir para o conteúdo</a><AppHeader view={view} navigate={navigate} professional={professional} count={patients.length} editProfessional={() => { setStarted(false); window.scrollTo({ top: 0, behavior: "instant" }); }} /><main className="gs-main">
    <div className="workspace-meta"><span>ÁREA PROFISSIONAL <span aria-hidden="true">/</span> {navItems.find(item => item.id === view)?.label}</span><span className="prototype-label"><i /> Protótipo interativo</span></div>
    <div className="workspace"><div className="page-heading"><div><span className="eyebrow">{view === "inicio" ? "GRAFISENSE / VISÃO GERAL" : "GRAFISENSE / " + navItems.find(item => item.id === view)?.label.toLocaleUpperCase("pt-BR")}</span><h1 id="page-heading" ref={heading} tabIndex={-1}>{viewCopy[view].title}</h1><p>{viewCopy[view].description}</p></div>{view === "pacientes" && <Button className="action" onClick={addPatient}><Plus /> Cadastrar paciente</Button>}</div>
      {view === "inicio" && <Dashboard patients={patients} professional={professional} navigate={navigate} addPatient={addPatient} selectPatient={selectPatient} />}
      {view === "pacientes" && <PatientsView patients={patients} selectedId={selectedId} search={search} setSearch={setSearch} addPatient={addPatient} selectPatient={selectPatient} />}
      {["avaliacao", "resultados", "historico"].includes(view) && <PatientPicker patients={patients} selectedId={selectedId} onSelect={setSelectedId} addPatient={addPatient} />}
      {view === "avaliacao" && <AssessmentView selected={selected} draft={draft} updateDraft={value => { if (selectedId) setDrafts(current => ({ ...current, [selectedId]: value })); }} showResults={() => navigate("resultados")} addPatient={addPatient} />}
      {view === "resultados" && <ResultsView selected={selected} draft={draft} navigate={navigate} />}
      {view === "historico" && <HistoryView key={selectedId} selected={selected} navigate={navigate} />}
    </div></main><footer className="app-footer"><span>GrafiSense <span aria-hidden="true">·</span> Apoio ao profissional de TO</span><span><Info /> Demonstração: dados apenas nesta sessão</span></footer>
  <Dialog open={dialog} onOpenChange={setDialog}><DialogContent className="gs-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar cadastro"><X /></Button></DialogClose><DialogHeader><span className="section-icon"><UserRound /></span><DialogTitle>Cadastrar paciente</DialogTitle><DialogDescription>Informe os dados essenciais para iniciar o acompanhamento.</DialogDescription></DialogHeader><form onSubmit={submitPatient} noValidate><PersonFields value={patientForm} onChange={setPatientForm} prefix="patient-" errors={errors} /><div className="demo-note"><ShieldCheck /><p>Use dados fictícios nesta demonstração. Os cadastros não são armazenados ao atualizar a página.</p></div><DialogFooter><Button variant="outline" type="button" className="action secondary" onClick={() => setDialog(false)}>Cancelar</Button><Button type="submit" className="action"><Plus /> Cadastrar paciente</Button></DialogFooter></form></DialogContent></Dialog><Toaster theme="light" position="top-right" closeButton />
  </div>;
}
