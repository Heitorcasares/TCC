# GrafiSense — código do front

Esta é uma cópia portátil do front-end, com o visual atualizado, a paleta original e as mesmas telas e interações. A configuração de desenvolvimento usa Vite. Os pacotes de hospedagem, Next.js e banco de dados que esta cópia local não usa foram retirados para reduzir a instalação.

## Nova identidade visual — outubro de 2026

- Entrada com chamada central, traços vetoriais e cadastro em uma faixa horizontal no computador.
- Navegação no topo, com acesso direto a todas as telas e ao cadastro profissional.
- Títulos serifados, formas mais retas, divisórias finas e composição com mais espaço livre.
- Painel com duas áreas de destaque, indicadores tipográficos e uma lista aberta de pacientes recentes.
- Diretório de pacientes em linhas, com busca, contatos e ações de avaliação e histórico.
- Resultados em uma única linha horizontal: mão e movimentos, espaçamento e legibilidade e média geral. Em telas menores, deslize para o lado ou use as setas do teclado com a área de indicadores selecionada.
- Telas adaptadas ao celular e etapas de vídeo e fotografia identificadas em azul e verde.
- Cores principais preservadas: azul `#4A90E2` e verde `#5CB85C`.

O novo visual não acrescenta dependências. Os traços são vetoriais e a tipografia usa fontes do sistema: não há downloads de imagens ou fontes externas. A prévia incluída em `dist` já contém esta nova identidade, com o menu no topo e o título “Todo traço tem uma história.” na entrada.

## Abrir a prévia pronta, sem instalar dependências

O ZIP já inclui a pasta `dist` compilada. Para visualizar e usar as telas, basta ter Node.js 22.13 ou superior; Node 24 é compatível.

1. Extraia este ZIP em uma nova pasta.
2. Entre na pasta **GrafiSense-front** que contém `visualizar.mjs` e `package.json`.
3. No Ubuntu, clique com o botão direito em uma área vazia dessa pasta e escolha **Abrir no terminal**. O VS Code pode ficar fechado.
4. Execute:

   ```bash
   node visualizar.mjs
   ```

5. Abra **http://127.0.0.1:5173** no navegador. Mantenha o terminal aberto; use **Ctrl+C** para encerrar.

Se uma prévia antiga estiver aberta, encerre-a com **Ctrl+C** antes de iniciar a nova. Execute o comando na pasta extraída deste ZIP e atualize a página do navegador.

Se a porta estiver ocupada, execute `node visualizar.mjs 5174` e abra o endereço mostrado. Esse servidor atende apenas no próprio computador.

Esta é a versão compilada do front. Alterações no código-fonte aparecem nela depois de executar `npm run build` e reiniciar `node visualizar.mjs`. Para editar e ver mudanças automaticamente, use o modo de desenvolvimento abaixo.

## Editar e executar em modo de desenvolvimento

1. Abra um terminal na pasta que contém `package.json` e `package-lock.json`. Você pode instalar as dependências pelo terminal do Ubuntu, com o VS Code fechado.
2. É necessário ter Node.js 22.13 ou superior e npm instalados.
3. Execute `npm ci --maxsockets=3`. A opção limita as conexões simultâneas durante os downloads.
4. Depois execute `npm run dev`.
5. Abra o endereço localhost mostrado no terminal.
6. Para editar, abra essa mesma pasta em **Arquivo > Abrir Pasta** no VS Code.

Para confirmar a pasta antes de instalar, execute `ls package.json package-lock.json`. Os dois arquivos precisam aparecer. Se o editor ou o sistema voltar a travar, o motivo precisa ser investigado com os logs; reduzir dependências não garante resolver todo tipo de travamento.

No Windows, se o PowerShell bloquear o comando npm, selecione o terminal Prompt de Comando no VS Code ou use `npm.cmd ci` e `npm.cmd run dev`.

Para gerar os arquivos de distribuição, execute `npm run build`. Para visualizar essa versão, use `npm run preview`.

## Arquivos principais

- `app/page.tsx`: telas, formulários e navegação.
- `app/globals.css`: cores, tamanhos, espaçamentos e adaptação para celular.
- `app/media-input.tsx`: permissão de câmera, gravação do vídeo e upload da fotografia.
- `lib/grafisense.ts`: tipos, máscaras e validação.
- `main.tsx`: ponto de entrada da cópia local.
- `Prompt-GrafiSense.txt`: instruções consolidadas para recriar o front.

## Estado atual

O profissional informa nome completo, CPF, telefone e e-mail. O paciente informa nome completo, e-mail e telefone do responsável; não há CPF no cadastro do paciente.

O vídeo é gravado pela câmera do site. Apenas a fotografia é enviada por upload. A câmera precisa de permissão do navegador e funciona em localhost ou HTTPS. Abrir o HTML com duplo clique não executa corretamente este projeto; use o servidor indicado acima.

Pacientes, avaliações e indicadores começam vazios. Os dados ficam somente na memória da página e desaparecem ao atualizar. Este projeto é um front-end demonstrativo: não contém banco de dados, análise por aprendizado de máquina ou geração de diagnósticos.

Versão de referência do front: d89a0375d02b797456f30ad80854d66f3a0f7007.
