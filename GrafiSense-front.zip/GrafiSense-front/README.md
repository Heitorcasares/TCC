# GrafiSense — código do front

Esta é uma cópia portátil do front-end atual, com as mesmas telas e interações, preparada para abrir no VS Code. A configuração local usa Vite. A versão publicada usa Vinext; não é necessário acessar a hospedagem para trabalhar nesta cópia.

## Como abrir e executar

1. Extraia o ZIP.
2. No VS Code, clique em Arquivo > Abrir Pasta e selecione a pasta GrafiSense-front.
3. É necessário ter Node.js 22.13 ou superior e npm instalados.
4. Abra Terminal > Novo Terminal e execute `npm ci` para instalar as dependências.
5. Depois execute `npm run dev`.
6. Abra o endereço localhost mostrado no terminal.

No Windows, se o PowerShell bloquear o comando npm, selecione o terminal Prompt de Comando no VS Code ou use `npm.cmd ci` e `npm.cmd run dev`.

Para gerar os arquivos de distribuição, execute `npm run build`. Para visualizar essa versão, use `npm run preview`.

## Arquivos principais

- `app/page.tsx`: telas, formulários e navegação.
- `app/globals.css`: cores, tamanhos, espaçamentos e adaptação para celular.
- `app/media-input.tsx`: permissão de câmera, gravação do vídeo e upload da fotografia.
- `lib/grafisense.ts`: tipos, máscaras e validação.
- `main.tsx`: ponto de entrada da cópia local.
- `Prompt-GrafiSense.txt`: instruções consolidadas para recriar o front.

## Estado atual

O profissional informa nome completo, CPF, telefone e e-mail. O paciente informa nome completo, e-mail e telefone do responsável; não há CPF no cadastro do paciente.

O vídeo é gravado pela câmera do site. Apenas a fotografia é enviada por upload. A câmera precisa de permissão do navegador e funciona em localhost ou HTTPS. Abrir o HTML com duplo clique não executa corretamente este projeto; use o servidor indicado acima.

Pacientes, avaliações e indicadores começam vazios. Os dados ficam somente na memória da página e desaparecem ao atualizar. Este projeto é um front-end demonstrativo: não contém banco de dados, análise por aprendizado de máquina ou geração de diagnósticos.

Versão de referência do front: d89a0375d02b797456f30ad80854d66f3a0f7007.
