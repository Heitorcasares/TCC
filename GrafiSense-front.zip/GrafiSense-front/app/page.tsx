"use client";

import { type CSSProperties, type FormEvent, type ReactNode, useRef, useState } from "react";
import { Activity, ArrowLeft, ArrowRight, BarChart3, CalendarDays, Check, CheckCircle2, ChevronRight, ClipboardCheck, Clock3, Hand, History, Home, Info, PenLine, Plus, Search, ShieldCheck, TrendingUp, UserRound, UsersRound, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from "@/components/ui/empty";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { Toaster } from "@/components/ui/sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MediaInput } from "./media-input";
import { type Draft, type Patient, type PatientForm, type Professional, emptyPatientForm, emptyProfessional, initials, maskCpf, maskPhone, normalize, validatePerson } from "@/lib/grafisense";

type View = "inicio" | "pacientes" | "avaliacao" | "resultados" | "historico";
const navItems: { id: View; label: string; icon: typeof Home }[] = [
  { id: "inicio", label: "Visão geral", icon: Home },
  { id: "pacientes", label: "Pacientes", icon: UsersRound },
  { id: "avaliacao", label: "Nova avaliação", icon: ClipboardCheck },
  { id: "resultados", label: "Resultados", icon: BarChart3 },
  { id: "historico", label: "Histórico", icon: History },
];
const viewCopy: Record<View, { title: string; description: string }> = {
  inicio: { title: "Seu acompanhamento, com clareza.", description: "Um espaço para organizar pacientes e acompanhar a escrita." },
  pacientes: { title: "Seus pacientes", description: "Encontre um paciente para iniciar uma avaliação ou consultar o histórico." },
  avaliacao: { title: "Nova avaliação", description: "Grave a mão pela câmera e envie a fotografia da escrita do paciente." },
  resultados: { title: "Resultados da avaliação", description: "Indicadores da mão e da escrita para apoiar o seu acompanhamento." },
  historico: { title: "Histórico de evolução", description: "Acompanhe as avaliações de cada paciente ao longo do tempo." },
};

function Brand() {
  return <div className="brand"><span className="brand-symbol"><PenLine aria-hidden="true" /></span><span><strong>Grafi<span>Sense</span></strong><small>Acompanhamento da escrita</small></span></div>;
}

function Notice({ children, attention = false }: { children: ReactNode; attention?: boolean }) {
  return <div className={"notice " + (attention ? "attention" : "")}><Info aria-hidden="true" /><p>{children}</p></div>;
}

function Blank({ icon: Icon, title, description, children, compact = false }: { icon: typeof Home; title: string; description: string; children?: ReactNode; compact?: boolean }) {
  return <Empty className={"blank " + (compact ? "compact" : "")}><EmptyHeader><EmptyMedia className="blank-icon"><Icon aria-hidden="true" /></EmptyMedia><EmptyTitle className="blank-title">{title}</EmptyTitle><EmptyDescription className="blank-description">{description}</EmptyDescription></EmptyHeader>{children}</Empty>;
}

function PersonFields<T extends PatientForm & { cpf?: string }>({ value, onChange, professional = false, errors, prefix }: { value: T; onChange: (person: T) => void; professional?: boolean; errors: Record<string, string>; prefix: string }) {
  const fields: { key: keyof Professional; label: string; placeholder: string; type?: string }[] = [
    { key: "name", label: "Nome completo", placeholder: professional ? "Seu nome completo" : "Nome completo do paciente" },
    ...(professional ? [{ key: "cpf" as const, label: "CPF", placeholder: "000.000.000-00" }] : []),
    { key: "phone", label: professional ? "Telefone" : "Telefone do responsável", placeholder: "(11) 90000-0000", type: "tel" },
    { key: "email", label: professional ? "E-mail" : "E-mail do paciente", placeholder: "nome@exemplo.com", type: "email" },
  ];
  return <div className="form-grid">{fields.map(field => <div className={"form-field " + (!professional || ["name", "email"].includes(field.key) ? "full" : "")} key={field.key}>
    <Label htmlFor={prefix + field.key}>{field.label}</Label>
    <Input id={prefix + field.key} type={field.type || "text"} inputMode={field.key === "cpf" ? "numeric" : field.key === "phone" ? "tel" : field.key === "email" ? "email" : "text"} autoComplete="off" maxLength={field.key === "name" ? 120 : field.key === "email" ? 254 : field.key === "cpf" ? 14 : 15} value={value[field.key] ?? ""} placeholder={field.placeholder} aria-invalid={!!errors[field.key]} aria-describedby={errors[field.key] ? prefix + field.key + "-error" : undefined} onChange={event => onChange({ ...value, [field.key]: field.key === "cpf" ? maskCpf(event.target.value) : field.key === "phone" ? maskPhone(event.target.value) : event.target.value })} />
    {errors[field.key] && <p id={prefix + field.key + "-error"} className="field-error">{errors[field.key]}</p>}
  </div>)}</div>;
}

function ProfessionalEntry({ initial, onContinue, onExplore }: { initial: Professional; onContinue: (value: Professional) => void; onExplore: () => void }) {
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const nextErrors = validatePerson(form); setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("pro-" + Object.keys(nextErrors)[0])?.focus(); return; }
    onContinue({ ...form, name: form.name.trim(), email: form.email.trim().toLowerCase() });
  }
  return <main className="entry-layout">
    <section className="entry-story"><Brand /><div className="entry-intro"><span className="eyebrow">ÁREA DO PROFISSIONAL</span><h1>Cada traço conta.<br /><span>Cada etapa também.</span></h1><p>Organize o acompanhamento da escrita dos seus pacientes em um único espaço.</p>
      <ol className="entry-steps">{[{ icon: UsersRound, title: "Organize seus pacientes", text: "Cadastros simples, sempre à mão." }, { icon: Hand, title: "Observe a mão e a escrita", text: "Vídeo e fotografia na mesma avaliação." }, { icon: TrendingUp, title: "Acompanhe a evolução", text: "Resultados reunidos em um histórico." }].map((step, index) => <li key={step.title}><span className="step-icon"><step.icon /></span><div><strong>{step.title}</strong><p>{step.text}</p></div><span className="step-index">0{index + 1}</span></li>)}</ol>
    </div><div className="entry-foot"><span>TERAPIA OCUPACIONAL</span><span>GrafiSense · 2026</span></div></section>
    <section className="entry-form-area"><div className="entry-mobile-brand"><Brand /></div><div className="entry-form"><span className="pill"><UserRound /> Cadastro profissional</span><h2>{initial.name ? "Seu cadastro" : "Boas-vindas ao GrafiSense"}</h2><p className="entry-description">Preencha os dados do profissional responsável para começar.</p>
      <form onSubmit={submit} noValidate><PersonFields value={form} onChange={setForm} errors={errors} prefix="pro-" professional /><div className="demo-note"><ShieldCheck /><p>Protótipo de apresentação. Use dados fictícios: as informações são descartadas ao atualizar a página.</p></div><Button type="submit" className="action entry-submit">{initial.name ? "Salvar e voltar ao painel" : "Cadastrar e acessar"}<ArrowRight /></Button></form>
      <div className="entry-explore"><span>Quer conhecer a interface?</span><Button variant="ghost" className="text-action" onClick={onExplore}>Explorar as telas <ArrowRight /></Button></div>
      <p className="entry-caption">Ferramenta de apoio à avaliação profissional.</p>
    </div></section><Toaster theme="light" position="top-right" closeButton />
  </main>;
}

function AppSidebar({ view, navigate, professional, editProfessional, count }: { view: View; navigate: (view: View) => void; professional: Professional; editProfessional: () => void; count: number }) {
  const { isMobile, setOpenMobile } = useSidebar();
  const go = (next: View) => { navigate(next); if (isMobile) setOpenMobile(false); };
  return <Sidebar className="gs-sidebar" collapsible="offcanvas"><SidebarHeader className="gs-sidebar-header"><Brand /><Button variant="ghost" size="icon" className="mobile-close" aria-label="Fechar menu" onClick={() => setOpenMobile(false)}><X /></Button></SidebarHeader>
    <SidebarContent><SidebarGroup className="gs-sidebar-group"><SidebarGroupLabel className="nav-group-label">ACOMPANHAMENTO</SidebarGroupLabel><SidebarGroupContent><SidebarMenu className="gs-menu">{navItems.map(item => <SidebarMenuItem key={item.id}><SidebarMenuButton className="gs-menu-button" isActive={view === item.id} aria-current={view === item.id ? "page" : undefined} onClick={() => go(item.id)}><item.icon /><span>{item.label}</span>{item.id === "pacientes" && <span className="nav-count">{count}</span>}</SidebarMenuButton></SidebarMenuItem>)}</SidebarMenu></SidebarGroupContent></SidebarGroup>
    <div className="sidebar-note"><span className="sidebar-note-icon"><PenLine /></span><strong>Um registro de cada vez.</strong><p>Organize as avaliações para acompanhar cada etapa da escrita.</p></div></SidebarContent>
    <SidebarFooter className="gs-sidebar-footer"><button className="profile-button" onClick={() => { editProfessional(); setOpenMobile(false); }}><span className="avatar">{professional.name ? initials(professional.name) : <UserRound />}</span><span><strong>{professional.name || "Profissional de TO"}</strong><small>{professional.name ? "Ver meu cadastro" : "Completar cadastro"}</small></span><ChevronRight /></button></SidebarFooter>
  </Sidebar>;
}

function Metric({ label, value, note, icon: Icon, success = false }: { label: string; value: string; note: string; icon: typeof Home; success?: boolean }) {
  return <div className="metric"><div><p>{label}</p><strong>{value}</strong><small>{note}</small></div><span className={"metric-icon " + (success ? "green" : "")}><Icon /></span></div>;
}

function Dashboard({ patients, professional, navigate, addPatient, selectPatient }: { patients: Patient[]; professional: Professional; navigate: (view: View) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  return <div className="view-stack"><div className="welcome-strip"><div className="welcome-label"><span className="section-icon"><PenLine /></span><p>{professional.name ? "Olá, " + professional.name.split(" ")[0] + "." : "Boas-vindas ao seu espaço."}<strong>{patients.length ? "Tudo pronto para continuar o acompanhamento." : "Vamos começar pelo primeiro paciente?"}</strong></p></div><Button className="action" onClick={addPatient}><Plus /> Cadastrar paciente</Button></div>
    <section className="metrics-grid" aria-label="Resumo do acompanhamento"><Metric label="Pacientes cadastrados" value={String(patients.length)} note="Nesta sessão" icon={UsersRound} /><Metric label="Avaliações concluídas" value="0" note="Nenhuma avaliação realizada" icon={ClipboardCheck} /><Metric label="Em evolução" value="0" note="Aguardando resultados" icon={TrendingUp} success /><Metric label="Média geral" value="—" note="Sem dados para calcular" icon={Activity} /></section>
    <section className="dashboard-columns"><div className="panel"><div className="panel-heading"><div><span className="eyebrow">ACOMPANHAMENTO</span><h2>Evolução da escrita</h2></div><Button variant="ghost" className="text-action" onClick={() => navigate("historico")}>Ver histórico <ArrowRight /></Button></div><div className="evolution-empty"><Blank icon={TrendingUp} title="Cada evolução começa com um registro" description="As avaliações de cada paciente aparecerão aqui quando houver resultados disponíveis." compact /><div className="chart-legend"><span><i />Mão e movimentos</span><span><i className="green" />Espaçamento e legibilidade</span></div></div></div>
      <div className="panel"><div className="panel-heading"><div><span className="eyebrow">CADASTROS</span><h2>Pacientes recentes</h2></div><span className="count-badge">{patients.length}</span></div>{patients.length ? <div className="recent-patients">{patients.slice(-4).reverse().map(patient => <button key={patient.id} onClick={() => selectPatient(patient.id, "pacientes")}><span className="avatar">{initials(patient.name)}</span><span><strong>{patient.name}</strong><small>Sem avaliação</small></span><ChevronRight /></button>)}</div> : <Blank icon={UsersRound} title="Sua lista começa aqui" description="Cadastre o primeiro paciente para iniciar o acompanhamento." compact><Button variant="outline" className="action secondary" onClick={addPatient}><Plus /> Primeiro paciente</Button></Blank>}</div></section>
    <section className="quick-grid" aria-label="Etapas do acompanhamento">{[{ n: "01", icon: UsersRound, title: "Cadastre", text: "Organize os dados do paciente.", target: "pacientes" as View }, { n: "02", icon: Hand, title: "Avalie", text: "Reúna a mão e a escrita.", target: "avaliacao" as View }, { n: "03", icon: TrendingUp, title: "Acompanhe", text: "Consulte o histórico de evolução.", target: "historico" as View }].map(item => <button key={item.n} className="quick-link" onClick={() => navigate(item.target)}><span className="quick-number">{item.n}</span><item.icon /><div><strong>{item.title}</strong><p>{item.text}</p></div><ArrowRight /></button>)}</section>
  </div>;
}

function PatientsView({ patients, selectedId, search, setSearch, addPatient, selectPatient }: { patients: Patient[]; selectedId: string; search: string; setSearch: (search: string) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  const query = normalize(search.trim());
  const filtered = patients.filter(patient => normalize(patient.name).includes(query) || normalize(patient.email).includes(query));
  return <div className="panel patients-panel"><div className="patient-toolbar"><div className="search-field"><Search /><Input aria-label="Buscar paciente por nome ou e-mail" placeholder="Buscar por nome ou e-mail" value={search} onChange={event => setSearch(event.target.value)} />{search && <button onClick={() => setSearch("")} aria-label="Limpar busca"><X /></button>}</div><span className="muted">{patients.length} {patients.length === 1 ? "paciente cadastrado" : "pacientes cadastrados"}</span></div>
    {!filtered.length ? <Blank icon={patients.length ? Search : UsersRound} title={patients.length ? "Nenhum paciente encontrado" : "Nenhum paciente cadastrado"} description={patients.length ? "Tente outro nome ou e-mail para encontrar o paciente." : "Adicione os dados essenciais do primeiro paciente para começar."}>{patients.length ? <Button variant="outline" className="action secondary" onClick={() => setSearch("")}>Limpar busca</Button> : <Button className="action" onClick={addPatient}><Plus /> Cadastrar primeiro paciente</Button>}</Blank> : <Table className="patient-table"><TableHeader><TableRow><TableHead>Paciente</TableHead><TableHead>Telefone do responsável</TableHead><TableHead>Situação</TableHead><TableHead className="text-right">Ações</TableHead></TableRow></TableHeader><TableBody>{filtered.map(patient => <TableRow key={patient.id} className={selectedId === patient.id ? "selected-row" : ""}><TableCell><button className="patient-name" onClick={() => selectPatient(patient.id, "avaliacao")}><span className="avatar">{initials(patient.name)}</span><span><strong>{patient.name}</strong><small>{patient.email}</small></span></button></TableCell><TableCell>{patient.phone}</TableCell><TableCell><span className="status"><Clock3 /> Sem avaliação</span></TableCell><TableCell><div className="table-actions"><Button variant="ghost" className="text-action" onClick={() => selectPatient(patient.id, "historico")}>Histórico</Button><Button variant="outline" className="action secondary" onClick={() => selectPatient(patient.id, "avaliacao")}>Avaliar <ArrowRight /></Button></div></TableCell></TableRow>)}</TableBody></Table>}
  </div>;
}

function PatientPicker({ patients, selectedId, onSelect, addPatient }: { patients: Patient[]; selectedId: string; onSelect: (id: string) => void; addPatient: () => void }) {
  return <div className="patient-picker"><span className="section-icon"><UserRound /></span><div className="picker-field"><Label htmlFor="active-patient">Paciente selecionado</Label><Select value={selectedId} onValueChange={onSelect} disabled={!patients.length}><SelectTrigger id="active-patient"><SelectValue placeholder="Cadastre um paciente para começar" /></SelectTrigger><SelectContent>{patients.map(patient => <SelectItem key={patient.id} value={patient.id}>{patient.name}</SelectItem>)}</SelectContent></Select></div><Button variant="ghost" className="text-action" onClick={addPatient}><Plus /> Novo paciente</Button></div>;
}

function AssessmentView({ selected, draft, updateDraft, showResults, addPatient }: { selected?: Patient; draft: Draft; updateDraft: (draft: Draft) => void; showResults: () => void; addPatient: () => void }) {
  const readyCount = Number(!!draft.video) + Number(!!draft.image);
  return <div className="view-stack">{!selected && <Notice>Cadastre ou selecione um paciente para habilitar a câmera e o envio da fotografia. <button className="inline-link" onClick={addPatient}>Cadastrar paciente</button></Notice>}
    <div className="assessment-progress"><span className={selected ? "complete" : ""}>{selected ? <CheckCircle2 /> : <span className="step-dot">1</span>} Paciente</span><i /><span className={selected ? "current" : ""}><span className="step-dot">2</span> Vídeo e fotografia</span><i /><span><span className="step-dot">3</span> Resultados</span></div>
    <div className="assessment-columns"><section className="panel collection-panel"><div className="collection-heading"><span className="section-icon"><Hand /></span><div><span className="eyebrow">AVALIAÇÃO 01</span><h2>Mão e movimentos</h2></div>{draft.video && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Registre a posição e os movimentos da mão durante a atividade de escrita.</p><MediaInput kind="video" file={draft.video} disabled={!selected} onChange={file => updateDraft({ ...draft, video: file })} /><div className="collection-tip"><Check /> Mão, lápis e papel visíveis; câmera estável.</div></section>
    <section className="panel collection-panel"><div className="collection-heading"><span className="section-icon"><PenLine /></span><div><span className="eyebrow">AVALIAÇÃO 02</span><h2>Espaçamento e legibilidade</h2></div>{draft.image && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Fotografe a folha para observar o espaçamento e a legibilidade da escrita.</p><MediaInput kind="image" file={draft.image} disabled={!selected} onChange={file => updateDraft({ ...draft, image: file })} /><div className="collection-tip"><Check /> Texto nítido, folha enquadrada e sem sombras.</div></section></div>
    <div className="assessment-bottom"><div><span className={"ready-pill " + (readyCount === 2 ? "ready" : "")}>{readyCount === 2 ? <CheckCircle2 /> : <ClipboardCheck />}{readyCount}/2 etapas concluídas</span><p>Prévia local. O processamento será integrado em uma próxima etapa.</p></div><Button className="action" disabled={readyCount !== 2 || !selected} onClick={showResults}>Conferir avaliação <ArrowRight /></Button></div>
  </div>;
}

function ResultsView({ selected, draft, navigate }: { selected?: Patient; draft: Draft; navigate: (view: View) => void }) {
  const ready = !!draft.video && !!draft.image;
  return <div className="view-stack"><section className="results-metrics"><Metric label="Mão e movimentos" value="—" note="Média indisponível" icon={Hand} /><Metric label="Espaçamento e legibilidade" value="—" note="Média indisponível" icon={PenLine} /><Metric label="Média geral" value="—" note="Aguardando análise" icon={Activity} /></section>
    <div className="panel"><Blank icon={ready ? ClipboardCheck : BarChart3} title={ready ? "Arquivos prontos para análise" : "Ainda não há resultados"} description={ready ? "O vídeo foi gravado e a fotografia foi selecionada. As médias serão exibidas quando o processamento estiver integrado ao GrafiSense." : selected ? selected.name + " ainda não possui avaliações concluídas." : "Selecione um paciente para acompanhar os resultados das avaliações."}>{ready && <div className="review-files"><span><CheckCircle2 /><strong>{draft.video?.name}</strong></span><span><CheckCircle2 /><strong>{draft.image?.name}</strong></span></div>}<Button variant="outline" className="action secondary" onClick={() => navigate(selected ? "avaliacao" : "pacientes")}>{ready ? <ArrowLeft /> : <Plus />}{ready ? "Voltar à avaliação" : selected ? "Iniciar avaliação" : "Ir para pacientes"}</Button></Blank></div><Notice attention>Os indicadores apoiam a observação do profissional. O GrafiSense não emite diagnóstico ou porcentagem de disgrafia.</Notice>
  </div>;
}

function HistoryView({ selected, navigate }: { selected?: Patient; navigate: (view: View) => void }) {
  const [date, setDate] = useState("");
  return <div className="view-stack"><Tabs defaultValue="evolucao" className="history-tabs"><div className="history-controls"><TabsList className="gs-tabs"><TabsTrigger value="evolucao"><TrendingUp /> Evolução</TabsTrigger><TabsTrigger value="registros"><History /> Avaliações</TabsTrigger></TabsList><div className="date-filter"><Label htmlFor="history-date"><CalendarDays /> Data</Label><Input id="history-date" type="date" value={date} onChange={event => setDate(event.target.value)} />{date && <Button variant="ghost" size="icon" aria-label="Limpar filtro de data" onClick={() => setDate("")}><X /></Button>}</div></div>
    <TabsContent value="evolucao"><div className="panel"><div className="panel-heading"><h2>Evolução ao longo do tempo</h2><span className="pill">0 avaliações</span></div><Blank icon={TrendingUp} title={date ? "Nenhuma avaliação nesta data" : "O histórico começa na primeira avaliação"} description={selected ? selected.name + " ainda não possui resultados para comparação." : "Selecione um paciente para consultar as avaliações e suas médias."}><Button variant="outline" className="action secondary" onClick={() => date ? setDate("") : navigate(selected ? "avaliacao" : "pacientes")}>{date ? "Limpar filtro" : selected ? "Iniciar avaliação" : "Ir para pacientes"}<ArrowRight /></Button></Blank><div className="chart-legend"><span><i />Mão e movimentos</span><span><i className="green" />Espaçamento e legibilidade</span></div></div></TabsContent>
    <TabsContent value="registros"><div className="panel"><Table><TableHeader><TableRow><TableHead>Data da avaliação</TableHead><TableHead>Mão e movimentos</TableHead><TableHead>Escrita</TableHead><TableHead>Média geral</TableHead><TableHead>Evolução</TableHead></TableRow></TableHeader><TableBody><TableRow><TableCell colSpan={5}><Blank icon={History} title="Nenhuma avaliação registrada" description={date ? "Não existem registros para a data selecionada." : "As avaliações concluídas aparecerão aqui, organizadas por data."} compact /></TableCell></TableRow></TableBody></Table></div></TabsContent></Tabs></div>;
}

export default function HomePage() {
  const [started, setStarted] = useState(false);
  const [professional, setProfessional] = useState<Professional>(emptyProfessional);
  const [view, setView] = useState<View>("inicio");
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [search, setSearch] = useState("");
  const [dialog, setDialog] = useState(false);
  const [patientForm, setPatientForm] = useState<PatientForm>(emptyPatientForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const heading = useRef<HTMLHeadingElement>(null);
  const selected = patients.find(patient => patient.id === selectedId);
  const draft = drafts[selectedId] || {};
  const navigate = (next: View) => { setView(next); requestAnimationFrame(() => { heading.current?.focus(); window.scrollTo({ top: 0, behavior: "instant" }); }); };
  const addPatient = () => { setPatientForm(emptyPatientForm); setErrors({}); setDialog(true); };
  const selectPatient = (id: string, next: View) => { setSelectedId(id); navigate(next); };
  function submitPatient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const { name, email, phone } = patientForm;
    const nextErrors = validatePerson({ name, email, phone });
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("patient-" + Object.keys(nextErrors)[0])?.focus(); return; }
    const newPatient: Patient = { id: crypto.randomUUID(), name: name.trim(), email: email.trim().toLowerCase(), phone };
    setPatients(current => [...current, newPatient]); setSelectedId(newPatient.id); setDialog(false); toast.success("Paciente adicionado à demonstração.");
  }
  if (!started) return <ProfessionalEntry initial={professional} onContinue={value => { setProfessional(value); setStarted(true); toast.success("Cadastro profissional preenchido."); }} onExplore={() => setStarted(true)} />;
  return <SidebarProvider style={{ "--sidebar-width": "16.75rem" } as CSSProperties}><a href="#page-heading" className="skip-link">Ir para o conteúdo</a><AppSidebar view={view} navigate={navigate} professional={professional} count={patients.length} editProfessional={() => setStarted(false)} /><SidebarInset className="gs-main">
    <header className="topbar"><div className="topbar-route"><SidebarTrigger className="menu-trigger" aria-label="Abrir ou recolher menu" /><span>Área profissional</span><ChevronRight /><strong>{navItems.find(item => item.id === view)?.label}</strong></div><span className="prototype-label">Protótipo interativo</span></header>
    <div className="workspace"><div className="page-heading"><div><span className="eyebrow">{view === "inicio" ? "VISÃO GERAL" : "ACOMPANHAMENTO DA ESCRITA"}</span><h1 id="page-heading" ref={heading} tabIndex={-1}>{viewCopy[view].title}</h1><p>{viewCopy[view].description}</p></div>{view === "pacientes" && <Button className="action" onClick={addPatient}><Plus /> Cadastrar paciente</Button>}</div>
      {view === "inicio" && <Dashboard patients={patients} professional={professional} navigate={navigate} addPatient={addPatient} selectPatient={selectPatient} />}
      {view === "pacientes" && <PatientsView patients={patients} selectedId={selectedId} search={search} setSearch={setSearch} addPatient={addPatient} selectPatient={selectPatient} />}
      {["avaliacao", "resultados", "historico"].includes(view) && <PatientPicker patients={patients} selectedId={selectedId} onSelect={setSelectedId} addPatient={addPatient} />}
      {view === "avaliacao" && <AssessmentView selected={selected} draft={draft} updateDraft={value => { if (selectedId) setDrafts(current => ({ ...current, [selectedId]: value })); }} showResults={() => navigate("resultados")} addPatient={addPatient} />}
      {view === "resultados" && <ResultsView selected={selected} draft={draft} navigate={navigate} />}
      {view === "historico" && <HistoryView key={selectedId} selected={selected} navigate={navigate} />}
    </div><footer className="app-footer"><span>GrafiSense <span aria-hidden="true">·</span> Apoio ao profissional de TO</span><span><Info /> Demonstração: dados apenas nesta sessão</span></footer>
  </SidebarInset>
  <Dialog open={dialog} onOpenChange={setDialog}><DialogContent className="gs-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar cadastro"><X /></Button></DialogClose><DialogHeader><span className="section-icon"><UserRound /></span><DialogTitle>Cadastrar paciente</DialogTitle><DialogDescription>Informe os dados essenciais para iniciar o acompanhamento.</DialogDescription></DialogHeader><form onSubmit={submitPatient} noValidate><PersonFields value={patientForm} onChange={setPatientForm} prefix="patient-" errors={errors} /><div className="demo-note"><ShieldCheck /><p>Use dados fictícios nesta demonstração. Os cadastros não são armazenados ao atualizar a página.</p></div><DialogFooter><Button variant="outline" type="button" className="action secondary" onClick={() => setDialog(false)}>Cancelar</Button><Button type="submit" className="action"><Plus /> Cadastrar paciente</Button></DialogFooter></form></DialogContent></Dialog><Toaster theme="light" position="top-right" closeButton />
  </SidebarProvider>;
}
