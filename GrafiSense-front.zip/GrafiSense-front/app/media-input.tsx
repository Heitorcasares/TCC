"use client";

import { useEffect, useRef, useState } from "react";
import { Camera, CheckCircle2, FileImage, LoaderCircle, RotateCcw, Square, UploadCloud, Video, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

type Props = { kind: "video" | "image"; file?: File; disabled?: boolean; onChange: (file?: File) => void };

function CameraCapture({ onCapture }: { onCapture: (file: File) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const active = useRef(true);
  const [ready, setReady] = useState(false);
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    active.current = true;
    let cancelled = false;
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("A câmera não está disponível. Abra o site em uma conexão HTTPS e em um navegador com suporte à câmera."); return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false }).then(stream => {
      if (cancelled) { stream.getTracks().forEach(track => track.stop()); return; }
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    }).catch((cause: unknown) => {
      if (cancelled) return;
      const code = cause instanceof DOMException ? cause.name : "";
      setError(code === "NotAllowedError" ? "Acesso à câmera não autorizado. Permita o uso da câmera nas configurações do navegador e tente novamente." : code === "NotFoundError" ? "Nenhuma câmera foi encontrada neste dispositivo. Conecte uma câmera e tente novamente." : "Não foi possível abrir a câmera. Confira se ela está conectada e se outro aplicativo está usando o dispositivo.");
    });
    return () => {
      active.current = false;
      cancelled = true;
      if (recorderRef.current?.state === "recording") recorderRef.current.stop();
      streamRef.current?.getTracks().forEach(track => track.stop());
    };
  }, []);

  useEffect(() => {
    if (!recording) return;
    const timer = window.setInterval(() => setSeconds(value => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [recording]);

  function record() {
    if (!streamRef.current) return;
    if (typeof MediaRecorder === "undefined") { setError("Este navegador não permite gravação de vídeo. Acesse por um navegador com suporte à gravação pela câmera."); return; }
    try {
      const mime = ["video/webm;codecs=vp8", "video/webm", "video/mp4"].find(type => MediaRecorder.isTypeSupported(type));
      const recorder = new MediaRecorder(streamRef.current, { ...(mime ? { mimeType: mime } : {}), videoBitsPerSecond: 2500000 });
      recorderRef.current = recorder;
      const chunks: Blob[] = [];
      let totalBytes = 0;
      let failed = false;
      recorder.ondataavailable = event => {
        if (event.data.size) { chunks.push(event.data); totalBytes += event.data.size; }
        if (totalBytes > 100 * 1024 * 1024 && recorder.state === "recording") recorder.stop();
      };
      recorder.onerror = () => { failed = true; if (active.current) { setRecording(false); setError("A gravação foi interrompida. Feche a câmera e tente novamente."); } };
      recorder.onstop = () => {
        if (!active.current || failed || !chunks.length) return;
        setRecording(false);
        const type = recorder.mimeType || "video/webm";
        onCapture(new File(chunks, "gravacao-mao." + (type.includes("mp4") ? "mp4" : "webm"), { type }));
      };
      recorder.start(1000); setSeconds(0); setRecording(true);
    } catch { setError("Não foi possível iniciar a gravação. Feche a câmera e tente novamente."); }
  }

  return <div className="camera-capture">
    {error ? <div className="notice attention" role="alert">{error}</div> : <>
      <div className="camera-frame"><video ref={videoRef} autoPlay muted playsInline onLoadedData={() => setReady(true)} aria-label="Prévia ao vivo da câmera" />{!ready && <span><LoaderCircle className="animate-spin" /> Aguardando acesso à câmera…</span>}</div>
      <div className="camera-status" role="status"><span className={recording ? "recording-status" : "muted"}>{recording ? "Gravando" : ready ? "Câmera pronta" : "Aguardando câmera"}</span><span>{Math.floor(seconds / 60).toString().padStart(2, "0")}:{(seconds % 60).toString().padStart(2, "0")}</span></div>
      <p className="muted">Mantenha a mão, o lápis e o papel visíveis. A gravação é feita sem áudio.</p>
      {recording ? <Button className="action stop-recording" onClick={() => { recorderRef.current?.stop(); setRecording(false); }}><Square /> Finalizar gravação</Button> : <Button className="action" disabled={!ready} onClick={record}><Video /> Iniciar gravação</Button>}
    </>}
  </div>;
}

export function MediaInput({ kind, file, disabled = false, onChange }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState("");
  const [camera, setCamera] = useState(false);
  const [dragging, setDragging] = useState(false);
  const isVideo = kind === "video";
  useEffect(() => {
    if (!file) { setUrl(""); return; }
    const objectUrl = URL.createObjectURL(file); setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);

  function choosePhoto(next?: File) {
    if (!next || disabled || isVideo) return;
    if (!/\.(jpe?g|png|webp)$/i.test(next.name) || (next.type && !["image/jpeg", "image/png", "image/webp"].includes(next.type))) { toast.error("Selecione uma imagem JPG, PNG ou WebP."); return; }
    if (!next.size || next.size > 10 * 1024 * 1024) { toast.error("Escolha uma imagem não vazia de até 10 MB."); return; }
    onChange(next); toast.success("Fotografia selecionada.");
  }
  function finishRecording(next: File) {
    if (!next.size) { toast.error("A gravação ficou vazia. Tente novamente."); return; }
    onChange(next); setCamera(false); toast.success("Vídeo gravado. Confira a prévia.");
  }

  return <>
    {!isVideo && <input ref={input} type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" className="sr-only" tabIndex={-1} aria-label="Selecionar fotografia da escrita" disabled={disabled} onChange={event => { choosePhoto(event.target.files?.[0]); event.target.value = ""; }} />}
    {file ? <div className="selected-media"><div className="media-preview">{url && (isVideo ? <video key={url} controls src={url} preload="metadata" aria-label="Prévia do vídeo gravado" /> : <img src={url} alt="Fotografia da escrita selecionada" />)}</div><div className="file-summary"><CheckCircle2 className="success-icon" /><span><strong>{isVideo ? "Vídeo da mão gravado" : file.name}</strong><small>{(file.size / 1024 / 1024).toFixed(1)} MB · {isVideo ? "pronto para conferir" : "selecionado"}</small></span><Button variant="ghost" size="icon" aria-label={isVideo ? "Remover gravação" : "Remover fotografia"} onClick={() => onChange(undefined)}><X /></Button></div></div> : isVideo ? <div className="drop-area camera-area"><span className="upload-icon"><Camera /></span><h3>Grave a mão durante a escrita</h3><p>Abra a câmera e permita o acesso para visualizar e gravar a atividade.</p><Button className="action" disabled={disabled} onClick={() => setCamera(true)}><Camera /> Abrir câmera</Button><small>A gravação começa quando você escolher.</small></div> : <div className={"drop-area " + (dragging ? "dragging" : "")} onDragOver={event => { event.preventDefault(); if (!disabled) setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); choosePhoto(event.dataTransfer.files[0]); }}><span className="upload-icon"><FileImage /></span><h3>Fotografia da escrita</h3><p>Arraste a fotografia para cá ou selecione um arquivo.</p><Button variant="outline" className="action secondary" disabled={disabled} onClick={() => input.current?.click()}><UploadCloud /> Selecionar fotografia</Button><small>JPG, PNG ou WebP · até 10 MB</small></div>}
    {file && <Button variant="ghost" className="camera-button" disabled={disabled} onClick={() => isVideo ? setCamera(true) : input.current?.click()}>{isVideo ? <RotateCcw /> : <UploadCloud />}{isVideo ? "Gravar novamente" : "Trocar fotografia"}</Button>}
    {isVideo && <Dialog open={camera} onOpenChange={setCamera}><DialogContent className="gs-dialog camera-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar câmera"><X /></Button></DialogClose><DialogHeader><DialogTitle>Gravar a atividade de escrita</DialogTitle><DialogDescription>Ao fechar esta janela, o acesso à câmera é encerrado. O vídeo fica apenas nesta sessão.</DialogDescription></DialogHeader>{camera && <CameraCapture onCapture={finishRecording} />}</DialogContent></Dialog>}
  </>;
}
