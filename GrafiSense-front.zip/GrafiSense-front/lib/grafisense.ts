export type Patient = { id: string; name: string; email: string; phone: string };
export type PatientForm = Omit<Patient, "id">;
export type Professional = { name: string; cpf: string; phone: string; email: string };
export type Draft = { video?: File; image?: File };
export const emptyProfessional: Professional = { name: "", cpf: "", phone: "", email: "" };
export const emptyPatientForm: PatientForm = { name: "", email: "", phone: "" };
export const digits = (value: string) => value.replace(/\D/g, "");
export const initials = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(p => p[0]).join("").toUpperCase();
export const normalize = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
export function maskCpf(value: string) {
  return digits(value).slice(0, 11).replace(/^(\d{3})(\d)/, "$1.$2").replace(/^(\d{3})\.(\d{3})(\d)/, "$1.$2.$3").replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, "$1.$2.$3-$4");
}
export function maskPhone(value: string) {
  const n = digits(value).slice(0, 11);
  if (n.length <= 2) return n;
  return `(${n.slice(0, 2)}) ${n.slice(2)}`.replace(n.length > 10 ? /(\d{5})(\d)/ : /(\d{4})(\d)/, "$1-$2");
}
export function validatePerson(person: PatientForm | Professional) {
  const errors: Record<string, string> = {};
  if (person.name.trim().split(/\s+/).length < 2) errors.name = "Informe o nome completo.";
  if ("cpf" in person && digits(person.cpf).length !== 11) errors.cpf = "O CPF deve ter 11 dígitos.";
  if (![10, 11].includes(digits(person.phone).length)) errors.phone = "Informe o DDD e o telefone.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(person.email.trim())) errors.email = "Informe um e-mail válido.";
  return errors;
}
