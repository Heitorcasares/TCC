# Revisão da avaliação da mão — versão 1.3.0

A avaliação estima uma postura compatível com **palmar** ou **pinça**. Quando não há evidência suficiente, informa **inconclusivo** ou **mão não detectada**. Não mede força, contato com o lápis, amplitude de movimento ou diagnóstico.

## O que foi refinado

- Verificação de todos os segmentos dos cinco dedos, incluindo o polegar. Pontos ausentes, não finitos, segmentos degenerados ou desproporcionais não geram uma classificação.
- Manutenção das amostras sem mão na sequência. A análise não reúne artificialmente trechos separados por perda de detecção.
- A postura predominante precisa aparecer em pelo menos metade da amostra total e em três amostras consecutivas, além dos critérios anteriores de predominância.
- Explicação dos quadros descartados: ausência de mão, mais de uma mão, pontos incompletos, pontos inconsistentes ou falta de padrão claro.
- Os resultados anteriores de palmar/pinça são preservados com a identificação de que antecedem a revisão. Um novo vídeo é necessário para aplicar os critérios novos.

Amostras consecutivas são imagens selecionadas ao longo do vídeo; não significam que todos os quadros entre elas foram examinados. O teto permanece em 60 amostras. Os percentuais são contagens, não confiança ou probabilidade de acerto.

## Testes realizados

As regras foram verificadas com pontos sintéticos de palmar, pinça pelo indicador, pinça pelo médio, dedos estendidos e controles sem padrão de preensão. Há casos de perda de mão, duas mãos, enquadramento incompleto, ausência de pontos 3D, posturas alternadas e evidência insuficiente.

Foram executadas 100 variações para cada um de quatro padrões sintéticos, totalizando 400, com ruído de 1% da largura da palma, rotações 3D, escala, translação e espelhamento. Esses padrões claros mantiveram o resultado esperado. Isso verifica estabilidade desses casos de software; não estima a precisão em pessoas.

O pipeline de vídeo foi testado com pontos sintéticos controlados e, separadamente, com o detector MediaPipe real em vídeos sem mão. A suite também verifica diferentes formatos, limites, o WebM do navegador e persistência após reinício.

## Como testar com gravações reais

1. Grave de 5 a 10 segundos durante a tarefa de escrita, com boa iluminação, câmera estável e somente a mão avaliada no enquadramento. Inclua os dedos e o lápis.
2. Identifique a postura observada manualmente antes de consultar a resposta do sistema. Use “não identificável” quando a imagem não permitir avaliar.
3. Inclua palmar, pinça, mudanças entre posturas, mãos direita/esquerda e casos de baixa visibilidade. Use vídeos de pessoas diferentes e somente mídias que você tenha autorização para utilizar.
4. Compare a observação com a resposta e registre também os inconclusivos. Não conte uma abstenção como acerto de classificação.
5. Separe vídeos para ajustar as regras e outros para verificar o resultado final. Reutilizar os mesmos vídeos nas duas etapas superestima a qualidade.

Não foram fornecidos vídeos reais com essas posturas rotuladas nesta atualização. Portanto, não há uma porcentagem de acurácia validada. A versão reduz classificações sem suporte nos casos reproduzidos; isso pode aumentar os resultados inconclusivos quando a gravação não é clara.

Os arquivos enviados ao sistema são temporários e não ficam guardados no histórico. Para repetir um teste, selecione o vídeo original novamente.
