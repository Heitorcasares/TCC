"""Estimativa EXPERIMENTAL de postura palmar/pinça, sem classificador treinado.

Regras sobre geometria 3D normalizada pela largura da palma. Os limiares são
de engenharia, não critérios clínicos validados. Não detectamos o objeto nem
medimos força ou contato: posturas compatíveis não comprovam uma preensão.
"""
import math
from collections import Counter
import numpy as np

METHOD = "geometria-preensao-v2"
POSTURE_METHODS = {"geometria-preensao-v1", METHOD}
LABELS = ("Palmar", "Pinça")
MIN_CLASSIFIED_FRAMES = 3
ISSUES = {
    "no_hand": "Mão não detectada. Mantenha a mão inteira visível e bem iluminada.",
    "multiple_hands": "Mais de uma mão visível. Enquadre somente a mão que segura o lápis.",
    "incomplete_hand": "Pontos da mão incompletos ou fora da imagem. Afaste um pouco a câmera.",
    "invalid_landmarks": "Pontos da mão inconsistentes. Melhore a iluminação e evite encobrir os dedos.",
    "no_clear_pattern": "Sem postura clara de palmar ou pinça. Mostre a mão segurando o lápis durante a tarefa.",
}


def angle(a, b, c):
    u, v = a - b, c - b
    denominator = float(np.linalg.norm(u) * np.linalg.norm(v))
    if denominator < 1e-12:
        return None
    return math.degrees(math.acos(float(np.clip(np.dot(u, v) / denominator, -1, 1))))


def estimate_posture(world_points):
    """Recebe 21 pontos 3D do MediaPipe e pode abster-se de classificar."""
    try:
        points = np.asarray(world_points, dtype=float)
    except (TypeError, ValueError):
        return {"label": None, "reason": "invalid_landmarks"}
    if points.shape != (21, 3) or not np.isfinite(points).all():
        return {"label": None, "reason": "invalid_landmarks"}
    scale = float(np.linalg.norm(points[5] - points[17]))
    if not math.isfinite(scale) or scale < 1e-7:
        return {"label": None, "reason": "invalid_landmarks"}
    p = (points - points[0]) / scale
    # Sanidade geométrica ampla, inclusive no polegar. Não são medidas
    # anatômicas normativas; servem para descartar esqueletos degenerados.
    segments = [(i, i + 1) for base in (1, 5, 9, 13, 17) for i in range(base, base + 3)]
    if (not np.isfinite(p).all()
            or any(not .02 <= np.linalg.norm(p[b] - p[a]) <= 2.0 for a, b in segments)
            or np.linalg.norm(np.cross(p[5], p[17])) < .02):
        return {"label": None, "reason": "invalid_landmarks"}
    palm_center = np.mean(p[[0, 5, 9, 13, 17]], axis=0)
    flexed, near_palm = [], []
    for base in (5, 9, 13, 17):
        pip = angle(p[base], p[base + 1], p[base + 2])
        dip = angle(p[base + 1], p[base + 2], p[base + 3])
        if pip is None or dip is None:
            return {"label": None, "reason": "invalid_landmarks"}
        flexed.append(pip < 130 or (pip < 155 and dip < 125))
        near_palm.append(float(np.linalg.norm(p[base + 3] - palm_center)) < 1.0)
    thumb = p[4]
    distances = {base: float(np.linalg.norm(thumb - p[base + 3])) for base in (5, 9)}
    # Pinça: polegar próximo ao indicador/médio, com contato presumido distal.
    pinch = any(
        distance <= .45
        and float(np.linalg.norm(p[base + 3] - p[base])) >= .75
        and float(np.linalg.norm((thumb + p[base + 3]) / 2 - palm_center)) >= .85
        for base, distance in distances.items()
    )
    # Palmar: ao menos 3 dedos fletidos perto da palma, incluindo indicador.
    palmar = (
        flexed[0] and sum(flexed) >= 3 and sum(near_palm) >= 3
        and float(np.linalg.norm(thumb - palm_center)) <= 1.10
        and not pinch
    )
    label = "Pinça" if pinch else "Palmar" if palmar else None
    return {
        "label": label,
        "reason": "compatible_posture" if label else "no_clear_pattern",
        "measurements": {
            "thumbIndexDistance": round(distances[5], 4),
            "thumbMiddleDistance": round(distances[9], 4),
            "flexedFingers": sum(flexed),
        },
    }


def summarize_postures(observations, sampled_frames, duration):
    """Percentuais são contagens de quadros; nunca probabilidades clínicas."""
    counts = Counter(item.get("label") for item in observations if item.get("label") in LABELS)
    detected = sum(item.get("reason") != "no_hand" for item in observations)
    classified = sum(counts.values())
    uncertain = detected - classified
    winner, winner_count = max(((label, counts[label]) for label in LABELS), key=lambda pair: pair[1])
    longest_run = run = 0
    for item in observations:
        run = run + 1 if item.get("label") == winner else 0
        longest_run = max(longest_run, run)
    support = winner_count / max(sampled_frames, 1)
    sufficient = (
        classified >= MIN_CLASSIFIED_FRAMES
        and detected / max(sampled_frames, 1) >= .5
        and classified / max(detected, 1) >= .6
        and winner_count / max(classified, 1) >= .7
        and support >= .5
        and longest_run >= MIN_CLASSIFIED_FRAMES
    )
    reasons = Counter(item.get("reason", "no_clear_pattern") for item in observations if item.get("label") not in LABELS)
    reasons["no_hand"] = sampled_frames - detected
    if not detected:
        status, message = "no_hand", "Nenhuma mão identificada. Mantenha a mão inteira visível, com boa iluminação."
    elif sufficient:
        status, message = "ok", "Postura predominante estimada pela geometria da mão. Confira o resultado com a observação do vídeo."
    elif classified < MIN_CLASSIFIED_FRAMES:
        problem = max(ISSUES, key=lambda code: reasons[code])
        status, message = "inconclusive", f"Não há quadros claros suficientes para estimar a preensão. {ISSUES[problem]} Grave de 5 a 10 segundos."
    elif support < .5:
        status, message = "inconclusive", "A mesma postura não foi identificada em pelo menos metade da amostra. Grave novamente com a mão inteira visível durante a tarefa."
    elif longest_run < MIN_CLASSIFIED_FRAMES:
        status, message = "inconclusive", "Não houve uma sequência de três amostras com a mesma postura. Evite movimentos bruscos da câmera e mantenha os dedos visíveis."
    else:
        status, message = "inconclusive", "A postura variou ou ficou pouco visível. Não foi possível indicar uma preensão predominante."
    return {
        "method": METHOD, "experimental": True,
        "status": status, "label": winner if sufficient else None,
        "message": message, "sampledFrames": sampled_frames,
        "detectedFrames": detected, "classifiedFrames": classified,
        "uncertainFrames": uncertain,
        "multipleHandFrames": sum(item.get("reason") == "multiple_hands" for item in observations),
        "quality": {
            "classifiedPercent": round(100 * classified / max(sampled_frames, 1), 2),
            "predominantPercent": round(100 * support, 2),
            "longestStableRun": longest_run,
            "issues": [{"code": code, "frames": reasons[code], "message": message}
                       for code, message in ISSUES.items() if reasons[code]],
        },
        "durationSeconds": round(duration, 2),
        "distribution": [
            {"label": label, "frames": counts[label], "percent": round(100 * counts[label] / max(detected, 1), 2)}
            for label in LABELS
        ],
    }


def public_hand_result(result):
    """Histórico antigo continua salvo, mas não é reinterpretado como preensão."""
    if not result or result.get("method") in POSTURE_METHODS:
        return result
    return {
        "method": "legacy", "experimental": False, "status": "legacy", "label": None,
        "message": "Este vídeo foi analisado por um método anterior. Envie um novo vídeo para analisar a preensão palmar ou em pinça.",
        "sampledFrames": result.get("sampledFrames", 0),
        "detectedFrames": result.get("detectedFrames", 0),
        "classifiedFrames": 0, "uncertainFrames": 0, "multipleHandFrames": 0,
        "durationSeconds": result.get("durationSeconds", 0), "distribution": [],
    }
