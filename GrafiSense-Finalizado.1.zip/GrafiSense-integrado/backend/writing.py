"""Adaptação de Machine Learning for Write/src/index.py.

Mantém os cinco indicadores; corrige a ordem das letras, agregação das linhas,
desvio do espaçamento e casos sem componentes. Não é um modelo treinado.
"""
import math
import warnings
import numpy as np
from PIL import Image, ImageOps

MAX_PIXELS = 25_000_000


def analyze_writing(path):
    import cv2
    from sklearn.cluster import DBSCAN
    from skimage.morphology import skeletonize

    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        try:
            with Image.open(path) as source:
                if source.format not in ("JPEG", "PNG", "WEBP"):
                    raise ValueError("Envie uma imagem JPG, PNG ou WebP.")
                if source.width * source.height > MAX_PIXELS:
                    raise ValueError("A imagem deve ter no máximo 25 milhões de pixels.")
                image = ImageOps.exif_transpose(source).convert("RGBA")
                white = Image.new("RGBA", image.size, "white")
                white.alpha_composite(image)
                image = white.convert("RGB")
                image.thumbnail((1800, 1800))
                rgb = np.asarray(image)
        except (OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
            raise ValueError("Imagem inválida ou grande demais. Envie outra fotografia.") from exc
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    height, width = binary.shape
    total, _, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    components = [{"x": int(x), "y": int(y), "w": int(w), "h": int(h), "area": int(area)}
                  for x, y, w, h, area in stats[1:] if 8 <= area <= height * width * .05]
    base = {"method": "heuristica-geometrica-v1", "components": len(components),
            "imageWidth": width, "imageHeight": height}
    if len(components) < 5:
        return {**base, "status": "insufficient", "message": "Poucos traços identificados. Fotografe uma frase nítida em papel claro.", "metrics": None, "lines": 0}
    if len(components) > 5000:
        raise ValueError("Imagem com detalhes demais. Recorte somente a área da escrita e tente novamente.")

    heights = np.array([c["h"] for c in components], dtype=float)
    median_height = float(np.median(heights))
    groups = DBSCAN(eps=max(median_height * .8, 1), min_samples=3).fit_predict([[c["y"]] for c in components])
    lines = [[c for c, g in zip(components, groups) if g == group] for group in sorted(set(groups)) if group != -1]
    if not lines:
        return {**base, "status": "insufficient", "message": "Não foi possível identificar linhas de escrita. Use uma foto de frente, com pelo menos uma frase.", "metrics": None, "lines": 0}

    alignment_scores, gaps = [], []
    for line in lines:
        line.sort(key=lambda c: c["x"])
        x, y = np.array([c["x"] for c in line], float), np.array([c["y"] for c in line], float)
        # Least squares também funciona quando todos os x são iguais.
        design = np.column_stack((x, np.ones_like(x)))
        expected = design @ np.linalg.lstsq(design, y, rcond=None)[0]
        relative_error = float(np.sqrt(np.mean((y - expected) ** 2)) / median_height)
        alignment_scores.append(math.exp(-math.log(2) * relative_error / .15))
        gaps.extend(max(0, b["x"] - (a["x"] + a["w"])) / median_height for a, b in zip(line, line[1:]))
    alignment = float(np.mean(alignment_scores))
    height_regularity = math.exp(-float(np.std(heights) / (np.mean(heights) + 1e-8)))
    gap_regularity = math.exp(-float(np.std(gaps) / (np.mean(gaps) + 1e-8))) if gaps else 0.0
    distance = cv2.distanceTransform(binary, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    skeleton = skeletonize(binary > 0)
    thickness_px = float(np.median(2 * distance[skeleton])) if skeleton.any() else 0.0

    def percent(value):
        return round(float(np.clip(value, 0, 1)) * 100, 2)

    return {**base, "status": "ok", "lines": len(lines), "message": "Indicadores geométricos calculados sobre a fotografia.",
            "metrics": {
                "legibility": percent(.5 * alignment + .3 * height_regularity + .2 * gap_regularity),
                "letterSize": percent(median_height / height / .10),
                "alignment": percent(alignment),
                "spacing": percent(float(np.median(gaps)) / .50 if gaps else 0),
                "strokeThickness": percent(thickness_px / median_height / .20),
            }}
