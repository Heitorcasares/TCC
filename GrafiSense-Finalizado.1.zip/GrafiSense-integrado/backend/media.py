"""Configuração de mídia compartilhada com o front compilado."""
import json
from pathlib import Path

SETTINGS = json.loads((Path(__file__).resolve().parents[1] / "config" / "media.json").read_text(encoding="utf-8"))
VIDEO_BYTES = SETTINGS["maxVideoMB"] * 1024 * 1024
IMAGE_BYTES = SETTINGS["maxImageMB"] * 1024 * 1024
VIDEO_EXTENSIONS = {"." + extension for extension in SETTINGS["videoExtensions"]}
MAX_SECONDS = SETTINGS["maxVideoSeconds"]
MAX_FRAMES = SETTINGS["maxSampledFrames"]
MAX_PROCESSING_SECONDS = SETTINGS["maxProcessingSeconds"]
THUMBNAIL_MAX_SIDE = SETTINGS["thumbnailMaxSide"]
VIDEO_FORMATS = ", ".join(extension.upper() for extension in SETTINGS["videoExtensions"])
DURATION_LIMIT = f"{MAX_SECONDS // 60} minutos" if MAX_SECONDS % 60 == 0 else f"{MAX_SECONDS} segundos"
