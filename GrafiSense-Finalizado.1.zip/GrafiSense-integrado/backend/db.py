"""Banco local real: criado automaticamente, sem MySQL ou Docker."""
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DEFAULT_PATH = Path(__file__).resolve().parent / "data" / "grafisense.sqlite3"


class Database:
    def __init__(self, path=None):
        self.path = Path(path or os.environ.get("GRAFISENSE_DB", DEFAULT_PATH)).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS professionals (
                    id INTEGER PRIMARY KEY, name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY,
                    professional_id INTEGER NOT NULL REFERENCES professionals(id),
                    expires REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS patients (
                    id INTEGER PRIMARY KEY,
                    professional_id INTEGER NOT NULL REFERENCES professionals(id),
                    name TEXT NOT NULL,
                    phone TEXT NOT NULL, email TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS assessments (
                    id INTEGER PRIMARY KEY,
                    patient_id INTEGER NOT NULL REFERENCES patients(id),
                    created_at TEXT NOT NULL,
                    result_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS assessments_patient ON assessments(patient_id, id);
            """)
            self.remove_patient_cpf(db)
            db.execute("CREATE INDEX IF NOT EXISTS patients_professional ON patients(professional_id, id)")

    @staticmethod
    def remove_patient_cpf(db):
        """Migra o esquema anterior sem perder IDs ou referências das avaliações.

        A coluna fazia parte de UNIQUE e exige reconstruir a tabela. Toda a
        alteração é atômica; uma falha mantém a tabela anterior intacta.
        """
        columns = {row["name"] for row in db.execute("PRAGMA table_info(patients)")}
        if "cpf" not in columns:
            return
        if columns != {"id", "professional_id", "name", "cpf", "phone", "email"}:
            raise RuntimeError("A tabela de pacientes tem campos diferentes da versão anterior. A migração foi interrompida para preservar esses dados.")
        db.execute("PRAGMA foreign_keys=OFF")
        db.execute("PRAGMA secure_delete=ON")
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("""CREATE TABLE patients_without_cpf (
                id INTEGER PRIMARY KEY,
                professional_id INTEGER NOT NULL REFERENCES professionals(id),
                name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL
            )""")
            db.execute("""INSERT INTO patients_without_cpf(id,professional_id,name,phone,email)
                SELECT id,professional_id,name,phone,email FROM patients""")
            db.execute("DROP TABLE patients")
            db.execute("ALTER TABLE patients_without_cpf RENAME TO patients")
            if db.execute("PRAGMA foreign_key_check").fetchone() is not None:
                raise RuntimeError("O banco contém referências inconsistentes. A remoção do CPF foi revertida; confira o banco antes de atualizar.")
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.execute("PRAGMA foreign_keys=ON")
        # Libera o WAL da migração quando não há outro leitor ativo.
        db.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()


def person_dto(row):
    return {"id": str(row["id"]), **{k: row[k] or "" for k in ("name", "phone", "email")}}


def professional_dto(row):
    return {"id": str(row["id"]), "name": row["name"], "email": row["email"]}
