import hashlib
import hmac
import re
import secrets
import time
from threading import Lock
from fastapi import HTTPException

COOKIE = "grafisense_session"
SESSION_SECONDS = 8 * 60 * 60


def digits(value):
    return re.sub(r"\D", "", value)


def validate_person(body, professional=False):
    keys = ("name", "email") if professional else ("name", "phone", "email")
    person = {k: str(body.get(k) or "").strip() for k in keys}
    person["email"] = person["email"].lower()
    if not professional:
        person["phone"] = digits(person["phone"])
    errors = {}
    if len(person["name"].split()) < 2 or len(person["name"]) > 120:
        errors["name"] = "Informe o nome completo, com até 120 caracteres."
    if not professional and len(person["phone"]) not in (10, 11):
        errors["phone"] = "Informe o DDD e o telefone."
    if len(person["email"]) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", person["email"]):
        errors["email"] = "Informe um e-mail válido."
    if errors:
        raise HTTPException(422, {"message": "Confira os campos destacados.", "fields": errors})
    return person


def hash_password(password):
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        raise HTTPException(422, {"message": "Confira a senha.", "fields": {"password": "Use uma senha de 8 a 128 caracteres."}})
    salt = secrets.token_hex(16)
    key = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64)
    return f"scrypt${salt}${key.hex()}"


def verify_password(password, stored):
    if not isinstance(password, str) or len(password) > 128:
        return False
    try:
        algorithm, salt, encoded = stored.split("$")
        if algorithm != "scrypt":
            return False
        key = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64)
        return hmac.compare_digest(key.hex(), encoded)
    except (ValueError, TypeError):
        return False


def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


class LoginLimiter:
    def __init__(self):
        self.attempts = {}
        self.lock = Lock()

    def check(self, address):
        now = time.time()
        with self.lock:
            self.attempts = {key: val for key, val in self.attempts.items() if val[1] > now}
            count, until = self.attempts.get(address, (0, now + 900))
            if count >= 20:
                raise HTTPException(429, "Muitas tentativas. Aguarde 15 minutos.")
            self.attempts[address] = (count + 1, until)
