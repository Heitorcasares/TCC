import json
import logging
import os
import secrets
import sqlite3
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

from fastapi import Body, Depends, FastAPI, File, HTTPException, Request, Response, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .db import Database, person_dto, professional_dto
from .media import IMAGE_BYTES, VIDEO_BYTES, VIDEO_EXTENSIONS, VIDEO_FORMATS
from .prehension import public_hand_result
from .security import COOKIE, SESSION_SECONDS, LoginLimiter, hash_password, token_hash, validate_person, verify_password

ROOT = Path(__file__).resolve().parents[1]
logger = logging.getLogger("grafisense")
MAX_UPLOAD = VIDEO_BYTES + IMAGE_BYTES + 2 * 1024 * 1024


class RequestGuard:
    """Limita uploads inclusive sem Content-Length; verifica origem das gravações."""
    def __init__(self, app, origins):
        self.app, self.origins = app, origins

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope["headers"])
        mutation = scope["method"] not in ("GET", "HEAD", "OPTIONS")
        origin = headers.get(b"origin", b"").decode()
        if mutation and origin and origin not in self.origins:
            return await JSONResponse({"message": "Origem não autorizada."}, 403)(scope, receive, send)
        limit = MAX_UPLOAD if b"multipart/form-data" in headers.get(b"content-type", b"") else 16384
        try:
            length = int(headers.get(b"content-length", b"0"))
        except ValueError:
            return await JSONResponse({"message": "Tamanho de requisição inválido."}, 400)(scope, receive, send)
        if length > limit:
            return await JSONResponse({"message": "Arquivo ou requisição grande demais."}, 413)(scope, receive, send)
        total = 0

        async def limited_receive():
            nonlocal total
            message = await receive()
            total += len(message.get("body", b""))
            if total > limit:
                raise HTTPException(413, "Arquivo ou requisição grande demais.")
            return message

        async def secure_send(message):
            if message["type"] == "http.response.start":
                message.setdefault("headers", []).extend([(b"x-content-type-options", b"nosniff"), (b"cache-control", b"no-store")])
            await send(message)
        await self.app(scope, limited_receive, secure_send)


def create_app(db_path=None):
    app = FastAPI(title="GrafiSense", version="1.3.0")
    app.state.db = Database(db_path)
    app.state.analysis_lock = Lock()
    app.state.limiter = LoginLimiter()
    port = os.environ.get("PORT", "8000")
    origins = {f"http://{host}:{p}" for host in ("localhost", "127.0.0.1") for p in (port, "5173")}
    app.add_middleware(RequestGuard, origins=origins)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "testserver"])

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request, error):
        return JSONResponse(error.detail if isinstance(error.detail, dict) else {"message": str(error.detail)}, status_code=error.status_code)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, error):
        return JSONResponse({"message": "Requisição inválida. Confira os campos e arquivos enviados."}, status_code=422)

    @app.exception_handler(Exception)
    async def unexpected_error(request, error):
        logger.exception("Falha interna na API", exc_info=error)
        return JSONResponse({"message": "O servidor encontrou um erro. Consulte o terminal para os detalhes."}, status_code=500)

    def current_user(request: Request):
        token = request.cookies.get(COOKIE, "")
        with app.state.db.connect() as db:
            row = db.execute("SELECT p.* FROM professionals p JOIN sessions s ON s.professional_id=p.id WHERE s.token_hash=? AND s.expires>?", (token_hash(token), time.time())).fetchone()
        if row is None:
            raise HTTPException(401, "Entre na sua conta para continuar.")
        return row

    def start_session(request, response, user_id):
        token = secrets.token_urlsafe(32)
        with app.state.db.connect() as db:
            db.execute("DELETE FROM sessions WHERE expires<=? OR token_hash=?", (time.time(), token_hash(request.cookies.get(COOKIE, ""))))
            db.execute("INSERT INTO sessions VALUES(?,?,?)", (token_hash(token), user_id, time.time() + SESSION_SECONDS))
        response.set_cookie(COOKIE, token, max_age=SESSION_SECONDS, httponly=True, samesite="strict", secure=False, path="/")

    def own_patient(patient_id, user_id):
        with app.state.db.connect() as db:
            row = db.execute("SELECT * FROM patients WHERE id=? AND professional_id=?", (patient_id, user_id)).fetchone()
        if row is None:
            raise HTTPException(404, "Paciente não encontrado na sua conta.")
        return row

    def duplicate(error):
        if "professionals.email" not in str(error):
            raise error
        raise HTTPException(409, {"message": "Já existe uma conta com este e-mail.", "fields": {"email": "Este e-mail já foi cadastrado."}})

    @app.get("/api/health")
    def health():
        with app.state.db.connect() as db:
            db.execute("SELECT 1")
        return {"ok": True, "database": "sqlite", "analysis": "sob demanda"}

    @app.post("/api/auth/register", status_code=201)
    def register(request: Request, response: Response, body: dict = Body(...)):
        app.state.limiter.check(request.client.host)
        person = validate_person(body, professional=True)
        password_hash = hash_password(body.get("password"))
        try:
            with app.state.db.connect() as db:
                cursor = db.execute("INSERT INTO professionals(name,email,password_hash) VALUES(?,?,?)", (person["name"], person["email"], password_hash))
                user_id = cursor.lastrowid
        except sqlite3.IntegrityError as error:
            duplicate(error)
        start_session(request, response, user_id)
        return {**person, "id": str(user_id)}

    @app.post("/api/auth/login")
    def login(request: Request, response: Response, body: dict = Body(...)):
        app.state.limiter.check(request.client.host)
        email = str(body.get("email") or "").strip().lower()
        with app.state.db.connect() as db:
            row = db.execute("SELECT * FROM professionals WHERE email=?", (email,)).fetchone()
        stored = row["password_hash"] if row else f"scrypt${'0' * 32}${'0' * 128}"
        valid = verify_password(body.get("password"), stored)
        if not row or not valid:
            raise HTTPException(401, "E-mail ou senha incorretos.")
        start_session(request, response, row["id"])
        return professional_dto(row)

    @app.get("/api/auth/me")
    def me(user=Depends(current_user)):
        return professional_dto(user)

    @app.post("/api/auth/logout")
    def logout(request: Request, response: Response):
        with app.state.db.connect() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(request.cookies.get(COOKIE, "")),))
        response.delete_cookie(COOKIE, path="/", httponly=True, samesite="strict")
        return {"ok": True}

    @app.put("/api/professional")
    def update(body: dict = Body(...), user=Depends(current_user)):
        person = validate_person(body, professional=True)
        try:
            with app.state.db.connect() as db:
                db.execute("UPDATE professionals SET name=?,email=? WHERE id=?", (person["name"], person["email"], user["id"]))
        except sqlite3.IntegrityError as error:
            duplicate(error)
        return {**person, "id": str(user["id"])}

    @app.get("/api/patients")
    def patients(user=Depends(current_user)):
        with app.state.db.connect() as db:
            rows = db.execute("SELECT * FROM patients WHERE professional_id=? ORDER BY id", (user["id"],)).fetchall()
        return [person_dto(row) for row in rows]

    @app.post("/api/patients", status_code=201)
    def create_patient(body: dict = Body(...), user=Depends(current_user)):
        person = validate_person(body)
        with app.state.db.connect() as db:
            cursor = db.execute("INSERT INTO patients(professional_id,name,phone,email) VALUES(?,?,?,?)", (user["id"], person["name"], person["phone"], person["email"]))
            patient_id = cursor.lastrowid
        return {**person, "id": str(patient_id)}

    @app.get("/api/assessments")
    def all_assessments(user=Depends(current_user)):
        with app.state.db.connect() as db:
            rows = db.execute("SELECT a.* FROM assessments a JOIN patients p ON a.patient_id=p.id WHERE p.professional_id=? ORDER BY a.id DESC", (user["id"],)).fetchall()
        return [assessment_dto(row) for row in rows]

    @app.get("/api/patients/{patient_id}/assessments")
    def patient_assessments(patient_id: int, user=Depends(current_user)):
        own_patient(patient_id, user["id"])
        with app.state.db.connect() as db:
            rows = db.execute("SELECT * FROM assessments WHERE patient_id=? ORDER BY id DESC", (patient_id,)).fetchall()
        return [assessment_dto(row) for row in rows]

    @app.post("/api/patients/{patient_id}/assessments", status_code=201)
    async def analyze(patient_id: int, image: UploadFile | None = File(None), video: UploadFile | None = File(None), user=Depends(current_user)):
        own_patient(patient_id, user["id"])
        if not image and not video:
            raise HTTPException(422, "Selecione uma fotografia e/ou um vídeo para analisar.")
        if not app.state.analysis_lock.acquire(blocking=False):
            raise HTTPException(409, "Já existe uma análise em andamento. Aguarde a conclusão e tente novamente.")
        try:
            with tempfile.TemporaryDirectory(prefix="grafisense-") as folder:
                image_path = await save_upload(image, folder, "image") if image else None
                video_path = await save_upload(video, folder, "video") if video else None
                result = await run_in_threadpool(analyze_files, image_path, video_path)
            created = datetime.now(timezone.utc).isoformat()
            with app.state.db.connect() as db:
                cursor = db.execute("INSERT INTO assessments(patient_id,created_at,result_json) VALUES(?,?,?)", (patient_id, created, json.dumps(result, ensure_ascii=False, allow_nan=False)))
                assessment_id = cursor.lastrowid
            return {"id": str(assessment_id), "patientId": str(patient_id), "createdAt": created, **result}
        except ValueError as error:
            raise HTTPException(422, str(error)) from error
        except (ImportError, RuntimeError) as error:
            logger.exception("Falha ao carregar o processamento")
            raise HTTPException(503, "Não foi possível carregar os módulos de análise. No Linux, execute bash instalar.sh; no Windows, instalar.bat. Confira os detalhes no terminal.") from error
        finally:
            app.state.analysis_lock.release()
            for upload in (image, video):
                if upload:
                    await upload.close()

    dist = ROOT / "dist"
    if (dist / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/favicon.svg", include_in_schema=False)
    def favicon():
        return FileResponse(ROOT / "public" / "favicon.svg")

    @app.get("/", include_in_schema=False)
    def index():
        if not (dist / "index.html").is_file():
            raise HTTPException(503, "Interface não compilada. Execute npm run build.")
        return FileResponse(dist / "index.html")

    return app


def assessment_dto(row):
    result = json.loads(row["result_json"])
    result["hands"] = public_hand_result(result.get("hands"))
    if result["hands"] and result["hands"]["status"] == "legacy":
        result["status"] = "partial" if (result.get("writing") or {}).get("status") == "ok" else "insufficient"
    return {"id": str(row["id"]), "patientId": str(row["patient_id"]), "createdAt": row["created_at"], **result}


async def save_upload(upload, folder, kind):
    suffix = Path(upload.filename or "").suffix.lower()
    allowed = {".jpg", ".jpeg", ".png", ".webp"} if kind == "image" else VIDEO_EXTENSIONS
    if suffix not in allowed:
        raise ValueError(f"Use imagem JPG/PNG/WebP ou vídeo {VIDEO_FORMATS}.")
    limit = IMAGE_BYTES if kind == "image" else VIDEO_BYTES
    path = Path(folder) / (kind + suffix)
    total = 0
    with path.open("wb") as output:
        while chunk := await upload.read(1024 * 1024):
            total += len(chunk)
            if total > limit:
                raise HTTPException(413, f"O arquivo excede o limite de {limit // 1024 // 1024} MB.")
            output.write(chunk)
    if not total:
        raise ValueError("O arquivo está vazio.")
    return path


def analyze_files(image_path, video_path):
    from threadpoolctl import threadpool_limits
    import cv2
    cv2.setNumThreads(1)
    # Bibliotecas e modelo só são carregados na primeira análise.
    with threadpool_limits(limits=1):
        if image_path:
            from .writing import analyze_writing
            writing = analyze_writing(image_path)
        else:
            writing = None
        if video_path:
            from .hands import analyze_hands
            hands = analyze_hands(video_path)
        else:
            hands = None
    outcomes = [item for item in (writing, hands) if item]
    good = sum(item["status"] == "ok" for item in outcomes)
    return {"status": "completed" if good == len(outcomes) else "partial" if good else "insufficient", "writing": writing, "hands": hands}
