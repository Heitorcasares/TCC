"""Amostra todo o vídeo, com memória e quantidade de inferências limitadas."""
import random
import math
import time
from pathlib import Path

from .media import DURATION_LIMIT, MAX_SECONDS, MAX_FRAMES, MAX_PROCESSING_SECONDS, THUMBNAIL_MAX_SIDE
from .prehension import estimate_posture, summarize_postures
from .video_timing import VideoTiming


class VideoSamples:
    """Reservatório reprodutível: início, fim e amostra dos quadros intermediários.

    Recebe no máximo cerca de um quadro por segundo. Não depende da duração
    declarada pelo contêiner, que pode estar ausente em gravações WebM.
    """
    def __init__(self, limit):
        if limit < 3:
            raise ValueError("A amostragem precisa permitir pelo menos três quadros.")
        self.limit = limit
        self.first = self.last = None
        self.middle = []
        self.seen_middle = 0
        self.rng = random.Random(0)
        self.candidates = 0

    def add(self, position, frame):
        item = (position, frame)
        self.candidates += 1
        if self.first is None:
            self.first = item
            return
        if self.last is not None:
            self.seen_middle += 1
            capacity = self.limit - 2
            if len(self.middle) < capacity:
                self.middle.append(self.last)
            else:
                index = self.rng.randrange(self.seen_middle)
                if index < capacity:
                    self.middle[index] = self.last
        self.last = item

    def frames(self):
        return sorted([item for item in [self.first, *self.middle, self.last] if item is not None], key=lambda item: item[0])


def analyze_hands(path):
    import cv2
    import mediapipe as mp
    import numpy as np

    started = time.monotonic()
    def check_time():
        if time.monotonic() - started > MAX_PROCESSING_SECONDS:
            raise ValueError(f"O processamento ultrapassou {MAX_PROCESSING_SECONDS} segundos. Envie um vídeo mais curto ou com resolução menor.")

    capture = cv2.VideoCapture(str(path))
    try:
        if not capture.isOpened():
            raise ValueError("Não foi possível decodificar o vídeo. O conteúdo pode estar corrompido ou usar um codec incompatível. Exporte como MP4 com vídeo H.264 e tente novamente.")
        fps = capture.get(cv2.CAP_PROP_FPS)
        timing = VideoTiming(fps)
        count = capture.get(cv2.CAP_PROP_FRAME_COUNT)
        width, height = capture.get(cv2.CAP_PROP_FRAME_WIDTH), capture.get(cv2.CAP_PROP_FRAME_HEIGHT)
        if not np.isfinite(width) or not np.isfinite(height) or width <= 0 or height <= 0 or width * height > 3840 * 2160:
            raise ValueError("Use vídeo de até 4K, preferencialmente 640 × 480.")
        metadata_duration = count / timing.fps if timing.fps is not None and np.isfinite(count) and count > 0 else None
        if metadata_duration and metadata_duration < 86400 and metadata_duration > MAX_SECONDS + .5:
            raise ValueError(f"O vídeo deve ter no máximo {DURATION_LIMIT}. Recorte-o e tente novamente.")
        codec_number = capture.get(cv2.CAP_PROP_FOURCC)
        codec_int = int(codec_number) if np.isfinite(codec_number) else 0
        codec = "".join(chr((codec_int >> (8 * i)) & 0xff) for i in range(4)).strip("\x00 ")
        if not codec.isprintable():
            codec = ""
        info = {"extension": Path(path).suffix.lstrip(".").upper(), "codec": codec or None, "width": int(width), "height": int(height)}
        next_sample_second = 0
        samples, decoded = VideoSamples(MAX_FRAMES), 0
        while True:
            check_time()
            if not capture.grab():
                break
            position = timing.position(decoded, capture.get(cv2.CAP_PROP_POS_MSEC) if timing.fps is None else None)
            if position > MAX_SECONDS + .5:
                raise ValueError(f"O vídeo deve ter no máximo {DURATION_LIMIT}.")
            if position + 1e-6 >= next_sample_second:
                ok, frame = capture.retrieve()
                if not ok or frame is None:
                    raise ValueError("Não foi possível ler os quadros do vídeo. Exporte o arquivo novamente.")
                ratio = min(1, THUMBNAIL_MAX_SIDE / max(frame.shape[:2]))
                if ratio < 1:
                    frame = cv2.resize(frame, (max(1, round(frame.shape[1] * ratio)), max(1, round(frame.shape[0] * ratio))))
                samples.add(decoded, frame)
                next_sample_second = math.floor(position + 1e-6) + 1
            decoded += 1
        if not decoded:
            raise ValueError("O vídeo não contém quadros legíveis.")
        duration, observed_fps = timing.finish(decoded)
        if duration > MAX_SECONDS + .5:
            raise ValueError(f"O vídeo deve ter no máximo {DURATION_LIMIT}.")
        info.update(fps=round(observed_fps, 3), timingMethod=timing.method, durationEstimated=timing.method == "timestamps")
    finally:
        capture.release()

    observations = []
    selected = samples.frames()
    with mp.solutions.hands.Hands(static_image_mode=True, max_num_hands=2, model_complexity=1, min_detection_confidence=.6) as detector:
        for _, frame in selected:
            check_time()
            results = detector.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            hands = results.multi_hand_landmarks or []
            if not hands:
                observations.append({"label": None, "reason": "no_hand"})
            elif len(hands) > 1:
                observations.append({"label": None, "reason": "multiple_hands"})
            elif hands:
                visible = hands[0].landmark
                worlds = results.multi_hand_world_landmarks or []
                if (len(visible) != 21 or len(worlds) != 1
                        or any(not math.isfinite(point.z) or not 0 <= point.x <= 1 or not 0 <= point.y <= 1 for point in visible)):
                    observations.append({"label": None, "reason": "incomplete_hand"})
                else:
                    observations.append(estimate_posture([[point.x, point.y, point.z] for point in worlds[0].landmark]))
    result = summarize_postures(observations, len(selected), duration)
    result["video"] = info
    result["availableSamples"] = samples.candidates
    return result
