"""Leitura de tempo sem exigir FPS confiável de gravações do navegador."""
import math
from collections import deque
from statistics import median


class VideoTiming:
    def __init__(self, reported_fps):
        self.fps = float(reported_fps) if math.isfinite(reported_fps) and .1 <= reported_fps <= 120 else None
        self.method = "fps" if self.fps is not None else "timestamps"
        self.origin = None
        self.last_time = 0.0
        self.intervals = deque(maxlen=30)

    def position(self, frame_index, milliseconds=None):
        if self.fps is not None:
            return frame_index / self.fps
        if milliseconds is None or not math.isfinite(milliseconds):
            raise ValueError("Não foi possível ler o tempo dos quadros deste vídeo. Exporte-o como MP4 com vídeo H.264 e tente novamente.")
        seconds = milliseconds / 1000.0
        if self.origin is None:
            self.origin = seconds
        elapsed = seconds - self.origin
        if elapsed < self.last_time - .001:
            raise ValueError("Os tempos dos quadros deste vídeo estão inconsistentes. Exporte-o novamente e tente analisar.")
        elapsed = max(elapsed, self.last_time)
        interval = elapsed - self.last_time
        if interval > 1e-6:
            self.intervals.append(interval)
        self.last_time = elapsed
        return elapsed

    def finish(self, decoded_frames):
        if self.fps is not None:
            return decoded_frames / self.fps, self.fps
        if self.last_time <= 0 or not self.intervals:
            # Não inventa 30 FPS para um arquivo sem informações de tempo.
            raise ValueError("O vídeo não tem informações de tempo suficientes para determinar sua duração. Exporte-o como MP4 com vídeo H.264 e tente novamente.")
        # O último quadro não informa por quanto tempo ficou visível. Estima
        # essa fração pela mediana dos intervalos recentes, sem depender de FPS.
        duration = self.last_time + median(self.intervals)
        observed_fps = (decoded_frames - 1) / self.last_time
        return duration, observed_fps
