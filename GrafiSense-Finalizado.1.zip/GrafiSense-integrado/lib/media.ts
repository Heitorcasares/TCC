import settings from "@/config/media.json";

export const MEDIA = settings;
export const VIDEO_BYTES = MEDIA.maxVideoMB * 1024 * 1024;
export const IMAGE_BYTES = MEDIA.maxImageMB * 1024 * 1024;
export const VIDEO_FORMATS = MEDIA.videoExtensions.map(value => value.toUpperCase()).join(", ");
export const VIDEO_ACCEPT = MEDIA.videoExtensions.map(value => "." + value).join(",");
export const DURATION_LIMIT = MEDIA.maxVideoSeconds % 60 === 0 ? `${MEDIA.maxVideoSeconds / 60} minutos` : `${MEDIA.maxVideoSeconds} segundos`;
export const extensionOf = (name: string) => name.split(".").pop()?.toLowerCase() || "";
export const durationLabel = (seconds: number) => `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
export const sizeLabel = (bytes: number) => bytes < 1024 ? `${bytes} B` : `${(bytes / (bytes < 1024 * 1024 ? 1024 : 1024 * 1024)).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} ${bytes < 1024 * 1024 ? "KB" : "MB"}`;

export type VideoDetails = { duration: number | null; width: number | null; height: number | null; previewAvailable: boolean };

export function inspectVideo(file: File): Promise<VideoDetails> {
  // Alguns contêineres são aceitos pelo servidor, mas não pelo navegador.
  return new Promise(resolve => {
    const video = document.createElement("video");
    const url = URL.createObjectURL(file);
    let done = false;
    const finish = (previewAvailable: boolean) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const details = {
        duration: Number.isFinite(video.duration) && video.duration > 0 ? video.duration : null,
        width: video.videoWidth || null, height: video.videoHeight || null, previewAvailable,
      };
      video.onloadedmetadata = null; video.onerror = null;
      video.removeAttribute("src"); video.load(); URL.revokeObjectURL(url);
      resolve(details);
    };
    const timer = window.setTimeout(() => finish(false), 5000);
    video.preload = "metadata";
    video.onloadedmetadata = () => finish(true);
    video.onerror = () => finish(false);
    video.src = url;
  });
}
