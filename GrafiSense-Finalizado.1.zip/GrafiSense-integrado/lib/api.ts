import type { Assessment, Draft, Patient, PatientForm, Professional } from './grafisense';
export class ApiError extends Error {
  constructor(message: string, public status: number, public fields: Record<string, string> = {}) { super(message); }
}
async function request<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  let response: Response;
  try { response = await fetch('/api' + path, { method, credentials: 'same-origin', headers: body instanceof FormData ? {} : { 'Content-Type': 'application/json' }, ...(body === undefined ? {} : { body: body instanceof FormData ? body : JSON.stringify(body) }) }); }
  catch { throw new ApiError('Não foi possível conectar ao servidor. Verifique se a API está em execução.', 0); }
  let data;
  try { data = await response.json(); } catch { throw new ApiError('Resposta inválida do servidor. Verifique a configuração da API.', response.status); }
  if (!response.ok) throw new ApiError(data.message || 'Não foi possível concluir a operação.', response.status, data.fields);
  return data;
}
export const api = {
  me: () => request<Professional>('/auth/me'),
  register: (person: Professional & { password: string }) => request<Professional>('/auth/register', 'POST', person),
  login: (email: string, password: string) => request<Professional>('/auth/login', 'POST', { email, password }),
  logout: () => request('/auth/logout', 'POST', {}),
  updateProfessional: (person: Professional) => request<Professional>('/professional', 'PUT', person),
  patients: () => request<Patient[]>('/patients'),
  createPatient: (person: PatientForm) => request<Patient>('/patients', 'POST', person),
  assessments: () => request<Assessment[]>('/assessments'),
  analyze: (patientId: string, draft: Draft) => {
    const data = new FormData();
    if (draft.image) data.append('image', draft.image);
    if (draft.video) data.append('video', draft.video);
    return request<Assessment>(`/patients/${encodeURIComponent(patientId)}/assessments`, 'POST', data);
  },
};
