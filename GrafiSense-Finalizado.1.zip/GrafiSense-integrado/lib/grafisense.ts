export type Patient = { id: string; name: string; email: string; phone: string };
export type PatientForm = Omit<Patient, "id">;
export type Professional = { id?: string; name: string; email: string };
export type Draft = { video?: File; image?: File };
export type WritingMetrics = { legibility: number; letterSize: number; alignment: number; spacing: number; strokeThickness: number };
export type WritingResult = { status: "ok" | "insufficient"; message: string; method: string; components: number; lines: number; metrics: WritingMetrics | null };
export type HandsResult = {
  status: "ok" | "no_hand" | "inconclusive" | "legacy";
  message: string; method: string; experimental: boolean;
  label: "Palmar" | "Pinça" | null;
  sampledFrames: number; detectedFrames: number; classifiedFrames: number;
  uncertainFrames: number; multipleHandFrames: number; durationSeconds: number;
  distribution: { label: "Palmar" | "Pinça"; frames: number; percent: number }[];
  video?: { extension: string; codec: string | null; width: number; height: number; fps: number; timingMethod?: "fps" | "timestamps"; durationEstimated?: boolean };
  availableSamples?: number;
  quality?: {
    classifiedPercent: number; predominantPercent: number; longestStableRun: number;
    issues: { code: string; frames: number; message: string }[];
  };
};
export type Assessment = { id: string; patientId: string; createdAt: string; status: "completed" | "partial" | "insufficient"; writing: WritingResult | null; hands: HandsResult | null };
export const emptyProfessional: Professional = { name: "", email: "" };
export const emptyPatientForm: PatientForm = { name: "", email: "", phone: "" };
export const digits = (value: string) => value.replace(/\D/g, "");
export const initials = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(p => p[0]).join("").toUpperCase();
export const normalize = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
export function maskPhone(value: string) {
  const n = digits(value).slice(0, 11);
  if (n.length <= 2) return n;
  return `(${n.slice(0, 2)}) ${n.slice(2)}`.replace(n.length > 10 ? /(\d{5})(\d)/ : /(\d{4})(\d)/, "$1-$2");
}
export function validatePerson(person: PatientForm | Professional, professional = false) {
  const errors: Record<string, string> = {};
  if (person.name.trim().split(/\s+/).length < 2) errors.name = "Informe o nome completo.";
  if (!professional) {
    if (!("phone" in person) || ![10, 11].includes(digits(person.phone).length)) errors.phone = "Informe o DDD e o telefone.";
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(person.email.trim())) errors.email = "Informe um e-mail válido.";
  return errors;
}

