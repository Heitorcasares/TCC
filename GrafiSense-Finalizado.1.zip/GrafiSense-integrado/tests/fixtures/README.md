# Gravação de teste

`camera-variable.webm` foi gerado em 28/10/2026 com Chromium e MediaRecorder,
por meio de um canvas de 320×240 com texto, sem imagem de pessoas, câmera física
ou áudio. O canvas solicitou 30 quadros com intervalos irregulares e a gravação
foi formada pela concatenação dos blocos de MediaRecorder.

No OpenCV 4.11.0, o arquivo informa FPS=1000 e contagem de quadros inválida,
mas contém 30 quadros legíveis com timestamps de 0 a 3195 ms. O formato de
arquivo é WebM/VP8. A versão 1.2 rejeitava o vídeo com o mesmo erro de FPS
reportado pelo usuário. A correção usa os timestamps e avalia quatro amostras.

O arquivo serve para testar leitura, temporização e integração de upload.
Não é um exemplo de preensão ou de validação do detector de mãos.
