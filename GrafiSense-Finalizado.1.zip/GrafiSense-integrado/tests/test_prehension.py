"""Testes de software com pontos sintéticos; não medem acurácia em pessoas."""
import json
from types import SimpleNamespace

import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.hands import analyze_hands
from backend.prehension import METHOD, estimate_posture, summarize_postures


def pose(kind):
    p = np.zeros((21, 3))
    p[0] = (0, -1, 0)
    p[1:5] = [(-.4, -.6, 0), (-.8, -.3, 0), (-1, .1, 0), (-1.2, .45, 0)]
    for base, x in zip((5, 9, 13, 17), (-.5, -.17, .17, .5)):
        p[base:base + 4] = [(x, 0, 0), (x, .45, 0), (x, .8, 0), (x, 1.05, 0)]
        if kind in ("palmar", "pinch") or (kind == "two_extended" and base >= 13):
            p[base + 2:base + 4] = [(x, .4, -.35), (x, .12, -.25)]
    if kind in ("palmar", "pinch", "two_extended"):
        p[3:5] = [(-.4, -.1, -.1), (-.25, .05, -.15)]
    if kind == "pinch":
        p[6:9] = [(-.48, .5, 0), (-.28, .8, -.05), (-.1, .95, -.05)]
        p[3:5] = [(-.5, .4, 0), (-.18, .95, -.05)]
    return p


@pytest.mark.parametrize("kind,expected", [("palmar", "Palmar"), ("pinch", "Pinça"), ("open", None), ("two_extended", None)])
def test_posture_and_coordinate_invariance(kind, expected):
    points = pose(kind)
    assert estimate_posture(points)["label"] == expected
    # Mesmo esqueleto deslocado, escalado, rotacionado em 3D e espelhado.
    rotation, _ = np.linalg.qr(np.random.default_rng(42).normal(size=(3, 3)))
    for scale in (.03, 2.5):
        transformed = points @ rotation * scale + [3, -2, 7]
        assert estimate_posture(transformed)["label"] == expected
        transformed[:, 0] *= -1
        assert estimate_posture(transformed)["label"] == expected


@pytest.mark.parametrize("points", [np.zeros((21, 3)), np.ones((20, 3)), np.full((21, 3), np.nan)])
def test_invalid_landmarks_abstain(points):
    assert estimate_posture(points)["label"] is None


def test_missing_bone_abstains():
    points = pose("palmar")
    points[6] = points[5]
    assert estimate_posture(points)["label"] is None


@pytest.mark.parametrize("labels,sampled,expected", [
    ([], 5, "no_hand"),
    (["Palmar"] * 2, 2, "inconclusive"),
    (["Palmar"] * 3, 10, "inconclusive"),
    (["Palmar"] * 3 + [None] * 3, 6, "inconclusive"),
    (["Palmar"] * 3 + ["Pinça"] * 3, 6, "inconclusive"),
    (["Palmar"] * 4 + [None], 5, "ok"),
])
def test_aggregation_requires_clear_consistent_evidence(labels, sampled, expected):
    result = summarize_postures([{"label": label} for label in labels], sampled, sampled)
    assert result["status"] == expected
    assert result["label"] == ("Palmar" if expected == "ok" else None)
    assert result["classifiedFrames"] + result["uncertainFrames"] == result["detectedFrames"]
    assert all(item["label"] in ("Palmar", "Pinça") for item in result["distribution"])
    assert sum(item["percent"] for item in result["distribution"]) <= 100.01
    assert "probabilities" not in result and "confidence" not in result
    json.dumps(result, allow_nan=False)


@pytest.fixture
def clip(tmp_path):
    path = tmp_path / "input.mp4"
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (320, 240))
    assert writer.isOpened()
    for _ in range(50):
        writer.write(np.full((240, 320, 3), 255, np.uint8))
    writer.release()
    return path


def use_synthetic_detector(monkeypatch, kind, count=1):
    import mediapipe as mp
    world = SimpleNamespace(landmark=[SimpleNamespace(x=x, y=y, z=z) for x, y, z in pose(kind)])
    normalized = SimpleNamespace(landmark=[SimpleNamespace(x=.5, y=.5, z=0) for _ in range(21)])
    class Detector:
        def __init__(self, **kwargs):
            assert kwargs["max_num_hands"] == 2
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def process(self, frame):
            assert frame.shape[:2] == (240, 320)
            return SimpleNamespace(multi_hand_landmarks=[normalized] * count, multi_hand_world_landmarks=[world] * count)
    monkeypatch.setattr(mp.solutions.hands, "Hands", Detector)


@pytest.mark.parametrize("kind,expected", [("palmar", "Palmar"), ("pinch", "Pinça"), ("open", None)])
def test_video_pipeline_and_persisted_results_with_synthetic_landmarks(monkeypatch, tmp_path, clip, kind, expected):
    use_synthetic_detector(monkeypatch, kind)
    db_path = tmp_path / "pipeline.sqlite3"
    account = {"name": "Teste Geometria", "email": "geometry@example.com", "password": "teste-senha-123"}
    with TestClient(create_app(db_path)) as client:
        assert client.post("/api/auth/register", json=account).status_code == 201
        patient = client.post("/api/patients", json={"name": "Paciente Teste", "phone": "11999999999", "email": "responsavel@example.com"}).json()
        response = client.post(f"/api/patients/{patient['id']}/assessments", files={"video": ("video.mp4", clip.read_bytes(), "video/mp4")})
        assert response.status_code == 201, response.text
        saved = response.json()
        hands = saved["hands"]
        assert hands["method"] == METHOD
        assert hands["label"] == expected
        assert hands["status"] == ("ok" if expected else "inconclusive")
        assert hands["detectedFrames"] == hands["sampledFrames"] == 5
        assert client.get("/api/assessments").json() == [saved]
    with TestClient(create_app(db_path)) as restarted:
        restarted.post("/api/auth/login", json=account)
        assert restarted.get(f"/api/patients/{patient['id']}/assessments").json() == [saved]


def test_two_hands_do_not_select_arbitrary_person(monkeypatch, clip):
    use_synthetic_detector(monkeypatch, "palmar", count=2)
    result = analyze_hands(clip)
    assert result["status"] == "inconclusive"
    assert result["label"] is None
    assert result["multipleHandFrames"] == result["uncertainFrames"] == 5
