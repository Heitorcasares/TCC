"""Remoção real do CPF; persistência e isolamento dos demais dados."""
import json
import sqlite3

import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.db import Database
from backend.security import hash_password

PRO = {"name": "Teste Migração", "email": "migration@example.com", "password": "senha-teste-123"}
PATIENT = {"name": "Paciente Teste", "phone": "11999999999", "email": "responsavel@example.com"}
OLD_HAND = {"method": "geometria-preensao-v1", "experimental": True, "status": "ok", "label": "Palmar", "message": "Resultado anterior", "sampledFrames": 5, "detectedFrames": 5, "classifiedFrames": 5, "uncertainFrames": 0, "multipleHandFrames": 0, "durationSeconds": 5, "distribution": [{"label": "Palmar", "frames": 5, "percent": 100}, {"label": "Pinça", "frames": 0, "percent": 0}]}
OLD_RESULT = {"status": "completed", "writing": None, "hands": OLD_HAND}


def seed_old_database(path, orphan=False):
    with sqlite3.connect(path) as db:
        db.executescript("""
            CREATE TABLE professionals (id INTEGER PRIMARY KEY, name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL);
            CREATE TABLE patients (id INTEGER PRIMARY KEY,
                professional_id INTEGER NOT NULL REFERENCES professionals(id),
                name TEXT NOT NULL, cpf TEXT NOT NULL, phone TEXT NOT NULL,
                email TEXT NOT NULL, UNIQUE(professional_id,cpf));
            CREATE TABLE assessments (id INTEGER PRIMARY KEY,
                patient_id INTEGER NOT NULL REFERENCES patients(id),
                created_at TEXT NOT NULL, result_json TEXT NOT NULL);
        """)
        db.execute("INSERT INTO professionals VALUES(7,?,?,?)", (PRO["name"], PRO["email"], hash_password(PRO["password"])))
        db.execute("INSERT INTO patients VALUES(41,7,?,?,?,?)", (PATIENT["name"], "52998224725", PATIENT["phone"], PATIENT["email"]))
        db.execute("INSERT INTO patients VALUES(73,7,?,?,?,?)", ("Outro Paciente", "11144477735", PATIENT["phone"], PATIENT["email"]))
        db.execute("INSERT INTO assessments VALUES(83,?,?,?)", (999 if orphan else 41, "2026-10-21T12:00:00+00:00", json.dumps(OLD_RESULT)))


@pytest.mark.parametrize("extra", [{}, {"cpf": "52998224725"}, {"cpf": "inválido"}, {"cpf": None}])
def test_patient_contract_does_not_require_expose_or_store_cpf(tmp_path, extra):
    path = tmp_path / "fresh.sqlite3"
    with TestClient(create_app(path)) as client:
        assert client.post("/api/auth/register", json=PRO).status_code == 201
        response = client.post("/api/patients", json={**PATIENT, **extra})
        assert response.status_code == 201, response.text
        patient = response.json()
        assert set(patient) == {"id", "name", "phone", "email"}
        assert client.get("/api/patients").json() == [patient]
        with client.app.state.db.connect() as db:
            assert "cpf" not in {row["name"] for row in db.execute("PRAGMA table_info(patients)")}
    with TestClient(create_app(path)) as client:
        client.post("/api/auth/login", json=PRO)
        assert client.get("/api/patients").json() == [patient]


def test_migration_preserves_ids_contacts_assessments_and_sessions(tmp_path):
    path = tmp_path / "old.sqlite3"
    seed_old_database(path)
    with TestClient(create_app(path)) as client:
        assert client.post("/api/auth/login", json=PRO).status_code == 200
        previous = client.get("/api/patients").json()
        assert previous == [{"id": "41", **PATIENT}, {"id": "73", **PATIENT, "name": "Outro Paciente"}]
        result = client.get("/api/patients/41/assessments").json()[0]
        assert result["id"] == "83" and result["hands"] == OLD_HAND
        # Contatos compartilhados ou nomes iguais não identificam uma pessoa.
        added = client.post("/api/patients", json=PATIENT)
        assert added.status_code == 201 and added.json()["id"] not in ("41", "73")
        patients = previous + [added.json()]
        cookie = client.cookies.get("grafisense_session")
        with client.app.state.db.connect() as db:
            assert db.execute("PRAGMA foreign_keys").fetchone()[0] == 1
            assert not db.execute("PRAGMA foreign_key_check").fetchall()
            assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            assert "cpf" not in {row["name"] for row in db.execute("PRAGMA table_info(patients)")}
            assert json.loads(db.execute("SELECT result_json FROM assessments WHERE id=83").fetchone()[0]) == OLD_RESULT
            with pytest.raises(sqlite3.IntegrityError):
                db.execute("INSERT INTO assessments(patient_id,created_at,result_json) VALUES(999,'x','{}')")
    # Reinícios repetidos não executam a migração novamente nem alteram IDs.
    for _ in range(2):
        with TestClient(create_app(path)) as client:
            client.cookies.set("grafisense_session", cookie)
            assert client.get("/api/patients").json() == patients
            assert client.get("/api/assessments").json() == [result]
            client.cookies.clear()
            client.post("/api/auth/register", json={**PRO, "email": f"other{_}@example.com"})
            assert client.get("/api/patients").json() == []
            assert client.get("/api/patients/41/assessments").status_code == 404


def test_failed_migration_rolls_back_instead_of_losing_data(tmp_path):
    path = tmp_path / "inconsistent.sqlite3"
    seed_old_database(path, orphan=True)
    with pytest.raises(RuntimeError, match="revertida"):
        Database(path)
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT cpf FROM patients WHERE id=41").fetchone()[0] == "52998224725"
        assert db.execute("SELECT COUNT(*) FROM patients").fetchone()[0] == 2
        assert db.execute("SELECT patient_id FROM assessments WHERE id=83").fetchone()[0] == 999
        assert not db.execute("SELECT name FROM sqlite_master WHERE name='patients_without_cpf'").fetchall()


def test_custom_patient_fields_are_not_silently_discarded(tmp_path):
    path = tmp_path / "custom.sqlite3"
    seed_old_database(path)
    with sqlite3.connect(path) as db:
        db.execute("ALTER TABLE patients ADD COLUMN notes TEXT")
        db.execute("UPDATE patients SET notes='Preservar'")
    with pytest.raises(RuntimeError, match="preservar"):
        Database(path)
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT notes FROM patients WHERE id=41").fetchone()[0] == "Preservar"
