"""Limites de mídia, formatos reais e amostragem de vídeos longos."""
import asyncio
from types import SimpleNamespace

import cv2
import numpy as np
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

import backend.app as app_module
import backend.hands as hands_module
from backend.app import create_app, save_upload
from backend.hands import analyze_hands, VideoSamples
from backend.media import MAX_FRAMES, MAX_SECONDS, VIDEO_BYTES


def write_clip(path, codec='mp4v', seconds=5, fps=10):
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*codec), fps, (320, 240))
    assert writer.isOpened(), f'Codec de teste indisponível: {codec}'
    for _ in range(int(seconds * fps)):
        writer.write(np.full((240, 320, 3), 255, np.uint8))
    writer.release()
    return path


@pytest.mark.parametrize('extension,codec', [('mp4','mp4v'),('mov','mp4v'),('m4v','mp4v'),('webm','VP80'),('avi','MJPG'),('mkv','mp4v')])
def test_supported_containers_are_decoded_and_saved(tmp_path, extension, codec):
    path = write_clip(tmp_path / ('clip.' + extension), codec)
    with TestClient(create_app(tmp_path / 'test.sqlite3')) as client:
        assert client.post('/api/auth/register',json={'name':'Profissional Teste','email':'video@example.com','password':'senha-teste-123'}).status_code == 201
        patient = client.post('/api/patients',json={'name':'Paciente Teste','phone':'11999999999','email':'paciente@example.com'}).json()
        response = client.post(f"/api/patients/{patient['id']}/assessments",files={'video':(path.name,path.read_bytes(),'application/octet-stream')})
        assert response.status_code == 201, response.text
        result = response.json()
        assert result['hands']['status'] == 'no_hand'
        assert result['hands']['durationSeconds'] == pytest.approx(5,.2)
        assert result['hands']['video']['extension'] == extension.upper()
        assert result['hands']['video']['width'] == 320
        assert result['hands']['video']['codec']
        assert client.get('/api/assessments').json() == [result]


def test_large_upload_is_streamed_past_previous_limit(tmp_path):
    class Upload:
        filename = 'maior-que-50MB.MKV'
        remaining = 51 * 1024 * 1024
        async def read(self, size):
            amount = min(size, self.remaining)
            self.remaining -= amount
            return b'x' * amount
    output = asyncio.run(save_upload(Upload(),tmp_path,'video'))
    assert output.stat().st_size == 51 * 1024 * 1024
    assert output.suffix == '.mkv'
    assert VIDEO_BYTES == 250 * 1024 * 1024


def test_size_limit_is_enforced_without_trusting_content_length(monkeypatch,tmp_path):
    monkeypatch.setattr(app_module,'VIDEO_BYTES',1024)
    class Upload:
        filename = 'too-large.mp4'
        async def read(self, size):
            return b'x' * 1025
    with pytest.raises(HTTPException) as error:
        asyncio.run(save_upload(Upload(),tmp_path,'video'))
    assert error.value.status_code == 413


def test_reservoir_covers_start_end_and_middle_with_bounded_memory():
    samples = VideoSamples(60)
    for i in range(300):
        samples.add(i, i)
        assert len(samples.middle) <= 58
    positions = [position for position,_ in samples.frames()]
    assert len(positions) == len(set(positions)) == 60
    assert positions[0] == 0 and positions[-1] == 299
    assert any(100 <= position <= 200 for position in positions)
    repeated = VideoSamples(60)
    for i in range(300): repeated.add(i, i)
    assert repeated.frames() == samples.frames()


def test_long_video_uses_limited_samples_from_whole_duration(tmp_path):
    path = write_clip(tmp_path/'long.mp4',seconds=75,fps=1)
    result = analyze_hands(path)
    assert result['durationSeconds'] == 75
    assert result['availableSamples'] == 75
    assert result['sampledFrames'] == MAX_FRAMES
    assert result['status'] == 'no_hand'


def test_over_duration_with_and_without_reliable_metadata(tmp_path,monkeypatch):
    path = write_clip(tmp_path/'too-long.mp4',seconds=MAX_SECONDS+1,fps=1)
    with pytest.raises(ValueError,match='no máximo'):
        analyze_hands(path)
    real_capture = cv2.VideoCapture
    class WithoutDuration:
        def __init__(self,path): self.inner = real_capture(path)
        def get(self,key): return 0 if key == cv2.CAP_PROP_FRAME_COUNT else self.inner.get(key)
        def __getattr__(self,name): return getattr(self.inner,name)
    monkeypatch.setattr(cv2,'VideoCapture',WithoutDuration)
    with pytest.raises(ValueError,match='no máximo'):
        analyze_hands(path)


def test_processing_timeout_is_enforced(tmp_path,monkeypatch):
    path = write_clip(tmp_path/'time.mp4',seconds=1)
    monkeypatch.setattr(hands_module,'MAX_PROCESSING_SECONDS',-1)
    with pytest.raises(ValueError,match='processamento ultrapassou'):
        analyze_hands(path)


def test_renaming_non_video_does_not_make_it_valid(tmp_path):
    path = tmp_path/'fake.mkv'
    path.write_bytes(b'arquivo sem conteudo de video')
    with pytest.raises(ValueError,match='decodificar'):
        analyze_hands(path)
