"""Regressão de WebM do MediaRecorder com FPS nominal incorreto."""
import json
from pathlib import Path

import cv2
import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.hands import analyze_hands
from backend.video_timing import VideoTiming
from test_video import write_clip

FIXTURE = Path(__file__).parent / 'fixtures/camera-variable.webm'


def test_real_mediarecorder_webm_with_1000_fps_is_accepted(tmp_path):
    capture = cv2.VideoCapture(str(FIXTURE))
    assert capture.isOpened()
    assert capture.get(cv2.CAP_PROP_FPS) == 1000
    capture.release()
    db = tmp_path/'timing.sqlite3'
    account = {'name':'Teste Gravação','email':'gravacao@example.com','password':'senha-teste-123'}
    with TestClient(create_app(db)) as client:
        assert client.post('/api/auth/register',json=account).status_code == 201
        patient = client.post('/api/patients',json={'name':'Paciente Teste','phone':'11999999999','email':'responsavel@example.com'}).json()
        response = client.post(f"/api/patients/{patient['id']}/assessments", files={'video':('gravacao-mao.webm',FIXTURE.read_bytes(),'video/webm')})
        assert response.status_code == 201, response.text
        record = response.json()
        hands = record['hands']
        assert hands['status'] == 'no_hand'
        assert hands['sampledFrames'] == 4
        assert 3.19 < hands['durationSeconds'] < 3.5
        assert hands['video']['timingMethod'] == 'timestamps'
        assert hands['video']['durationEstimated'] is True
        assert 8 < hands['video']['fps'] < 10
        json.dumps(record,allow_nan=False)
    with TestClient(create_app(db)) as restarted:
        restarted.post('/api/auth/login',json=account)
        assert restarted.get('/api/assessments').json() == [record]


@pytest.mark.parametrize('reported_fps',[0,float('nan'),1000])
def test_readable_timestamps_work_without_valid_fps(tmp_path,monkeypatch,reported_fps):
    path = write_clip(tmp_path/'timestamps.mp4')
    real_capture = cv2.VideoCapture
    class Capture:
        def __init__(self,path): self.inner = real_capture(path)
        def get(self,key): return reported_fps if key == cv2.CAP_PROP_FPS else self.inner.get(key)
        def __getattr__(self,name): return getattr(self.inner,name)
    monkeypatch.setattr(cv2,'VideoCapture',Capture)
    result = analyze_hands(path)
    assert result['durationSeconds'] == pytest.approx(5,.01)
    assert result['sampledFrames'] == 5
    assert result['video']['fps'] == pytest.approx(10,.01)


def test_over_duration_is_rejected_even_without_valid_fps(tmp_path,monkeypatch):
    path = write_clip(tmp_path/'too-long.mp4',seconds=301,fps=1)
    real_capture = cv2.VideoCapture
    class Capture:
        def __init__(self,path): self.inner = real_capture(path)
        def get(self,key): return 1000 if key == cv2.CAP_PROP_FPS else self.inner.get(key)
        def __getattr__(self,name): return getattr(self.inner,name)
    monkeypatch.setattr(cv2,'VideoCapture',Capture)
    with pytest.raises(ValueError,match='no máximo'):
        analyze_hands(path)


def test_timestamp_origin_can_be_nonzero_and_duplicate_pts_are_allowed():
    timing = VideoTiming(1000)
    observed = [timing.position(i,pts) for i,pts in enumerate([5000,5100,5100,5200,5500])]
    assert observed == pytest.approx([0,.1,.1,.2,.5])
    duration, fps = timing.finish(5)
    assert duration == pytest.approx(.6)
    assert fps == 8


@pytest.mark.parametrize('timestamp',[None,float('nan'),float('inf')])
def test_missing_timestamps_do_not_invent_a_frame_rate(timestamp):
    with pytest.raises(ValueError,match='tempo dos quadros'):
        VideoTiming(1000).position(0,timestamp)


def test_constant_timestamps_cannot_establish_duration():
    timing = VideoTiming(1000)
    for i in range(4): timing.position(i,0)
    with pytest.raises(ValueError,match='determinar sua duração'):
        timing.finish(4)


def test_reversed_timestamps_are_rejected():
    timing = VideoTiming(1000)
    timing.position(0,0); timing.position(1,100)
    with pytest.raises(ValueError,match='inconsistentes'):
        timing.position(2,50)
