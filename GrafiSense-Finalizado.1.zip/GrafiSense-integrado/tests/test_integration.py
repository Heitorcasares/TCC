import io
import json
import sqlite3
from pathlib import Path

import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from backend.app import create_app
from backend.prehension import METHOD
from backend.writing import analyze_writing

ROOT = Path(__file__).resolve().parents[1]
PRO = {"name": "Profissional Teste", "email": "teste@example.com", "password": "senha-teste-123"}
PATIENT = {"name": "Paciente Teste", "phone": "11999999999", "email": "responsavel@example.com"}


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path / "test.sqlite3")) as client:
        yield client


def account_patient(client):
    assert client.post("/api/auth/register", json=PRO).status_code == 201
    response = client.post("/api/patients", json=PATIENT)
    assert response.status_code == 201, response.text
    return response.json()["id"]


def test_registration_login_persistence_and_hash(tmp_path):
    path = tmp_path / "real.sqlite3"
    with TestClient(create_app(path)) as client:
        patient_id = account_patient(client)
        assert client.get("/api/health").json() == {"ok": True, "database": "sqlite", "analysis": "sob demanda"}
        response = client.put("/api/professional", json={**PRO, "name": "Profissional Atualizado"})
        assert response.json()["name"] == "Profissional Atualizado"
        assert client.post("/api/auth/logout").status_code == 200
        assert client.get("/api/patients").status_code == 401
    # Aplicação reiniciada: conexão e instância novas, mesmo arquivo SQLite.
    with TestClient(create_app(path)) as restarted:
        assert restarted.post("/api/auth/login", json={**PRO, "password": "errada"}).status_code == 401
        assert restarted.post("/api/auth/login", json=PRO).status_code == 200
        assert restarted.get("/api/patients").json()[0]["id"] == patient_id
        assert restarted.get("/api/auth/me").json()["name"] == "Profissional Atualizado"
    with sqlite3.connect(path) as db:
        stored = db.execute("SELECT password_hash FROM professionals").fetchone()[0]
        assert stored.startswith("scrypt$") and PRO["password"] not in stored


def test_auth_validation_duplicates_and_isolation(client):
    assert client.get("/api/assessments").status_code == 401
    assert client.post("/api/auth/register", json={**PRO, "password": "curta"}).status_code == 422
    patient_id = account_patient(client)
    assert client.post("/api/patients", json=PATIENT).status_code == 201
    assert client.post("/api/patients", json={**PATIENT, "phone": "123"}).status_code == 422
    assert client.post("/api/auth/register", json=PRO).status_code == 409
    assert client.post("/api/auth/register", json={**PRO, "email": "segunda@example.com"}).status_code == 201
    assert client.get("/api/patients").json() == []
    assert client.get(f"/api/patients/{patient_id}/assessments").status_code == 404
    assert client.post(f"/api/patients/{patient_id}/assessments", files={"image": ("fake.png", b"123", "image/png")}).status_code == 404


def test_real_writing_saved_and_restored(tmp_path):
    db_path = tmp_path / "test.sqlite3"
    with TestClient(create_app(db_path)) as client:
        patient_id = account_patient(client)
        with (ROOT / "exemplos/escrita/e01.png").open("rb") as image:
            response = client.post(f"/api/patients/{patient_id}/assessments", files={"image": ("foto.png", image, "image/png")})
        assert response.status_code == 201, response.text
        result = response.json()
        assert result["writing"]["status"] == "ok"
        assert result["hands"] is None
        assert all(0 <= value <= 100 for value in result["writing"]["metrics"].values())
        json.dumps(result, allow_nan=False)
        assert client.get("/api/assessments").json() == [result]
        assert client.get(f"/api/patients/{patient_id}/assessments").json() == [result]
        client.post("/api/auth/register", json={**PRO, "email": "outra@example.com"})
        assert client.get("/api/assessments").json() == []
    with TestClient(create_app(db_path)) as client:
        client.post("/api/auth/login", json=PRO)
        assert client.get("/api/assessments").json() == [result]


def test_empty_corrupt_and_missing_uploads(client):
    patient_id = account_patient(client)
    url = f"/api/patients/{patient_id}/assessments"
    assert client.post(url).status_code == 422
    for content in (b"", b"this is not an image"):
        assert client.post(url, files={"image": ("foto.jpg", content, "image/jpeg")}).status_code == 422
    assert client.post(url, files={"video": ("bad.mp4", b"not a video", "video/mp4")}).status_code == 422
    assert client.post(url, files={"image": ("code.py", b"123", "image/png")}).status_code == 422
    assert client.get("/api/assessments").json() == []


def test_blank_image_is_not_invented_result(client):
    patient_id = account_patient(client)
    blank = io.BytesIO()
    Image.new("RGB", (320, 240), "white").save(blank, format="PNG")
    response = client.post(f"/api/patients/{patient_id}/assessments", files={"image": ("blank.png", blank.getvalue(), "image/png")})
    assert response.status_code == 201
    result = response.json()
    assert result["status"] == "insufficient"
    assert result["writing"]["metrics"] is None


def test_no_hand_video_and_combined_upload(client, tmp_path):
    patient_id = account_patient(client)
    path = tmp_path / "blank.mp4"
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (640, 480))
    assert writer.isOpened()
    for _ in range(20):
        writer.write(np.full((480, 640, 3), 255, np.uint8))
    writer.release()
    with path.open("rb") as video, (ROOT / "exemplos/escrita/e01.png").open("rb") as image:
        response = client.post(f"/api/patients/{patient_id}/assessments", files={"image": ("foto.png", image, "image/png"), "video": ("clip.mp4", video, "video/mp4")})
    assert response.status_code == 201, response.text
    result = response.json()
    assert result["status"] == "partial"
    assert result["hands"]["status"] == "no_hand"
    assert result["hands"]["label"] is None
    assert result["hands"]["method"] == METHOD
    assert result["hands"]["classifiedFrames"] == 0
    assert "confidence" not in result["hands"]
    assert result["hands"]["sampledFrames"] == 2
    assert result["writing"]["metrics"] is not None


def test_limits_and_cross_origin(client):
    assert client.post("/api/auth/register", json=PRO, headers={"Origin": "https://other.example"}).status_code == 403
    assert client.post("/api/auth/register", content=b"x" * 17000, headers={"Content-Type": "application/json"}).status_code == 413
    assert client.post("/api/auth/register", content=iter([b"x" * 17000]), headers={"Content-Type": "application/json"}).status_code == 413
    assert client.post("/api/auth/register", json=PRO, headers={"Origin": "http://localhost:8000"}).status_code == 201
    assert client.post("/api/auth/register", json=PRO, headers={"Host": "evil.example"}).status_code == 400


def test_busy_analysis_does_not_create_record(client):
    patient_id = account_patient(client)
    client.app.state.analysis_lock.acquire()
    try:
        response = client.post(f"/api/patients/{patient_id}/assessments", files={"image": ("foto.png", b"abc", "image/png")})
        assert response.status_code == 409
    finally:
        client.app.state.analysis_lock.release()
    assert client.get("/api/assessments").json() == []


def test_professional_contract_ignores_removed_fields(client):
    response = client.post("/api/auth/register", json={**PRO, "cpf": "inválido", "phone": "não utilizado"})
    assert response.status_code == 201
    assert set(response.json()) == {"id", "name", "email"}
    assert set(client.get("/api/auth/me").json()) == {"id", "name", "email"}
    response = client.put("/api/professional", json={"name": "Nome Atualizado", "email": PRO["email"]})
    assert response.status_code == 200
    assert set(response.json()) == {"id", "name", "email"}
    with client.app.state.db.connect() as db:
        columns = {row["name"] for row in db.execute("PRAGMA table_info(professionals)")}
    assert not {"cpf", "phone"} & columns


def test_existing_database_and_legacy_results_are_preserved(tmp_path):
    from backend.security import hash_password
    path = tmp_path / "previous.sqlite3"
    # Estrutura exata do profissional na versão anterior entregue.
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE professionals (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, cpf TEXT UNIQUE, phone TEXT)")
        db.execute("INSERT INTO professionals VALUES(1,?,?,?,?,?)", (PRO["name"], PRO["email"], hash_password(PRO["password"]), "52998224725", PATIENT["phone"]))
    legacy = {"status": "completed", "writing": None, "hands": {"method": "original-randomforest", "status": "ok", "label": "Joinha", "confidence": 70, "probabilities": [{"label": "Joinha", "value": 70}], "sampledFrames": 5, "detectedFrames": 5, "durationSeconds": 5}}
    with TestClient(create_app(path)) as client:
        response = client.post("/api/auth/login", json=PRO)
        assert response.status_code == 200
        assert set(response.json()) == {"id", "name", "email"}
        patient = client.post("/api/patients", json=PATIENT).json()
        with client.app.state.db.connect() as db:
            db.execute("INSERT INTO assessments(patient_id,created_at,result_json) VALUES(?,?,?)", (patient["id"], "2026-01-01T12:00:00+00:00", json.dumps(legacy)))
        assert client.put("/api/professional", json={"name": "Nome Atualizado", "email": PRO["email"]}).status_code == 200
        result = client.get("/api/assessments").json()[0]
        assert result["status"] == "insufficient"
        assert result["hands"]["status"] == "legacy"
        assert result["hands"]["label"] is None
        assert result["hands"]["distribution"] == []
        assert "Joinha" not in json.dumps(result)
        # O banco antigo também aceita novas contas sem CPF/telefone.
        assert client.post("/api/auth/register", json={**PRO, "email": "nova@example.com"}).status_code == 201
    with TestClient(create_app(path)) as client:
        client.post("/api/auth/login", json=PRO)
        assert client.get("/api/patients").json() == [patient]
        assert client.get("/api/assessments").json() == [result]
        with client.app.state.db.connect() as db:
            assert json.loads(db.execute("SELECT result_json FROM assessments").fetchone()[0]) == legacy
            old_fields = db.execute("SELECT cpf,phone FROM professionals WHERE id=1").fetchone()
            assert tuple(old_fields) == ("52998224725", PATIENT["phone"])


@pytest.mark.parametrize("name", ["e01.png", "e02.png", "e03.png", "e04.png", "e05.png", "e06.png", "e07.png", "e08.png", "e09.png", "e10.png"])
def test_original_writing_images_never_return_nan(name):
    result = analyze_writing(ROOT / "exemplos/escrita" / name)
    json.dumps(result, allow_nan=False)
    assert result["status"] in ("ok", "insufficient")
