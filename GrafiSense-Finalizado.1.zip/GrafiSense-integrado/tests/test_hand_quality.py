"""Cenários adversos e estabilidade de software; não estimam acurácia clínica."""
import json
from types import SimpleNamespace

import numpy as np
import pytest

from backend.hands import analyze_hands
from backend.prehension import estimate_posture, summarize_postures, public_hand_result
from test_prehension import clip, pose


@pytest.mark.parametrize("base", [1, 5, 9, 13, 17])
@pytest.mark.parametrize("segment", [0, 1, 2])
def test_collapsed_segment_of_any_finger_is_not_a_grasp(base, segment):
    points = pose("pinch")
    points[base + segment] = points[base + segment + 1]
    assert estimate_posture(points) == {"label": None, "reason": "invalid_landmarks"}


@pytest.mark.parametrize("points", [None, "invalid", [[1], [2, 3]], np.full((21, 3), np.inf)])
def test_malformed_points_abstain_without_crashing(points):
    assert estimate_posture(points)["reason"] == "invalid_landmarks"


def test_collinear_palm_and_extreme_segment_abstain():
    points = pose("palmar")
    points[0] = (0, 0, 0)
    assert estimate_posture(points)["label"] is None
    points = pose("pinch")
    points[2] = (20, 20, 20)
    assert estimate_posture(points)["label"] is None


@pytest.mark.parametrize("kind,expected", [("palmar", "Palmar"), ("pinch", "Pinça"), ("open", None), ("two_extended", None)])
def test_small_jitter_with_3d_transformations_retains_clear_synthetic_patterns(kind, expected):
    rng = np.random.default_rng(741)
    for _ in range(100):
        # Ruído de 1% da largura da palma antes da escala; sementes reprodutíveis.
        points = pose(kind) + rng.normal(0, .01, (21, 3))
        rotation, _ = np.linalg.qr(rng.normal(size=(3, 3)))
        points = points @ rotation * rng.uniform(.02, .15) + rng.uniform(-1, 1, 3)
        points[:, 0] *= rng.choice([-1, 1])
        assert estimate_posture(points)["label"] == expected


def test_middle_finger_pinch_and_extended_thumb_negative_control():
    points = pose("palmar")
    points[10:13] = [(-.17, .5, 0), (-.1, .8, -.05), (0, .95, -.05)]
    points[3:5] = [(-.5, .4, 0), (-.08, .95, -.05)]
    assert estimate_posture(points)["label"] == "Pinça"
    points = pose("palmar")
    points[1:5] = pose("open")[1:5]
    assert estimate_posture(points)["label"] is None


def observation(kind):
    if kind in ("Palmar", "Pinça"):
        return {"label": kind, "reason": "compatible_posture"}
    return {"label": None, "reason": kind}


@pytest.mark.parametrize("labels,status", [
    (["Palmar"] * 4 + ["no_clear_pattern"] * 2 + ["no_hand"] * 4, "inconclusive"),
    (["Palmar", "Palmar", "no_hand"] * 3 + ["Palmar"], "inconclusive"),
    (["Palmar", "Palmar", "no_clear_pattern"] * 3 + ["Palmar"], "inconclusive"),
    (["Palmar", "Pinça"] * 5, "inconclusive"),
    (["Palmar"] * 6 + ["Pinça"] * 4, "inconclusive"),
    (["Palmar"] * 7 + ["Pinça"] * 3, "ok"),
    (["Palmar"] * 5 + ["no_hand"] * 5, "ok"),
    (["Pinça"] * 2 + ["no_hand"] * 8, "inconclusive"),
    (["no_hand"] * 10, "no_hand"),
    (["multiple_hands"] * 10, "inconclusive"),
    (["incomplete_hand"] * 10, "inconclusive"),
    (["invalid_landmarks"] * 10, "inconclusive"),
])
def test_temporal_evidence_and_quality_counts(labels, status):
    result = summarize_postures([observation(label) for label in labels], len(labels), 10)
    assert result["status"] == status
    assert (result["label"] is not None) == (status == "ok")
    assert result["detectedFrames"] == len(labels) - labels.count("no_hand")
    assert result["classifiedFrames"] + result["uncertainFrames"] == result["detectedFrames"]
    assert sum(issue["frames"] for issue in result["quality"]["issues"]) + result["classifiedFrames"] == len(labels)
    json.dumps(result, allow_nan=False)


def fake_result(kind):
    normalized = [SimpleNamespace(x=.5, y=.5, z=0) for _ in range(21)]
    world = [SimpleNamespace(x=x, y=y, z=z) for x, y, z in pose("pinch")]
    if kind == "outside": normalized[8].x = 1.05
    if kind == "nan": normalized[4].x = np.nan
    if kind == "missing": normalized.pop()
    if kind == "broken_thumb": world[3] = world[4]
    count = 2 if kind == "multiple" else 0 if kind == "none" else 1
    return SimpleNamespace(
        multi_hand_landmarks=[SimpleNamespace(landmark=normalized)] * count,
        multi_hand_world_landmarks=[] if kind == "missing_world" else [SimpleNamespace(landmark=world)] * count,
    )


def detector_sequence(monkeypatch, kinds):
    import mediapipe as mp
    results = iter(map(fake_result, kinds))
    class Detector:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def process(self, frame): return next(results)
    monkeypatch.setattr(mp.solutions.hands, "Hands", Detector)


@pytest.mark.parametrize("kind,reason", [("outside", "incomplete_hand"), ("nan", "incomplete_hand"), ("missing", "incomplete_hand"), ("missing_world", "incomplete_hand"), ("broken_thumb", "invalid_landmarks"), ("multiple", "multiple_hands")])
def test_video_reports_specific_detection_problem(monkeypatch, clip, kind, reason):
    detector_sequence(monkeypatch, [kind] * 5)
    result = analyze_hands(clip)
    assert result["status"] == "inconclusive" and result["label"] is None
    assert result["quality"]["issues"][0]["code"] == reason
    assert result["quality"]["issues"][0]["frames"] == 5


def test_missing_hand_breaks_sequence_in_real_video_pipeline(monkeypatch, clip):
    detector_sequence(monkeypatch, ["ok", "ok", "none", "ok", "ok"])
    result = analyze_hands(clip)
    assert result["status"] == "inconclusive" and result["label"] is None
    assert result["classifiedFrames"] == 4 and result["sampledFrames"] == 5
    assert result["quality"]["longestStableRun"] == 2
    assert result["quality"]["issues"][0]["code"] == "no_hand"


def test_unusable_frame_does_not_destroy_clear_sequence(monkeypatch, clip):
    detector_sequence(monkeypatch, ["outside", "ok", "ok", "ok", "ok"])
    result = analyze_hands(clip)
    assert result["status"] == "ok" and result["label"] == "Pinça"
    assert result["quality"]["classifiedPercent"] == 80
    assert result["quality"]["longestStableRun"] == 4


@pytest.mark.parametrize("method", ["geometria-preensao-v1", "geometria-preensao-v2"])
def test_existing_posture_history_keeps_its_original_method(method):
    stored = {"method": method, "status": "ok", "label": "Palmar"}
    assert public_hand_result(stored) == stored
