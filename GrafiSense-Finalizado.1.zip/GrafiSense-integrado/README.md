# GrafiSense integrado

Front React preservado e conectado aos dois projetos Python enviados. Uma API FastAPI atende o site, faz as análises e grava contas, pacientes e resultados em **SQLite**, sem configurar MySQL.

## Atualização 1.3.0

- Pacientes sem CPF no formulário, na API e no banco. Ao iniciar, o esquema anterior é migrado automaticamente, preservando IDs, contatos e avaliações.
- Avaliação da mão com validação dos pontos do polegar, rejeição de segmentos degenerados e exigência de evidência em pelo menos metade da amostra e em três amostras consecutivas.
- Resultados mostram os motivos dos quadros sem classificação e orientações para melhorar a gravação.
- As avaliações palmar/pinça anteriores continuam disponíveis, com identificação dos critérios antigos. Novas avaliações usam `geometria-preensao-v2`.
- A atualização não acrescenta dependências. Consulte `ATUALIZAR-LINUX.txt` ou `ATUALIZAR-WINDOWS.txt`; faça backup com o servidor fechado antes de atualizar.

## Correção da versão 1.2.1

Corrigida a rejeição de WebM gravado pelo navegador quando o leitor informa uma taxa de quadros ausente ou fora da faixa confiável, como 1000 FPS. Nesses casos, a análise usa os tempos dos quadros decodificados para amostrar o vídeo e estimar sua duração. A tela identifica a duração aproximada e a taxa média calculada. Não é necessário reinstalar as dependências.

## Alterações da versão 1.2

- Vídeos de até **250 MB e 5 minutos**, incluindo gravação pela câmera.
- Envio de **MP4, WebM, MOV, AVI, MKV e M4V**, conforme o codec disponível.
- Nome, extensão, tamanho, duração e resolução mostrados na seleção quando o navegador consegue ler os metadados. A análise confirma os dados no servidor.
- Até 60 quadros distribuídos pelo vídeo, com memória de amostragem limitada.
- Limites centralizados em `config/media.json`; consulte `VIDEOS.md` para alterar.

## Mudanças anteriores mantidas

- Cadastro do profissional somente com nome, e-mail e senha. CPF e telefone opcionais foram removidos da interface e da API. Pacientes informam nome, telefone e e-mail do responsável, sem CPF.
- Análise da mão limitada às posturas **palmar** e **pinça**, com estado **inconclusivo** quando não há evidência suficiente. O classificador anterior foi retirado.
- Resultados e histórico usam o novo formato. Registros do antigo classificador de gestos são identificados como “Método anterior”; não são convertidos artificialmente em preensões.
- Bancos da versão anterior continuam aceitos. Veja `ATUALIZAR-WINDOWS.txt` ou `ATUALIZAR-LINUX.txt` para atualizar sem apagar os dados.

## Abrir no Windows

1. Extraia o ZIP inteiro em uma pasta, por exemplo `Documentos/GrafiSense-integrado`.
2. Instale **Python 3.12 de 64 bits**, marcando **Add Python to PATH**. Python 3.10 e 3.11 também são aceitos. Não use Python 3.13 ou superior para estas dependências.
3. Dê dois cliques em `instalar.bat`. A primeira instalação baixa as bibliotecas pela internet e pode demorar alguns minutos. Espere aparecer “Instalacao concluida”.
4. Dê dois cliques em `iniciar.bat`.
5. Abra **http://localhost:8000** e mantenha o terminal aberto enquanto usa o site. Para encerrar, pressione `Ctrl+C` no terminal.

Para abrir de novo, basta `iniciar.bat`. A interface já está compilada em `dist`: não é necessário Node, npm, MySQL ou Docker no uso normal. A instalação das bibliotecas de visão computacional ocupa espaço em disco, mas os modelos só são carregados quando uma análise é solicitada. O servidor não treina modelos ao iniciar.

## Linux / macOS

Com Python 3.10–3.12 de 64 bits instalado:

```bash
bash instalar.sh
bash iniciar.sh
```

Se houver mais de uma versão do Python, use `PYTHON=python3.12 bash instalar.sh`. No Linux, se a criação do ambiente falhar por ausência de `venv`, instale o pacote `python3.12-venv` da sua distribuição. Se o OpenCV indicar falta de `libGL.so.1`, em Debian/Ubuntu instale `libgl1` e `libglib2.0-0`. A disponibilidade de pacotes depende da distribuição. O ambiente de teste foi Linux x86_64; Windows/macOS ainda precisam de validação na máquina de destino.

## Testar o fluxo completo

1. Crie uma conta profissional com nome completo, e-mail e senha.
2. Cadastre um paciente com nome completo, telefone e e-mail do responsável. Não é solicitado CPF.
3. Entre em **Nova avaliação**.
4. Para testar sem câmera, selecione `exemplos/escrita/e01.png` e clique em **Analisar e salvar**.
5. Veja os indicadores em **Resultados** e consulte o registro em **Histórico**.
6. Recarregue a página ou reinicie o servidor e entre novamente. Os registros permanecem no banco.
7. Para mãos, grave pela câmera ou selecione MP4/WebM/MOV/AVI/MKV/M4V de até **5 minutos e 250 MB**. Fotografias: JPG/PNG/WebP, até **10 MB e 25 milhões de pixels**.

É possível enviar apenas a foto, apenas o vídeo ou os dois. Arquivos inválidos geram uma mensagem, sem criar um resultado falso. Se não forem encontrados mão ou traços suficientes, o registro informa explicitamente essa limitação e não inventa uma nota. O filtro de data do histórico usa o dia no fuso do navegador.

## O que funciona

- Cadastro, login, edição do profissional e logout.
- Senhas com scrypt; sessão em cookie HttpOnly/SameSite=Strict com validade de 8 horas.
- Pacientes vinculados à conta autenticada, com isolamento entre profissionais.
- Captura de câmera no navegador e upload de vídeo/fotografia para o Python.
- Processamento de vídeo com MediaPipe e regras geométricas de preensão; processamento de fotografia pelo algoritmo de escrita adaptado.
- Resultados, histórico por paciente, filtro por data e contagens reais no painel.
- Gravação permanente em SQLite, inclusive após fechar o navegador ou reiniciar o servidor.

O servidor escuta somente em `127.0.0.1` para uso local. Esta entrega não configura hospedagem pública ou acesso de vários computadores.

## Como interpretar a análise

**Mãos:** a análise usa os 21 pontos tridimensionais estimados pelo MediaPipe para verificar flexão dos dedos e proximidade do polegar ao indicador/médio. O resultado sugere uma postura compatível com **palmar** ou **pinça**. Não existe um novo classificador treinado: os limiares são experimentais e não foram calibrados ou validados em vídeos rotulados dessas preensões. Não são detectados o lápis, o contato com ele nem a força aplicada. Um punho fechado ou um gesto sem objeto pode ter geometria semelhante a uma preensão.

Mantenha a mão inteira visível e iluminação uniforme; uma gravação curta e nítida costuma ser suficiente. Vídeos longos são avaliados por amostragem e não quadro a quadro. Quadros com duas mãos ou pontos incompletos não são classificados. São necessários ao menos três quadros classificados, mão detectada em pelo menos metade da amostra, classificação em 60% dos quadros com detecção e predominância de 70% entre os classificados. A postura predominante também precisa aparecer em pelo menos metade de todos os quadros amostrados e em uma sequência de três amostras consecutivas. Quadros sem mão, cortados, inválidos, com duas mãos ou outra postura interrompem a sequência. Amostras consecutivas não significam segundos contínuos, especialmente em vídeos longos. Caso contrário, a tela mostra **inconclusivo**. Os percentuais exibidos são proporções de quadros detectados, não probabilidades de acerto, confiança ou qualidade clínica. Como há quadros sem classificação, as duas barras podem somar menos de 100%.

**Escrita:** o programa fornecido extrai medidas geométricas de uma imagem. O script de treinamento enviado está incompleto: depende de `extrair_carac`, de um `dataset.csv` de escrita e de rótulos que não vieram no ZIP, e não inclui um modelo de escrita treinado. A integração executa a extração disponível, corrigida para tratar imagens vazias e agregar todas as linhas. A “legibilidade estimada” é uma heurística, sem validação clínica. Ela depende de recorte, resolução, iluminação, fundo e segmentação. Objetos e ruídos também podem ser identificados como componentes.

Os cinco índices de escrita vão de 0 a 100. Tamanho, espaçamento e grossura são medidas normalizadas, não porcentagens de acerto nem notas em que maior é sempre melhor. Não foi criada média geral combinando preensão e escrita: são medidas diferentes. Os resultados servem para explorar os algoritmos enviados, não para emitir diagnóstico.

## Onde ficam os dados

O arquivo `backend/data/grafisense.sqlite3` é criado automaticamente. Contas, hashes de senhas, sessões, pacientes e resultados são gravados nele. Fotos e vídeos são processados em arquivos temporários, apagados ao concluir a requisição; o histórico guarda indicadores, não cópias das mídias.

Para backup, feche o servidor e copie a pasta `backend/data`. Não a apague ao atualizar o projeto. `GRAFISENSE_DB` permite definir um caminho alternativo. O projeto não migra automaticamente um banco MySQL anterior. A API e o SQL anteriores estão preservados em `legado/mysql` como referência e não são iniciados pelo sistema novo.

## Se você usa npm

Depois de executar `instalar.bat` ou `bash instalar.sh`, estes comandos abrem o sistema pronto:

```bash
npm run dev
# equivalentes: npm start, npm run api, npm run dev:leve
```

Todos iniciam Python + site em **http://localhost:8000**. Não é preciso abrir outro servidor para o uso normal.

Para **editar o front com recarga automática**, use Node.js 22.13+ e, em dois terminais:

```bash
# Terminal 1 — API Python
npm run api

# Terminal 2 — front de desenvolvimento
npm ci
npm run dev:front
```

Nesse modo, abra **http://localhost:5173**. O Vite encaminha `/api` para `http://127.0.0.1:8000`. Depois das alterações, execute `npm run build` para atualizar a interface usada por `iniciar.bat`. `npm run typecheck` verifica o TypeScript. Se alterar `config/media.json`, reinicie o servidor e execute `npm run build` para atualizar também o front. Se mudar a porta Python pelo ambiente `PORT`, ajuste também o destino do proxy no `vite.config.ts` para usar o Vite.

## Testes automatizados

No Windows:

```bat
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.venv\Scripts\python.exe -m pytest -q tests
```

No Linux/macOS:

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q tests
```

`npm test` executa os mesmos testes usando `.venv`. Eles usam SQLite temporário real, as fotografias enviadas, vídeo sem mão e pontos sintéticos para testar a lógica de preensão, sem sobrescrever o banco de uso. Os testes sintéticos verificam o software e não demonstram acurácia em vídeos reais de preensão. Detalhes da verificação desta entrega estão em `VERIFICACAO.md`.

## Problemas comuns

| Problema | Como resolver |
| --- | --- |
| “Servidor indisponível” | Abra `iniciar.bat`, mantenha o terminal aberto e acesse `http://localhost:8000`. |
| `No matching distribution` na instalação | Verifique se usa Python 3.10–3.12, 64 bits. Confira também a conexão com a internet. |
| `Address already in use` | Já há um processo na porta 8000. Feche o outro terminal ou defina `PORT` antes de iniciar. |
| Câmera não abre | Permita a câmera no navegador, feche outros aplicativos que a usam ou use **Selecionar vídeo**. |
| Nenhuma mão identificada | Mantenha a mão inteira visível e bem iluminada. A análise seleciona até 60 quadros ao longo do vídeo. |
| Vídeo não pode ser lido | Respeite 5 minutos e 250 MB. Se o codec for incompatível, exporte como MP4 com vídeo H.264. Trocar apenas a extensão do nome não converte o arquivo. |
| Poucos traços de escrita | Use uma foto de frente, sem sombras, com uma frase visível em papel claro. |
| Resultado demora | A primeira análise carrega as bibliotecas e o modelo. Só uma análise é executada por vez; prefira vídeos de 5–10 s em 640×480. |

Veja `INTEGRACAO.md` para entender a conexão entre as partes e as mudanças em cada arquivo.
