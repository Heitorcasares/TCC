#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
runtime_python="${PYTHON:-python3}"
"$runtime_python" -c 'import sys; assert (3,10) <= sys.version_info[:2] <= (3,12), "Use Python 3.10, 3.11 ou 3.12 (64 bits)."'
"$runtime_python" -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
printf '\nInstalação concluída. Execute: bash iniciar.sh\n'
