# Como juntei o front com os back-ends

## 1. Situação dos arquivos recebidos

- O front React fazia cadastro/login em uma API Node na porta 3001 que exigia MySQL. A parte de avaliação apenas mostrava prévias locais.
- `Machine Learning for Hands/src/index.py` abria a webcam com `cv2.VideoCapture(0)`, carregava o modelo e desenhava a previsão em uma janela OpenCV.
- `Machine Learning for Write/src/index.py` processava um caminho fixo, `models/e01.png`, e exportava CSV/Excel ao executar o arquivo.

Esses programas Python não possuíam rotas HTTP para o navegador chamar. Por isso, colocar suas pastas ao lado do front não bastava.

## 2. API Python e banco local

Criei `backend/app.py` com FastAPI. Ele mantém os contratos de cadastro que o front já usava e acrescenta o envio dos arquivos. `backend/db.py` cria as tabelas SQLite. O banco é persistente; não se trata de localStorage ou de uma simulação em memória.

| Método | Rota | Ação |
| --- | --- | --- |
| GET | `/api/health` | Confere a API e o banco |
| POST | `/api/auth/register` | Cria profissional e inicia sessão |
| POST | `/api/auth/login` | Verifica senha e inicia sessão |
| GET | `/api/auth/me` | Recupera a conta autenticada |
| POST | `/api/auth/logout` | Encerra a sessão |
| PUT | `/api/professional` | Atualiza a própria conta |
| GET / POST | `/api/patients` | Lista ou cria pacientes da conta |
| GET | `/api/assessments` | Lista registros dos pacientes da conta |
| GET | `/api/patients/{id}/assessments` | Recupera o histórico do paciente |
| POST | `/api/patients/{id}/assessments` | Recebe os campos `image` e/ou `video` em multipart, processa e salva |

A API valida a sessão e a propriedade do paciente antes da análise. Receber um ID no endereço não dá acesso ao paciente de outro profissional. Senhas recebem scrypt com salt aleatório; o banco guarda o hash e o navegador recebe um cookie HttpOnly.

## 3. Da câmera do navegador ao modelo

`app/media-input.tsx` usa `getUserMedia` e `MediaRecorder` para gravar a câmera do usuário. O botão de envio também permite escolher um vídeo existente. `lib/api.ts` monta `FormData`, sem fixar manualmente o cabeçalho multipart, para o navegador acrescentar o boundary correto.

`backend/hands.py` lê o vídeo enviado, lê candidatos a aproximadamente um quadro por segundo e mantém até 60 quadros em um reservatório reprodutível, incluindo o primeiro e o último candidatos e extrai os 21 pontos da mão com MediaPipe. A imagem mantém sua proporção ao ser reduzida; a classificação usa as coordenadas mundiais 3D, não os pixels da imagem. Duas mãos visíveis tornam o quadro inconclusivo. O vídeo inteiro é percorrido, inclusive quando o contêiner não informa a duração. As imagens amostradas são reduzidas a no máximo 640 pixels por lado antes de serem mantidas na memória. Só as amostras passam pelo detector; aumentar a duração não aumenta sem limite a quantidade de inferências.

`backend/prehension.py` normaliza os pontos pela largura da palma, calcula ângulos dos dedos e distâncias entre polegar e dedos. As regras distinguem postura palmar ou em pinça quando há evidência suficiente, ou se abstêm. A normalização evita dependência direta de escala, orientação, espelhamento e translação das coordenadas; erros na estimação 3D continuam afetando o resultado. Consulte o código para os limiares experimentais.

O método `geometria-preensao-v2` não foi treinado nem validado com vídeos rotulados. O modelo e os scripts antigos de gestos foram removidos do pacote. Não há carregamento de pickle nem reutilização das probabilidades antigas.

A revisão v2 confere os três segmentos de todos os cinco dedos, finitude das coordenadas, largura e não degeneração da palma. Comprimentos normalizados fora de 0,02 a 2 larguras da palma são descartados como inconsistentes. Esses limites amplos são verificações de software, não referências anatômicas validadas.

A agregação exige três quadros classificados, detecção em 50% da amostra, classificação em 60% das detecções e 70% de predominância entre classificados. Agora também exige apoio da postura predominante em 50% da amostra total e uma sequência de três amostras com esse rótulo. Quadros sem detecção permanecem na sequência para não unir trechos separados. O campo opcional `quality` registra cobertura de classificação, sequência e motivos dos quadros sem classificação. A amostragem continua limitada a 60 inferências; a revisão não aumenta esse custo.

## 4. Do upload de escrita aos indicadores

`backend/writing.py` adapta a extração recebida para uma função chamada sob demanda. As mudanças principais foram:

- Remover leitura fixa de `e01.png`, prints e exportações automáticas na importação.
- Verificar o formato, orientação e tamanho da imagem; tratar transparência sobre fundo branco.
- Tratar imagens vazias e casos sem linhas, sem produzir NaN ou variáveis não inicializadas.
- Ordenar os componentes pelo eixo X antes de calcular espaços.
- Agregar todas as linhas, retirando o `return` que encerrava a análise na primeira iteração.
- Calcular a variação sobre a lista de espaçamentos, em vez de usar o desvio de um único número, que era sempre zero.
- Reduzir imagens grandes para no máximo 1800 pixels por lado e limitar trabalho concorrente.

O significado experimental dos cinco índices foi preservado. O módulo HOG do código original não alimentava os valores retornados e foi removido do caminho de inferência.

## 5. Resultados no front

O clique em **Analisar e salvar** chama a API. Enquanto aguarda, a tela mostra o processamento e impede um segundo envio. O retorno contém `writing`, `hands`, identificação do paciente, data e identificação do registro salvo.

`app/analysis-views.tsx` mostra esses dados em resultados e histórico. Os registros são recarregados do banco ao entrar novamente. O painel usa contagens reais. A distribuição de preensão informa contagens e proporções dos quadros com mão detectada. A API não retorna probabilidades ou confiança para esse método. O front mostra também quadros sem classificação, ausência de mão e resultados inconclusivos.

## 6. Inicialização e arquivos preservados

`run.py` inicia um único servidor em `http://localhost:8000`. Esse servidor entrega o `dist` compilado e responde às rotas `/api`. No desenvolvimento, o Vite da porta 5173 encaminha as mesmas rotas ao Python.

- `backend/`: API, banco, segurança e processamento em uso.
- `backend/prehension.py`: regras geométricas experimentais e adaptação do histórico antigo.
- `backend/data/`: banco criado na primeira execução.
- `app/` e `lib/`: front conectado.
- `referencias/Write`: código de escrita recebido, preservado para consulta; não é executado pelo servidor.
- `legado/mysql/`: API Node, schema e instruções anteriores, preservados para consulta.
- `exemplos/escrita/`: as dez imagens de escrita enviadas.

Não foram modificados os arquivos originais que deram origem à integração. O pacote atualizado inclui somente o processamento de preensão atual e a referência de escrita.

### Compatibilidade do banco

Na versão 1.3, pacientes deixam de ter CPF. `Database.remove_patient_cpf` reconstrói a tabela dentro de uma transação, mantém IDs e contatos, remove a restrição de unicidade por CPF e verifica as chaves estrangeiras antes de confirmar. Em caso de falha, faz rollback. A migração é idempotente e recusa esquemas com campos adicionais para não descartá-los. Novos pacientes recebem IDs próprios; nome, telefone ou e-mail não são usados como identificadores únicos, permitindo contatos compartilhados por irmãos, por exemplo.

A aplicação ignora um campo CPF enviado por um front antigo e nunca o retorna ou grava no novo esquema. `secure_delete` é habilitado durante a migração e há tentativa de checkpoint do WAL após confirmar. Isso não remove cópias de segurança anteriores nem constitui garantia de apagamento forense de discos ou outros arquivos. O backup anterior contém os dados antigos; depois de conferir a atualização, substitua-o por uma cópia nova conforme sua política de retenção. Estruturas históricas de referência em `legado/mysql` não são executadas nem contêm cadastros reais.

Referência da reconstrução transacional: [procedimento de alteração de esquema do SQLite](https://www.sqlite.org/lang_altertable.html#making_other_kinds_of_table_schema_changes).

A tabela de profissionais criada em um banco novo contém nome, e-mail e hash de senha. Em bancos existentes, as antigas colunas opcionais são deixadas intactas para preservar os dados, mas não são lidas para o contrato público, exibidas, validadas ou atualizadas. Login, cadastro e edição usam apenas os campos atuais.

Os resultados anteriores continuam salvos no JSON original do banco. As preensões `geometria-preensao-v1` continuam legíveis com o método original, sem aplicar retrospectivamente os critérios v2. Para os resultados do antigo classificador de gestos, `public_hand_result` substitui a apresentação da mão por `status: legacy` e uma mensagem solicitando novo vídeo. Isso preserva o histórico sem apresentar o método anterior como análise de preensão. Fotos e vídeos nunca foram armazenados no histórico, portanto não há mídia para reprocessar automaticamente.

## 7. Tamanho, duração e formatos

`config/media.json` é a configuração compartilhada. `backend/media.py` carrega os valores para a API e `lib/media.ts` os importa durante a compilação do front. O limite multipart inclui vídeo + imagem + margem para os campos do formulário.

A seleção no navegador confere extensão, bytes e duração quando legível. A prévia indisponível não bloqueia o envio. No servidor, o upload é gravado em blocos, o conteúdo é aberto pelo OpenCV e os limites de duração/resolução também são conferidos. A análise pode parar se ultrapassar 120 segundos de processamento. Quando a taxa informada pelo leitor é válida, a duração é calculada pela contagem de quadros. Se a taxa estiver ausente ou fora da faixa confiável (inclusive 1000 FPS em WebM do navegador), `backend/video_timing.py` usa `CAP_PROP_POS_MSEC` de cada quadro decodificado. A última fração de duração é estimada pela mediana dos intervalos recentes; a API sinaliza `durationEstimated: true` e `timingMethod: timestamps`. Não há adoção silenciosa de 30 FPS. Se também não houver tempos utilizáveis, a análise retorna uma mensagem específica. O limite de 5 minutos é verificado em ambos os caminhos. Fontes com taxa variável podem apresentar diferença em relação ao player.

A extensão mostrada vem do nome do arquivo e não certifica seu contêiner interno. O campo `hands.video.codec` informa o código de codec exposto pelo OpenCV quando disponível. Um nome `.mp4` sozinho não assegura compatibilidade. Os campos adicionais são opcionais na interface para manter os registros da versão anterior legíveis.

Fontes técnicas: [OpenCV VideoCapture](https://docs.opencv.org/4.x/d8/dfe/classcv_1_1VideoCapture.html) e [contêineres de mídia no navegador, MDN](https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Formats/Containers).

## 8. Dependências

As versões de dependências da instalação anterior foram mantidas. MediaPipe **0.10.21** mantém a API `mp.solutions.hands`. O scikit-learn continua sendo usado para agrupar linhas no processamento de escrita; não há classificador treinado de preensão. A atualização não exige bibliotecas adicionais em uma instalação que já funcionava.

Referência técnica do detector e das coordenadas: [MediaPipe Hands](https://github.com/google-ai-edge/mediapipe/blob/master/docs/solutions/hands.md). Os limiares de preensão são regras deste projeto e não critérios fornecidos ou validados pelo MediaPipe.

Os testes verificam funcionamento do software e persistência. Não demonstram acurácia clínica, generalização da análise ou diagnóstico.
