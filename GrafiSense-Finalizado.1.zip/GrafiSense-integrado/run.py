"""Um servidor para o front compilado, a API e o banco local."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    if not (3, 10) <= sys.version_info[:2] <= (3, 12):
        raise SystemExit("Use Python 3.10, 3.11 ou 3.12 (64 bits). Recomendado: 3.12.")
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ.setdefault(name, "1")
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    try:
        import uvicorn
        from backend.app import create_app
    except ImportError as exc:
        raise SystemExit("Dependências ausentes. Execute instalar.bat (Windows) ou bash instalar.sh (Linux/macOS).") from exc
    if not (ROOT / "dist" / "index.html").exists():
        raise SystemExit("A pasta dist está ausente. Extraia o ZIP inteiro ou execute npm run build.")
    port = int(os.environ.get("PORT", "8000"))
    print(f"\nGrafiSense pronto para iniciar. Abra http://localhost:{port}\nMantenha este terminal aberto. Para encerrar, pressione Ctrl+C.\n", flush=True)
    uvicorn.run(create_app(), host="127.0.0.1", port=port, log_level="info")


if __name__ == "__main__":
    main()
