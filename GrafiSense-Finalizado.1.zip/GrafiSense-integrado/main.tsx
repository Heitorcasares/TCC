import { createRoot } from "react-dom/client";
import HomePage from "./app/page";
import "./app/globals.css";

createRoot(document.getElementById("root")!).render(<HomePage />);
