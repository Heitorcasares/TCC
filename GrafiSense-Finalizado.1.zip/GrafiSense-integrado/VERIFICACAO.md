# Verificação da atualização 1.3.0

Verificado em 28/10/2026, Linux x86_64, Python 3.12 e Node 24.

## Resultado

- **116 testes Python passaram** em 28,94 segundos, com SQLite temporário real. São 54 novos casos além dos 62 da versão anterior. Três avisos de depreciação de dependências, sem falhas.
- **TypeScript:** `npm run typecheck` passou.
- **Compilação:** `npm run build` passou; o `dist` atualizado acompanha o ZIP.
- **Chromium:** banco antigo migrado, cadastro sem CPF pelo formulário, requisição e resposta sem CPF, contatos compartilhados, envio conjunto de WebM e foto, mensagens de visibilidade e histórico.
- Cadastro e resultados conferidos em 1360 e 390 pixels, sem rolagem horizontal ou erros JavaScript.

## Pacientes sem CPF

1. Banco novo sem a coluna; cadastro apenas com nome, telefone e e-mail.
2. Campo CPF eventualmente enviado por um cliente antigo é ignorado, sem gravação ou retorno.
3. Migração do esquema exato anterior, preservando IDs não sequenciais, contatos, avaliações e seus vínculos.
4. Login, sessão após reinício, isolamento entre contas e histórico continuam funcionando.
5. Nome ou contato compartilhado não impede novos cadastros e não combina pacientes diferentes.
6. Reinícios repetidos não repetem a migração nem alteram IDs.
7. Verificações SQLite de integridade e chaves estrangeiras passam; referências inválidas continuam impedidas.
8. Migração com banco inconsistente é revertida, preservando a tabela antiga; colunas personalizadas impedem a migração para não serem descartadas.

A remoção ocorre ao iniciar a versão atualizada. Não há acesso remoto ao banco de uso do usuário. Cópias de segurança feitas antes da atualização ainda contêm os dados antigos.

## Refinamentos e regressões da mão

Antes da mudança, foram reproduzidos três comportamentos: polegar com segmento colapsado classificado como pinça; quatro quadros palmares em dez amostras tratados como predominantes; sequência interrompida repetidamente tratada como consistente. Com a revisão, esses casos ficam inconclusivos.

Novos testes cobrem:

- Cada um dos 15 segmentos internos dos cinco dedos colapsado, inclusive os três do polegar.
- Coordenadas ausentes, formato irregular, infinito, segmentos desproporcionais e palma degenerada.
- Pinça pelo indicador e pelo médio; controles sem padrão claro.
- **400 variações sintéticas:** 100 para cada padrão de palmar, pinça, dedos estendidos e dois dedos estendidos. Ruído de 1% da largura da palma combinado com rotações 3D, escala, translação e espelhamento.
- Pouca visibilidade, posturas alternadas, predominância dividida, sequência interrompida por falta de mão e recuperação após um quadro inutilizável.
- Pontos fora da imagem, normalizados incompletos, ausência de coordenadas mundiais, duas mãos e polegar inconsistente no pipeline de vídeo com detector controlado.
- Contagens e motivos de descarte coerentes; serialização sem NaN.
- Métodos de preensão v1 e v2 preservados no histórico com sua identificação original.

Os padrões sintéticos claros mantiveram os rótulos esperados. Não foram testadas preensões reais de pessoas rotuladas; o resultado não é uma medida de acurácia.

## Regressões anteriores mantidas

A suite completa também passou para autenticação, hash de senha, conta profissional sem campos opcionais, isolamento por conta, escrita, persistência, limites de requisição e concorrência de análise.

O vídeo real sem mão é processado com OpenCV e MediaPipe e retorna ausência de mão. As fotografias de escrita são processadas sem valores não finitos. Vídeos vazios, corrompidos ou acima dos limites são rejeitados.

Foram mantidos os testes de seis contêineres reais: MP4/MOV/M4V com MPEG-4 Part 2, WebM com VP8, AVI com MJPEG e MKV com MPEG-4 Part 2. Isso não garante todas as combinações de codecs dessas extensões. Também passam upload de 51 MB, reservatório limitado, vídeo de 75 segundos, limite de 301 segundos e tempo máximo de processamento.

A fixture WebM do MediaRecorder continua reproduzindo FPS=1000 no OpenCV. A correção usa os tempos de seus 30 quadros e retorna quatro amostras, duração aproximada de 3,29 segundos e média de 9,077 quadros/s. Foram mantidos os testes de FPS ausente/NaN, tempos duplicados, origem diferente de zero e tempos inválidos. Esse mesmo WebM foi enviado com uma foto pelo navegador na versão 1.3.0, retornando HTTP 201, análise da escrita e ausência de mão, com histórico disponível após recarga.

## Navegador e limites da verificação

O teste do navegador começou com um banco anterior contendo dois pacientes e uma avaliação de preensão v1. Após a migração, os pacientes foram lidos sem CPF e um terceiro foi cadastrado pela interface. O histórico v1 permaneceu associado ao paciente correto e exibiu a nota sobre os critérios anteriores.

Registros v2 de palmar, pinça e inconclusivo foram gerados com observações sintéticas e inseridos somente no banco de teste para conferir apresentação e navegação. Isso testa a interface, não a detecção de pessoas reais.

A análise continua experimental: não há classificador palmar/pinça treinado nem conjunto rotulado para medir precisão. Não são detectados o lápis, contato ou força. As novas condições de abstenção podem aumentar o número de inconclusivos. Consulte `AVALIACAO-MAO.md` para a interpretação e um roteiro de comparação com gravações reais.

A câmera física do usuário, a instalação Windows/macOS e novos codecs não foram verificados nesta execução. As dependências não mudaram.

O ZIP não inclui bancos de teste, credenciais, capturas de tela, ambiente virtual ou `node_modules`. Inclui somente a fixture WebM sintética, sem pessoas ou áudio, usada na regressão automatizada.
