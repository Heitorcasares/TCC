import { useState } from "react";
import { CheckCircle2, Eye, EyeOff, LockKeyhole } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type PasswordFieldsProps = {
  mode: "create" | "login";
  password: string;
  confirmation: string;
  onPasswordChange: (value: string) => void;
  onConfirmationChange: (value: string) => void;
  errors: Record<string, string>;
};

export function PasswordFields({ mode, password, confirmation, onPasswordChange, onConfirmationChange, errors }: PasswordFieldsProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [passwordTouched, setPasswordTouched] = useState(false);
  const [confirmationTouched, setConfirmationTouched] = useState(false);
  const creating = mode === "create";
  const lengthValid = password.length >= 8 && password.length <= 128;
  const passwordError = errors.password || (creating && passwordTouched && !lengthValid ? "Use uma senha de 8 a 128 caracteres." : "");
  const confirmationError = errors.confirm || (creating && confirmationTouched && !confirmation ? "Digite a senha novamente para confirmar." : creating && confirmationTouched && confirmation !== password ? "As senhas devem ser iguais." : "");
  const matching = lengthValid && !!confirmation && password === confirmation && !confirmationError;

  return <fieldset className={"password-section" + (creating ? "" : " login-password")}>
    <legend className="password-section-title"><LockKeyhole aria-hidden="true" />{creating ? "Crie sua senha de acesso" : "Sua senha de acesso"}</legend>
    <p className="password-section-description">{creating ? "Você vai usar esta senha junto com seu e-mail para entrar no GrafiSense." : "Use a senha que você criou ao cadastrar sua conta."}</p>
    <div className="password-grid">
      <div className="form-field">
        <Label htmlFor="pro-password">{creating ? "Criar senha" : "Senha"}</Label>
        <div className="password-input-wrap">
          <Input id="pro-password" name="password" type={showPassword ? "text" : "password"} value={password} onChange={event => onPasswordChange(event.target.value)} onBlur={() => setPasswordTouched(true)} autoComplete={creating ? "new-password" : "current-password"} minLength={creating ? 8 : undefined} maxLength={128} required placeholder={creating ? "Digite uma senha" : "Digite sua senha"} spellCheck={false} autoCapitalize="none" aria-invalid={!!passwordError} aria-describedby={[creating ? "pro-password-hint" : "", passwordError ? "pro-password-error" : ""].filter(Boolean).join(" ") || undefined} />
          <button type="button" className="password-visibility" aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"} aria-controls="pro-password" onClick={() => setShowPassword(value => !value)}>{showPassword ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}</button>
        </div>
        {creating && <p id="pro-password-hint" className="password-hint">Use de 8 a 128 caracteres.</p>}
        {passwordError && <p id="pro-password-error" className="field-error" role="alert">{passwordError}</p>}
      </div>
      {creating && <div className="form-field">
        <Label htmlFor="pro-confirm">Confirmar senha</Label>
        <div className="password-input-wrap">
          <Input id="pro-confirm" name="passwordConfirmation" type={showConfirmation ? "text" : "password"} value={confirmation} onChange={event => onConfirmationChange(event.target.value)} onBlur={() => setConfirmationTouched(true)} autoComplete="new-password" maxLength={128} required placeholder="Digite a mesma senha novamente" spellCheck={false} autoCapitalize="none" aria-invalid={!!confirmationError} aria-describedby={confirmationError ? "pro-confirm-error" : "pro-confirm-status"} />
          <button type="button" className="password-visibility" aria-label={showConfirmation ? "Ocultar confirmação de senha" : "Mostrar confirmação de senha"} aria-controls="pro-confirm" onClick={() => setShowConfirmation(value => !value)}>{showConfirmation ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}</button>
        </div>
        {confirmationError && <p id="pro-confirm-error" className="field-error" role="alert">{confirmationError}</p>}
        <p id="pro-confirm-status" className={"password-hint" + (matching ? " password-match" : "")} aria-live="polite">{matching ? <><CheckCircle2 aria-hidden="true" /> As senhas coincidem.</> : !confirmationError ? "Repita a senha para evitar erros de digitação." : null}</p>
      </div>}
    </div>
  </fieldset>;
}
