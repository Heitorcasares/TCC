"use client";

import { useEffect, useRef, useState } from "react";
import { Camera, CheckCircle2, FileImage, LoaderCircle, RotateCcw, Square, UploadCloud, Video, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { DURATION_LIMIT, durationLabel, extensionOf, IMAGE_BYTES, inspectVideo, MEDIA, sizeLabel, VIDEO_ACCEPT, VIDEO_BYTES, VIDEO_FORMATS, type VideoDetails } from "@/lib/media";

type Props = { kind: "video" | "image"; file?: File; disabled?: boolean; onChange: (file?: File) => void };

function CameraCapture({ onCapture }: { onCapture: (file: File) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const active = useRef(true);
  const stopTimer = useRef<number | undefined>(undefined);
  const [ready, setReady] = useState(false);
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    active.current = true;
    let cancelled = false;
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("A câmera não está disponível. Abra o site em uma conexão HTTPS e em um navegador com suporte à câmera."); return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } }, audio: false }).then(stream => {
      if (cancelled) { stream.getTracks().forEach(track => track.stop()); return; }
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    }).catch((cause: unknown) => {
      if (cancelled) return;
      const code = cause instanceof DOMException ? cause.name : "";
      setError(code === "NotAllowedError" ? "Acesso à câmera não autorizado. Permita o uso da câmera nas configurações do navegador e tente novamente." : code === "NotFoundError" ? "Nenhuma câmera foi encontrada neste dispositivo. Conecte uma câmera e tente novamente." : "Não foi possível abrir a câmera. Confira se ela está conectada e se outro aplicativo está usando o dispositivo.");
    });
    return () => {
      active.current = false;
      window.clearTimeout(stopTimer.current);
      cancelled = true;
      if (recorderRef.current?.state === "recording") recorderRef.current.stop();
      streamRef.current?.getTracks().forEach(track => track.stop());
    };
  }, []);

  useEffect(() => {
    if (!recording) return;
    const timer = window.setInterval(() => setSeconds(value => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [recording]);

  function record() {
    if (!streamRef.current) return;
    if (typeof MediaRecorder === "undefined") { setError("Este navegador não permite gravação de vídeo. Acesse por um navegador com suporte à gravação pela câmera."); return; }
    try {
      const mime = ["video/webm;codecs=vp8", "video/webm", "video/mp4"].find(type => MediaRecorder.isTypeSupported(type));
      const recorder = new MediaRecorder(streamRef.current, { ...(mime ? { mimeType: mime } : {}), videoBitsPerSecond: 800000 });
      recorderRef.current = recorder;
      const chunks: Blob[] = [];
      let totalBytes = 0;
      let failed = false;
      recorder.ondataavailable = event => {
        if (event.data.size) { chunks.push(event.data); totalBytes += event.data.size; }
        if (totalBytes > VIDEO_BYTES && recorder.state === "recording") recorder.stop();
      };
      recorder.onerror = () => { failed = true; if (active.current) { setRecording(false); setError("A gravação foi interrompida. Feche a câmera e tente novamente."); } };
      recorder.onstop = () => {
        window.clearTimeout(stopTimer.current);
        if (!active.current || failed || !chunks.length) return;
        setRecording(false);
        const type = recorder.mimeType || "video/webm";
        onCapture(new File(chunks, "gravacao-mao." + (type.includes("mp4") ? "mp4" : "webm"), { type }));
      };
      recorder.start(1000); setSeconds(0); setRecording(true);
      stopTimer.current = window.setTimeout(() => { if (recorder.state === "recording") recorder.stop(); }, MEDIA.maxVideoSeconds * 1000);
    } catch { setError("Não foi possível iniciar a gravação. Feche a câmera e tente novamente."); }
  }

  return <div className="camera-capture">
    {error ? <div className="notice attention" role="alert">{error}</div> : <>
      <div className="camera-frame"><video ref={videoRef} autoPlay muted playsInline onLoadedData={() => setReady(true)} aria-label="Prévia ao vivo da câmera" />{!ready && <span><LoaderCircle className="animate-spin" /> Aguardando acesso à câmera…</span>}</div>
      <div className="camera-status" role="status"><span className={recording ? "recording-status" : "muted"}>{recording ? "Gravando" : ready ? "Câmera pronta" : "Aguardando câmera"}</span><span>{Math.floor(seconds / 60).toString().padStart(2, "0")}:{(seconds % 60).toString().padStart(2, "0")}</span></div>
      <p className="muted">Mantenha a mão, o lápis e o papel visíveis. A gravação é feita sem áudio e termina automaticamente em {DURATION_LIMIT}.</p>
      {recording ? <Button className="action stop-recording" onClick={() => { recorderRef.current?.stop(); setRecording(false); }}><Square /> Finalizar gravação</Button> : <Button className="action" disabled={!ready} onClick={record}><Video /> Iniciar gravação</Button>}
    </>}
  </div>;
}

export function MediaInput({ kind, file, disabled = false, onChange }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState("");
  const [camera, setCamera] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [checking, setChecking] = useState(false);
  const selection = useRef(0);
  const [metadata, setMetadata] = useState<{ file: File; details: VideoDetails } | null>(null);
  const [previewError, setPreviewError] = useState(false);
  const isVideo = kind === "video";
  const details = metadata && metadata.file === file ? metadata.details : null;
  useEffect(() => () => { selection.current += 1; }, []);
  useEffect(() => {
    setPreviewError(false);
    if (!file) { setUrl(""); return; }
    const objectUrl = URL.createObjectURL(file); setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);

  async function chooseFile(next?: File) {
    if (!next || disabled) return;
    if (isVideo) {
      if (!MEDIA.videoExtensions.includes(extensionOf(next.name))) { toast.error(`Selecione um vídeo ${VIDEO_FORMATS}.`); return; }
      if (!next.size || next.size > VIDEO_BYTES) { toast.error(`Escolha um vídeo não vazio de até ${MEDIA.maxVideoMB} MB e ${DURATION_LIMIT}.`); return; }
      const request = ++selection.current;
      setChecking(true);
      const info = await inspectVideo(next);
      if (request !== selection.current) return;
      setChecking(false);
      if (info.duration !== null && info.duration > MEDIA.maxVideoSeconds + .5) { toast.error(`O vídeo tem ${durationLabel(info.duration)}. O limite é de ${DURATION_LIMIT}. Recorte-o antes de enviar.`); return; }
      setMetadata({ file: next, details: info });
      onChange(next); toast.success("Vídeo selecionado."); return;
    }
    if (!/\.(jpe?g|png|webp)$/i.test(next.name) || (next.type && !["image/jpeg", "image/png", "image/webp"].includes(next.type))) { toast.error("Selecione uma imagem JPG, PNG ou WebP."); return; }
    if (!next.size || next.size > IMAGE_BYTES) { toast.error(`Escolha uma imagem não vazia de até ${MEDIA.maxImageMB} MB.`); return; }
    onChange(next); toast.success("Fotografia selecionada.");
  }
  function finishRecording(next: File) {
    setCamera(false);
    void chooseFile(next);
  }

  return <>
    <input ref={input} type="file" accept={isVideo ? VIDEO_ACCEPT : ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"} className="sr-only" tabIndex={-1} aria-label={isVideo ? "Selecionar vídeo da mão" : "Selecionar fotografia da escrita"} disabled={disabled || checking} onChange={event => { void chooseFile(event.target.files?.[0]); event.target.value = ""; }} />
    {file ? <div className="selected-media"><div className="media-preview">{url && (isVideo ? <video key={url} controls src={url} preload="metadata" onError={() => setPreviewError(true)} onLoadedMetadata={event => { const video = event.currentTarget; setMetadata({ file, details: { duration: Number.isFinite(video.duration) && video.duration > 0 ? video.duration : null, width: video.videoWidth || null, height: video.videoHeight || null, previewAvailable: true } }); }} aria-label="Prévia do vídeo gravado" /> : <img src={url} alt="Fotografia da escrita selecionada" />)}</div><div className="file-summary"><CheckCircle2 className="success-icon" /><span><strong title={file.name}>{file.name}</strong><small>Extensão: {extensionOf(file.name).toUpperCase()} · {sizeLabel(file.size)}</small>{isVideo && <small>{details?.duration != null ? `Duração: ${durationLabel(details.duration)}` : "Duração: será verificada na análise"}{details?.width && details?.height ? ` · ${details.width} × ${details.height}` : ""}</small>}</span><Button variant="ghost" size="icon" aria-label={isVideo ? "Remover gravação" : "Remover fotografia"} disabled={disabled || checking} onClick={() => onChange(undefined)}><X /></Button></div></div> : isVideo ? <div className="drop-area camera-area"><span className="upload-icon"><Camera /></span><h3>Grave a mão durante a escrita</h3><p>Abra a câmera e permita o acesso para visualizar e gravar a atividade.</p><Button className="action" disabled={disabled || checking} onClick={() => setCamera(true)}><Camera /> Abrir câmera</Button><Button variant="outline" className="action secondary" disabled={disabled || checking} onClick={() => input.current?.click()}><UploadCloud /> Selecionar vídeo</Button><small>{VIDEO_FORMATS} · até {MEDIA.maxVideoMB} MB e {DURATION_LIMIT}</small></div> : <div className={"drop-area " + (dragging ? "dragging" : "")} onDragOver={event => { event.preventDefault(); if (!disabled) setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); void chooseFile(event.dataTransfer.files[0]); }}><span className="upload-icon"><FileImage /></span><h3>Fotografia da escrita</h3><p>Arraste a fotografia para cá ou selecione um arquivo.</p><Button variant="outline" className="action secondary" disabled={disabled || checking} onClick={() => input.current?.click()}><UploadCloud /> Selecionar fotografia</Button><small>JPG, PNG ou WebP · até {MEDIA.maxImageMB} MB</small></div>}
    {checking && <p className="muted" role="status">Conferindo o vídeo…</p>}
    {file && isVideo && (previewError || details?.previewAvailable === false) && <p className="notice attention" role="status">A prévia deste arquivo não está disponível no navegador. Você pode tentar analisar; o servidor verificará se consegue ler o vídeo.</p>}
    {file && isVideo && <Button variant="ghost" disabled={disabled || checking} onClick={() => input.current?.click()}><UploadCloud /> Trocar vídeo</Button>}
    {file && <Button variant="ghost" className="camera-button" disabled={disabled || checking} onClick={() => isVideo ? setCamera(true) : input.current?.click()}>{isVideo ? <RotateCcw /> : <UploadCloud />}{isVideo ? "Gravar novamente" : "Trocar fotografia"}</Button>}
    {isVideo && <Dialog open={camera} onOpenChange={setCamera}><DialogContent className="gs-dialog camera-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar câmera"><X /></Button></DialogClose><DialogHeader><DialogTitle>Gravar a atividade de escrita</DialogTitle><DialogDescription>Ao fechar esta janela, o acesso à câmera é encerrado. O vídeo será enviado quando você clicar em Analisar e salvar.</DialogDescription></DialogHeader>{camera && <CameraCapture onCapture={finishRecording} />}</DialogContent></Dialog>}
  </>;
}
