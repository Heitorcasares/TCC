import { useState } from "react";
import { ArrowRight, BarChart3, CalendarDays, Hand, History, Info, PenLine, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { Assessment, HandsResult, Patient, WritingMetrics } from "@/lib/grafisense";

export type View = "inicio" | "pacientes" | "avaliacao" | "resultados" | "historico";
export const indexValue = (value: number | undefined | null) => value == null ? "—" : `${value.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}/100`;
const dateLabel = (date: string) => new Date(date).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
const localDay = (date: string) => {
  const value = new Date(date);
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
};
const labels: { key: keyof WritingMetrics; title: string; note: string }[] = [
  { key: "legibility", title: "Legibilidade estimada", note: "Estimativa geométrica da fotografia" },
  { key: "alignment", title: "Alinhamento", note: "Regularidade das linhas identificadas" },
  { key: "letterSize", title: "Tamanho da letra", note: "Tamanho relativo à altura da imagem" },
  { key: "spacing", title: "Espaçamento", note: "Distância relativa entre os traços" },
  { key: "strokeThickness", title: "Grossura do traço", note: "Espessura relativa à altura dos traços" },
];

function Explanation() {
  return <div className="notice"><Info /><p>A análise da mão estima uma postura compatível com preensão palmar ou em pinça a partir dos pontos da mão. É experimental e ainda não foi validada com vídeos rotulados dessas preensões. Os índices de escrita são estimativas geométricas de 0 a 100; tamanho, espaçamento e grossura não são notas de qualidade. Estes resultados não constituem diagnóstico.</p></div>;
}

const handLabel = (hands: HandsResult | null) => hands?.label || (hands?.status === "legacy" ? "Método anterior" : hands?.status === "inconclusive" ? "Inconclusivo" : hands?.status === "no_hand" ? "Mão não detectada" : "—");

function HandAnalysis({ hands }: { hands: HandsResult | null }) {
  return <section className="panel analysis-panel"><div className="panel-heading"><h2><Hand /> Análise de preensão</h2><span className="pill">{hands?.experimental ? "Experimental" : hands?.status === "legacy" ? "Método anterior" : "Não enviado"}</span></div>
    {hands ? <>
      <div className="gesture-summary"><div><span className="eyebrow">POSTURA ESTIMADA</span><h3>{handLabel(hands)}</h3></div></div>
      <p>{hands.message}</p>
      {hands.status !== "legacy" && hands.detectedFrames > 0 && <>
        <p className="muted">Proporção dos quadros com mão detectada. Estes percentuais não medem confiança nem qualidade da preensão.</p>
        <div className="gesture-distribution">{hands.distribution.map(item => <div key={item.label}><span>{item.label} · {item.frames} {item.frames === 1 ? "quadro" : "quadros"}</span><progress max="100" value={item.percent} aria-label={`Quadros compatíveis com ${item.label}`} /><strong>{item.percent.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%</strong></div>)}</div>
        <p className="muted">{hands.uncertainFrames} {hands.uncertainFrames === 1 ? "quadro com mão detectada sem classificação." : "quadros com mão detectada sem classificação."}{hands.multipleHandFrames > 0 ? ` Em ${hands.multipleHandFrames} deles havia mais de uma mão; mantenha somente a mão avaliada no enquadramento.` : ""}</p>
      </>}
      {hands.status !== "legacy" && <p className="muted">Mão detectada em {hands.detectedFrames} de {hands.sampledFrames} quadros amostrados · vídeo de {hands.durationSeconds.toLocaleString("pt-BR")} s.</p>}
      {hands.quality && <div className="hand-quality"><h4>Visibilidade e consistência</h4><p className="muted">Postura identificada em {hands.quality.classifiedPercent.toLocaleString("pt-BR")}% de toda a amostra. Maior sequência da postura mais frequente: {hands.quality.longestStableRun} {hands.quality.longestStableRun === 1 ? "amostra" : "amostras"}. A sequência se refere aos quadros selecionados, não a segundos contínuos.</p>{hands.quality.issues.length > 0 && <ul>{hands.quality.issues.map(issue => <li key={issue.code}>{issue.frames} {issue.frames === 1 ? "quadro" : "quadros"}: {issue.message}</li>)}</ul>}</div>}
      {hands.method === "geometria-preensao-v1" && <p className="muted">Registro feito antes da revisão dos critérios de visibilidade e consistência. Envie um novo vídeo para usar os critérios atuais.</p>}
      {hands.video && <p className="muted">Arquivo {hands.video.extension} · {hands.video.width} × {hands.video.height} · {hands.video.fps.toLocaleString("pt-BR")} quadros/s{hands.video.timingMethod === "timestamps" ? " em média" : ""}. A análise usa uma amostra ao longo do vídeo.{hands.video.durationEstimated ? " A duração é aproximada, calculada pelos tempos dos quadros." : ""}</p>}
    </> : <p>Nenhum vídeo foi enviado nesta avaliação.</p>}
  </section>;
}

export function ResultsView({ selected, result, navigate }: { selected?: Patient; result?: Assessment; navigate: (view: View) => void }) {
  if (!result) return <div className="view-stack"><section className="panel analysis-empty"><BarChart3 /><h2>Ainda não há resultados</h2><p>{selected ? "Envie uma fotografia e/ou um vídeo para analisar e salvar o resultado deste paciente." : "Selecione um paciente para consultar os resultados."}</p><Button className="action" onClick={() => navigate(selected ? "avaliacao" : "pacientes")}>{selected ? "Iniciar avaliação" : "Ir para pacientes"}<ArrowRight /></Button></section><Explanation /></div>;
  const { writing, hands } = result;
  return <div className="view-stack">
    <div className="analysis-heading"><span className="pill">Registro #{result.id} · {dateLabel(result.createdAt)}</span><Button variant="outline" className="action secondary" onClick={() => navigate("avaliacao")}>Nova avaliação<ArrowRight /></Button></div>
    {result.status !== "completed" && <div className="notice attention" role="status"><Info /><p>{hands?.status === "legacy" ? "A análise da mão deste registro usa um método anterior. A análise da escrita permanece disponível quando realizada." : `Este registro tem dados insuficientes em ${result.status === "partial" ? "uma das análises" : "todas as análises enviadas"}. Confira as mensagens e repita a captura se necessário.`}</p></div>}
    <section className="panel analysis-panel"><div className="panel-heading"><h2><PenLine /> Análise da escrita</h2><span className="pill">{writing ? "Fotografia processada" : "Não enviada"}</span></div>
      {writing?.metrics ? <><div className="analysis-metrics">{labels.map(item => <article className="metric" key={item.key}><div><p>{item.title}</p><strong>{indexValue(writing.metrics?.[item.key])}</strong><small>{item.note}</small></div></article>)}</div><p className="muted">{writing.components} componentes e {writing.lines} linhas identificadas. Use fotos com enquadramento e iluminação semelhantes nas comparações.</p></> : <p>{writing?.message || "Nenhuma fotografia foi enviada nesta avaliação."}</p>}
    </section>
    <HandAnalysis hands={hands} /><Explanation />
  </div>;
}

export function HistoryView({ selected, assessments, navigate, openResult }: { selected?: Patient; assessments: Assessment[]; navigate: (view: View) => void; openResult: (id: string) => void }) {
  const [date, setDate] = useState("");
  const filtered = assessments.filter(item => !date || localDay(item.createdAt) === date);
  return <div className="view-stack"><div className="history-controls"><span className="pill">{assessments.length} registros salvos</span><div className="date-filter"><Label htmlFor="history-date"><CalendarDays /> Data</Label><Input id="history-date" type="date" value={date} onChange={e => setDate(e.target.value)} />{date && <Button variant="ghost" size="icon" aria-label="Limpar filtro de data" onClick={() => setDate("")}><X /></Button>}</div></div>
    <section className="panel analysis-panel"><div className="panel-heading"><h2><History /> Histórico de avaliações</h2></div>
      {filtered.length ? <Table><TableHeader><TableRow><TableHead>Data</TableHead><TableHead>Preensão estimada</TableHead><TableHead>Legibilidade estimada</TableHead><TableHead>Alinhamento</TableHead><TableHead>Resultado</TableHead></TableRow></TableHeader><TableBody>{filtered.map(item => <TableRow key={item.id}><TableCell>{dateLabel(item.createdAt)}</TableCell><TableCell>{handLabel(item.hands)}</TableCell><TableCell>{indexValue(item.writing?.metrics?.legibility)}</TableCell><TableCell>{indexValue(item.writing?.metrics?.alignment)}</TableCell><TableCell><Button variant="ghost" className="text-action" onClick={() => openResult(item.id)}>Ver detalhes<ArrowRight /></Button></TableCell></TableRow>)}</TableBody></Table> : <div className="analysis-empty"><h3>{date ? "Nenhum registro nesta data" : "O histórico começa na primeira avaliação"}</h3><p>{selected ? "As análises deste paciente serão salvas aqui automaticamente." : "Selecione um paciente para consultar seu histórico."}</p><Button className="action" onClick={() => date ? setDate("") : navigate(selected ? "avaliacao" : "pacientes")}>{date ? "Limpar filtro" : "Começar"}<ArrowRight /></Button></div>}
    </section><Explanation />
  </div>;
}
