"use client";

import { type FormEvent, type ReactNode, useEffect, useRef, useState } from "react";
import { Activity, ArrowLeft, ArrowRight, BarChart3, CalendarDays, Check, CheckCircle2, ChevronRight, ClipboardCheck, Clock3, Hand, History, Home, Info, Mail, PenLine, Phone, Plus, Search, ShieldCheck, TrendingUp, UserRound, UsersRound, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Empty, EmptyHeader, EmptyTitle, EmptyDescription, EmptyMedia } from "@/components/ui/empty";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Toaster } from "@/components/ui/sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MediaInput } from "./media-input";
import { PasswordFields } from "./password-fields";
import { type Assessment, type Draft, type Patient, type PatientForm, type Professional, emptyPatientForm, emptyProfessional, initials, maskPhone, normalize, validatePerson } from "@/lib/grafisense";

import { ResultsView, HistoryView } from "./analysis-views";
import { api, ApiError } from "@/lib/api";

type View = "inicio" | "pacientes" | "avaliacao" | "resultados" | "historico";
const navItems: { id: View; label: string; icon: typeof Home }[] = [
  { id: "inicio", label: "Visão geral", icon: Home },
  { id: "pacientes", label: "Pacientes", icon: UsersRound },
  { id: "avaliacao", label: "Nova avaliação", icon: ClipboardCheck },
  { id: "resultados", label: "Resultados", icon: BarChart3 },
  { id: "historico", label: "Histórico", icon: History },
];
const viewCopy: Record<View, { title: string; description: string }> = {
  inicio: { title: "Seu olhar. Cada trajetória.", description: "Um olhar para cada paciente. Um lugar para acompanhar cada etapa." },
  pacientes: { title: "Pessoas que você acompanha.", description: "Encontre um paciente para iniciar uma avaliação ou consultar o histórico." },
  avaliacao: { title: "Um novo olhar sobre a escrita.", description: "Grave a mão pela câmera e envie a fotografia da escrita do paciente." },
  resultados: { title: "Os detalhes, lado a lado.", description: "Indicadores da mão e da escrita para apoiar o seu acompanhamento." },
  historico: { title: "Cada etapa faz parte.", description: "Acompanhe as avaliações de cada paciente ao longo do tempo." },
};

function Brand() {
  return <div className="brand"><span className="brand-symbol" aria-hidden="true"><span>g</span><i /></span><span><strong>Grafi<span>Sense</span></strong><small>Cuidado em cada traço</small></span></div>;
}

function Signature() {
  return <svg className="signature-mark" viewBox="0 0 680 300" fill="none" aria-hidden="true" focusable="false"><path d="M-20 208C52 175 76 67 120 78c47 12-61 193-78 143C22 164 230 105 213 48c-18-62-153 239-51 202 48-18 92-121 76-111-42 26-56 127-9 99 73-44 119-195 86-169-31 24-63 173-18 155 55-22 49-94 66-83 23 16-29 97 5 77 44-25 56-78 68-64 9 11-21 46 0 49 25 5 54-56 63-47 14 16-10 59 15 44 47-30 126-79 181-44" /><path d="M209 269c104-25 278-46 392-31" /></svg>;
}

function Notice({ children, attention = false }: { children: ReactNode; attention?: boolean }) {
  return <div className={"notice " + (attention ? "attention" : "")}><Info aria-hidden="true" /><p>{children}</p></div>;
}

function Blank({ icon: Icon, title, description, children, compact = false }: { icon: typeof Home; title: string; description: string; children?: ReactNode; compact?: boolean }) {
  return <Empty className={"blank " + (compact ? "compact" : "")}><EmptyHeader><EmptyMedia className="blank-icon"><Icon aria-hidden="true" /></EmptyMedia><EmptyTitle className="blank-title">{title}</EmptyTitle><EmptyDescription className="blank-description">{description}</EmptyDescription></EmptyHeader>{children}</Empty>;
}

function ProfessionalFields({ value, onChange, errors }: { value: Professional; onChange: (person: Professional) => void; errors: Record<string, string> }) {
  const fields = [{ key: "name", label: "Nome completo", placeholder: "Seu nome completo" }, { key: "email", label: "E-mail", placeholder: "nome@exemplo.com" }] as const;
  return <div className="form-grid">{fields.map(field => <div className="form-field full" key={field.key}>
    <Label htmlFor={"pro-" + field.key}>{field.label}</Label>
    <Input id={"pro-" + field.key} type={field.key === "email" ? "email" : "text"} autoComplete={field.key} maxLength={field.key === "name" ? 120 : 254} value={value[field.key]} placeholder={field.placeholder} aria-invalid={!!errors[field.key]} aria-describedby={errors[field.key] ? "pro-" + field.key + "-error" : undefined} onChange={event => onChange({ ...value, [field.key]: event.target.value })} />
    {errors[field.key] && <p id={"pro-" + field.key + "-error"} className="field-error">{errors[field.key]}</p>}
  </div>)}</div>;
}

function PersonFields({ value, onChange, errors, prefix }: { value: PatientForm; onChange: (person: PatientForm) => void; errors: Record<string, string>; prefix: string }) {
  const fields: { key: keyof PatientForm; label: string; placeholder: string; type?: string }[] = [
    { key: "name", label: "Nome completo", placeholder: "Nome completo do paciente" },
    { key: "phone", label: "Telefone do responsável", placeholder: "(11) 90000-0000", type: "tel" },
    { key: "email", label: "E-mail do responsável", placeholder: "nome@exemplo.com", type: "email" },
  ];
  return <div className="form-grid">{fields.map(field => <div className="form-field full" key={field.key}>
    <Label htmlFor={prefix + field.key}>{field.label}</Label>
    <Input id={prefix + field.key} type={field.type || "text"} inputMode={field.key === "phone" ? "tel" : field.key === "email" ? "email" : "text"} autoComplete="off" maxLength={field.key === "name" ? 120 : field.key === "email" ? 254 : 15} value={value[field.key] ?? ""} placeholder={field.placeholder} aria-invalid={!!errors[field.key]} aria-describedby={errors[field.key] ? prefix + field.key + "-error" : undefined} onChange={event => onChange({ ...value, [field.key]: field.key === "phone" ? maskPhone(event.target.value) : event.target.value })} />
    {errors[field.key] && <p id={prefix + field.key + "-error"} className="field-error">{errors[field.key]}</p>}
  </div>)}</div>;
}

function ProfessionalEntry({ initial, onContinue, onLogout, connectionError }: { initial: Professional; onContinue: (value: Professional) => Promise<void>; onLogout: () => Promise<void>; connectionError?: string }) {
  const [form, setForm] = useState(initial);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [login, setLogin] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  function changeAccessMode() {
    setLogin(value => !value);
    setPassword(""); setConfirm(""); setErrors({});
  }
  function clearPasswordErrors() {
    setErrors(current => {
      const next = { ...current };
      delete next.password; delete next.confirm;
      return next;
    });
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (busy) return;
    const nextErrors = login ? {} : validatePerson(form, true);
    if (!initial.id && !login && (password.length < 8 || password.length > 128)) nextErrors.password = "Use uma senha de 8 a 128 caracteres.";
    if (!initial.id && !login && !confirm) nextErrors.confirm = "Digite a senha novamente para confirmar.";
    else if (!initial.id && !login && password !== confirm) nextErrors.confirm = "As senhas devem ser iguais.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("pro-" + Object.keys(nextErrors)[0])?.focus(); return; }
    setBusy(true);
    try {
      const value = initial.id ? await api.updateProfessional(form) : login ? await api.login(form.email, password) : await api.register({ ...form, password });
      await onContinue(value);
      toast.success(initial.id ? "Cadastro atualizado." : login ? "Bem-vindo de volta." : "Conta criada.");
    } catch (error) { if (error instanceof ApiError) setErrors(error.fields); toast.error(error instanceof Error ? error.message : "Não foi possível entrar."); }
    finally { setBusy(false); }
  }
  return <div className="entry-layout">
    <header className="entry-header"><Brand /><Button variant="ghost" className="text-action" disabled={busy} onClick={() => initial.id ? void onLogout() : changeAccessMode()}>{initial.id ? "Sair da conta" : login ? "Criar uma conta" : "Já tenho uma conta"}<ArrowRight /></Button></header>
    <main>
      <section className="entry-hero">
        <Signature />
        <span className="eyebrow">TERAPIA OCUPACIONAL · ACOMPANHAMENTO DA ESCRITA</span>
        <h1>Todo traço tem<br /><em>uma história.</em></h1>
        <p>Um espaço para observar com atenção.<br />E acompanhar cada paciente no seu próprio ritmo.</p>
        <div className="hero-caption"><span>O olhar é seu.</span><span>Os registros ficam juntos.</span></div>
      </section>
      <section className="entry-registration" aria-labelledby="entry-form-title">
        <div className="entry-form-heading"><div><span className="eyebrow">01 / ÁREA DO PROFISSIONAL</span><h2 id="entry-form-title">{initial.id ? "Seu cadastro." : login ? "Acesse sua conta." : "Seu cuidado começa aqui."}</h2></div><span className="entry-form-context"><UserRound /> Cadastro profissional</span></div>
        <form onSubmit={submit} noValidate>
          {connectionError && <Notice attention>O servidor está indisponível. Você pode conferir os campos; para entrar ou salvar o cadastro, é necessário conectar ao servidor.</Notice>}
          {login ? <div className="form-field"><Label htmlFor="login-email">E-mail</Label><Input id="login-email" type="email" autoComplete="username" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div> : <ProfessionalFields value={form} onChange={setForm} errors={errors} />}
          {!initial.id && <PasswordFields key={login ? "login" : "create"} mode={login ? "login" : "create"} password={password} confirmation={confirm} onPasswordChange={value => { setPassword(value); clearPasswordErrors(); }} onConfirmationChange={value => { setConfirm(value); clearPasswordErrors(); }} errors={errors} />}
          <div className="entry-form-bottom"><div className="demo-note"><ShieldCheck /><p>Dados usados para organizar o acompanhamento dos pacientes e permitir acesso à sua conta.</p></div><Button type="submit" className="action" disabled={busy}>{busy ? "Aguarde…" : initial.id ? "Salvar e voltar ao painel" : login ? "Entrar" : "Cadastrar e acessar"}<ArrowRight /></Button></div>
        </form>
      </section>
      <section className="entry-chapters" aria-label="Etapas do acompanhamento">
        {[{ n: "01", title: "Uma pessoa.", text: "Reúna os dados de cada paciente e encontre tudo em um só lugar.", icon: UsersRound }, { n: "02", title: "Muitos detalhes.", text: "Registre os movimentos da mão e a fotografia da escrita.", icon: Hand }, { n: "03", title: "Novas perspectivas.", text: "Consulte os resultados disponíveis e o histórico de avaliações.", icon: TrendingUp }].map(item => <article key={item.n}><div className="chapter-top"><span>{item.n}</span><item.icon aria-hidden="true" /></div><h2>{item.title}</h2><p>{item.text}</p></article>)}
      </section>
    </main>
    <footer className="entry-foot"><span>GrafiSense / Cuidado em cada traço</span><span>Uma ferramenta de apoio à avaliação profissional.</span></footer>
    <Toaster theme="light" position="top-right" closeButton />
  </div>;
}

function AppHeader({ view, navigate, professional, editProfessional, count }: { view: View; navigate: (view: View) => void; professional: Professional; editProfessional: () => void; count: number }) {
  return <header className="app-header"><div className="app-header-inner">
    <Brand />
    <nav className="primary-nav" aria-label="Navegação principal">{navItems.map(item => <button key={item.id} type="button" aria-current={view === item.id ? "page" : undefined} onClick={() => navigate(item.id)}><item.icon aria-hidden="true" /><span>{item.label}</span>{item.id === "pacientes" && count > 0 && <span className="nav-count">{count}</span>}</button>)}</nav>
    <button className="profile-button" onClick={editProfessional} aria-label={professional.name ? "Editar cadastro de " + professional.name : "Completar cadastro profissional"}><span className="avatar">{professional.name ? initials(professional.name) : <UserRound />}</span><span><strong>{professional.name || "Meu espaço"}</strong><small>{professional.name ? "Meu cadastro" : "Completar cadastro"}</small></span><ChevronRight aria-hidden="true" /></button>
  </div></header>;
}

function Metric({ label, value, note, icon: Icon, success = false }: { label: string; value: string; note: string; icon: typeof Home; success?: boolean }) {
  return <div className="metric"><div><p>{label}</p><strong>{value}</strong><small>{note}</small></div><span className={"metric-icon " + (success ? "green" : "")}><Icon /></span></div>;
}

function Dashboard({ patients, professional, navigate, addPatient, selectPatient, assessments }: { assessments: Assessment[]; patients: Patient[]; professional: Professional; navigate: (view: View) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  return <div className="dashboard">
    <section className="dashboard-cover">
      <div className="cover-story"><Signature /><span className="eyebrow">{professional.name ? "BOAS-VINDAS, " + professional.name.split(" ")[0].toLocaleUpperCase("pt-BR") : "UM OLHAR ATENTO FAZ A DIFERENÇA"}</span><h2>A escrita muda.<br /><em>O cuidado acompanha.</em></h2><p>Registre os pequenos detalhes de hoje.<br />Construa o acompanhamento de amanhã.</p><Button variant="outline" className="action cover-action" onClick={() => navigate(patients.length ? "avaliacao" : "pacientes")}>Iniciar uma avaliação <ArrowRight /></Button><span className="cover-caption">MÃO · ESCRITA · EVOLUÇÃO</span></div>
      <div className="cover-next"><span className="eyebrow">O PRÓXIMO ENCONTRO</span><span className="cover-plus" aria-hidden="true"><Plus /></span><h3>{patients.length ? "Mais uma história para acompanhar." : "Comece por alguém."}</h3><p>{patients.length ? "Adicione um paciente ao seu espaço de acompanhamento." : "Cadastre seu primeiro paciente. Cada trajetória merece o seu próprio registro."}</p><Button variant="ghost" className="text-action" onClick={addPatient}>Cadastrar paciente <ArrowRight /></Button></div>
    </section>
    <section className="overview-section" aria-labelledby="overview-title"><div className="section-kicker"><span>01 / VISÃO DO ACOMPANHAMENTO</span><h2 id="overview-title">Seu trabalho, em perspectiva.</h2></div><div className="metrics-grid">
      <Metric label="Pacientes cadastrados" value={String(patients.length).padStart(2, "0")} note="Na sua conta" icon={UsersRound} />
      <Metric label="Análises registradas" value={String(assessments.length).padStart(2, "0")} note="Salvas no banco local" icon={ClipboardCheck} />
      <Metric label="Pacientes com registros" value={String(new Set(assessments.map(item => item.patientId)).size).padStart(2, "0")} note="Com histórico disponível" icon={TrendingUp} success />
      <Metric label="Análises de escrita" value={String(assessments.filter(item => item.writing?.status === "ok").length).padStart(2, "0")} note="Com indicadores disponíveis" icon={Activity} />
    </div></section>
    <section className="recent-section" aria-labelledby="recent-title"><div className="section-heading"><div><span className="eyebrow">02 / PESSOAS, ANTES DOS NÚMEROS</span><h2 id="recent-title">Pacientes recentes.</h2></div><Button variant="ghost" className="text-action" onClick={() => navigate("pacientes")}>Ver todos os pacientes <ArrowRight /></Button></div>
      {patients.length ? <div className="recent-patients">{patients.slice(-4).reverse().map((patient, index) => <button key={patient.id} onClick={() => selectPatient(patient.id, "avaliacao")}><span className="row-number">{String(index + 1).padStart(2, "0")}</span><span className="avatar">{initials(patient.name)}</span><span className="recent-person"><strong>{patient.name}</strong><small>{patient.email}</small></span><span className="status"><Clock3 /> {assessments.some(item => item.patientId === patient.id) ? "Com histórico" : "Sem avaliação"}</span><span className="recent-patient-action">Avaliar <ArrowRight /></span></button>)}</div> : <div className="first-patient"><span className="empty-portrait" aria-hidden="true"><UsersRound /></span><div><h3>Um espaço esperando a primeira história.</h3><p>Cadastre um paciente para começar a organizar suas avaliações.</p></div><Button variant="outline" className="action secondary" onClick={addPatient}><Plus /> Primeiro paciente</Button></div>}
    </section>
    <nav className="workflow-links" aria-label="Etapas do acompanhamento">{[{ n: "01", label: "Organizar pacientes", target: "pacientes" as View }, { n: "02", label: "Observar a escrita", target: "avaliacao" as View }, { n: "03", label: "Acompanhar a evolução", target: "historico" as View }].map(item => <button key={item.n} onClick={() => navigate(item.target)}><span>{item.n}</span><strong>{item.label}</strong><ArrowRight /></button>)}</nav>
  </div>;
}

function PatientsView({ patients, selectedId, search, setSearch, addPatient, selectPatient, assessments }: { assessments: Assessment[]; patients: Patient[]; selectedId: string; search: string; setSearch: (search: string) => void; addPatient: () => void; selectPatient: (id: string, view: View) => void }) {
  const query = normalize(search.trim());
  const filtered = patients.filter(patient => normalize(patient.name).includes(query) || normalize(patient.email).includes(query));
  return <section className="patients-view" aria-label="Lista de pacientes">
    <div className="patient-toolbar"><div className="patient-total"><strong>{String(patients.length).padStart(2, "0")}</strong><span>{patients.length === 1 ? "paciente cadastrado" : "pacientes cadastrados"}</span></div><div className="search-field"><Search /><Input aria-label="Buscar paciente por nome ou e-mail" placeholder="Buscar nome ou e-mail" value={search} onChange={event => setSearch(event.target.value)} />{search && <button onClick={() => setSearch("")} aria-label="Limpar busca"><X /></button>}</div></div>
    {!filtered.length ? <div className="panel directory-empty"><Blank icon={patients.length ? Search : UsersRound} title={patients.length ? "Nenhum paciente encontrado." : "A primeira história começa aqui."} description={patients.length ? "Tente outro nome ou e-mail para encontrar o paciente." : "Adicione os dados do paciente. Os registros e as avaliações ganham um lugar para ficar juntos."}>{patients.length ? <Button variant="outline" className="action secondary" onClick={() => setSearch("")}>Limpar busca</Button> : <Button className="action" onClick={addPatient}><Plus /> Cadastrar primeiro paciente</Button>}</Blank></div> : <div className="patient-directory">{filtered.map((patient, index) => <article key={patient.id} className={"directory-row " + (selectedId === patient.id ? "selected" : "")}>
      <span className="row-number">{String(index + 1).padStart(2, "0")}</span>
      <div className="directory-person"><span className="avatar">{initials(patient.name)}</span><div><h2>{patient.name}</h2><span className="status"><Clock3 /> {assessments.some(item => item.patientId === patient.id) ? "Com histórico" : "Sem avaliação"}</span></div></div>
      <dl className="patient-contact"><div><dt><Mail /><span className="sr-only">E-mail</span></dt><dd title={patient.email}>{patient.email}</dd></div><div><dt><Phone /><span className="sr-only">Telefone do responsável</span></dt><dd>{patient.phone}</dd></div></dl>
      <div className="directory-actions"><Button variant="ghost" className="text-action" onClick={() => selectPatient(patient.id, "historico")}><History /> Histórico</Button><Button className="action" onClick={() => selectPatient(patient.id, "avaliacao")}>Avaliar <ArrowRight /></Button></div>
    </article>)}</div>}
  </section>;
}

function PatientPicker({ patients, selectedId, onSelect, addPatient }: { patients: Patient[]; selectedId: string; onSelect: (id: string) => void; addPatient: () => void }) {
  return <div className="patient-picker"><span className="section-icon"><UserRound /></span><div className="picker-field"><Label htmlFor="active-patient">Paciente selecionado</Label><Select value={selectedId} onValueChange={onSelect} disabled={!patients.length}><SelectTrigger id="active-patient"><SelectValue placeholder="Cadastre um paciente para começar" /></SelectTrigger><SelectContent>{patients.map(patient => <SelectItem key={patient.id} value={patient.id}>{patient.name}</SelectItem>)}</SelectContent></Select></div><Button variant="ghost" className="text-action" onClick={addPatient}><Plus /> Novo paciente</Button></div>;
}

function AssessmentView({ selected, draft, updateDraft, showResults, addPatient, busy, error }: { selected?: Patient; draft: Draft; updateDraft: (draft: Draft) => void; showResults: () => void; addPatient: () => void; busy: boolean; error: string }) {
  const readyCount = Number(!!draft.video) + Number(!!draft.image);
  return <div className="view-stack">{!selected && <Notice>Cadastre ou selecione um paciente para habilitar a câmera e o envio da fotografia. <button className="inline-link" onClick={addPatient}>Cadastrar paciente</button></Notice>}
    <div className="assessment-progress"><span className={selected ? "complete" : ""}>{selected ? <CheckCircle2 /> : <span className="step-dot">1</span>} Paciente</span><i /><span className={selected ? "current" : ""}><span className="step-dot">2</span> Vídeo e fotografia</span><i /><span><span className="step-dot">3</span> Resultados</span></div>
    <div className="assessment-columns"><section className="panel collection-panel"><div className="collection-heading"><span className="section-icon"><Hand /></span><div><span className="eyebrow">ETAPA 01 · VÍDEO</span><h2>Preensão da mão</h2></div>{draft.video && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Estimativa experimental de postura palmar ou em pinça. Mantenha apenas a mão que segura o lápis visível. A análise utiliza uma amostra ao longo do vídeo; uma gravação curta e nítida costuma ser suficiente. Se a posição não estiver clara, o resultado será inconclusivo.</p><MediaInput kind="video" file={draft.video} disabled={!selected || busy} onChange={file => updateDraft({ ...draft, video: file })} /><div className="collection-tip"><Check /> Mão, lápis e papel visíveis; câmera estável.</div></section>
    <section className="panel collection-panel writing-panel"><div className="collection-heading"><span className="section-icon"><PenLine /></span><div><span className="eyebrow">ETAPA 02 · FOTOGRAFIA</span><h2>Espaçamento e legibilidade</h2></div>{draft.image && <CheckCircle2 className="success-icon" />}</div><p className="collection-description">Fotografe a folha para observar o espaçamento e a legibilidade da escrita.</p><MediaInput kind="image" file={draft.image} disabled={!selected || busy} onChange={file => updateDraft({ ...draft, image: file })} /><div className="collection-tip"><Check /> Texto nítido, folha enquadrada e sem sombras.</div></section></div>
    {error && <div className="notice attention" role="alert"><Info /><p>{error}</p></div>}
    {busy && <div className="notice" role="status"><Info /><p>Análise em andamento. A primeira análise carrega os módulos de processamento e pode demorar um pouco mais.</p></div>}
    <div className="assessment-bottom"><div><span className={"ready-pill " + (readyCount === 2 ? "ready" : "")}>{readyCount === 2 ? <CheckCircle2 /> : <ClipboardCheck />}{readyCount}/2 arquivos selecionados</span><p>Envie um ou ambos os arquivos. Os resultados serão salvos no histórico.</p></div><Button className="action" disabled={!readyCount || !selected || busy} onClick={showResults}>{busy ? "Analisando… aguarde" : "Analisar e salvar"} <ArrowRight /></Button></div>
  </div>;
}

export default function HomePage() {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [assessmentId, setAssessmentId] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState("");
  const accountEpoch = useRef(0);
  const [started, setStarted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [connectionError, setConnectionError] = useState("");
  const [savingPatient, setSavingPatient] = useState(false);
  const [professional, setProfessional] = useState<Professional>(emptyProfessional);
  const [view, setView] = useState<View>("inicio");
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [search, setSearch] = useState("");
  const [dialog, setDialog] = useState(false);
  const [patientForm, setPatientForm] = useState<PatientForm>(emptyPatientForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const heading = useRef<HTMLHeadingElement>(null);
  const selected = patients.find(patient => patient.id === selectedId);
  const draft = drafts[selectedId] || {};
  const patientAssessments = assessments.filter(item => item.patientId === selectedId);
  const currentAssessment = patientAssessments.find(item => item.id === assessmentId) || patientAssessments[0];
  const activePatientId = useRef(selectedId);
  activePatientId.current = selectedId;
  useEffect(() => { setAssessmentId(""); setAnalysisError(""); }, [selectedId]);
  const navigate = (next: View) => { setView(next); requestAnimationFrame(() => { heading.current?.focus(); window.scrollTo({ top: 0, behavior: "instant" }); }); };
  const addPatient = () => { setPatientForm(emptyPatientForm); setErrors({}); setDialog(true); };
  const selectPatient = (id: string, next: View) => { setSelectedId(id); navigate(next); };
  async function submitPatient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (savingPatient) return;
    const nextErrors = validatePerson(patientForm);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) { document.getElementById("patient-" + Object.keys(nextErrors)[0])?.focus(); return; }
    setSavingPatient(true);
    try {
      const newPatient = await api.createPatient(patientForm);
      setPatients(current => [...current, newPatient]); setSelectedId(newPatient.id); setDialog(false); toast.success("Paciente cadastrado no banco de dados.");
    } catch (error) { if (error instanceof ApiError) setErrors(error.fields); toast.error(error instanceof Error ? error.message : "Erro ao cadastrar paciente."); }
    finally { setSavingPatient(false); }
  }
  async function loadAccount(value: Professional) {
    const [list, records] = await Promise.all([api.patients(), api.assessments()]);
    setProfessional(value); setPatients(list); setAssessments(records); setSelectedId(list[0]?.id || ""); setConnectionError(""); enterDashboard();
  }
  async function restoreSession() {
    setLoading(true); setConnectionError("");
    try { await loadAccount(await api.me()); }
    catch (error) { if (!(error instanceof ApiError && error.status === 401)) setConnectionError(error instanceof Error ? error.message : "Falha ao carregar cadastros."); }
    finally { setLoading(false); }
  }
  useEffect(() => { void restoreSession(); }, []);
  async function logout() {
    try { await api.logout(); accountEpoch.current += 1; setAssessments([]); setAssessmentId(""); setAnalysisError(""); setProfessional(emptyProfessional); setPatients([]); setSelectedId(""); setDrafts({}); setStarted(false); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Erro ao sair."); }
  }
  async function analyze() {
    if (!selectedId || analyzing || (!draft.video && !draft.image)) return;
    const patientId = selectedId;
    const epoch = accountEpoch.current;
    setAnalyzing(true); setAnalysisError("");
    try {
      const result = await api.analyze(patientId, draft);
      if (accountEpoch.current !== epoch) return;
      setAssessments(current => [result, ...current]);
      setDrafts(current => ({ ...current, [patientId]: {} }));
      if (activePatientId.current === patientId) { setAssessmentId(result.id); navigate("resultados"); }
      toast.success("Análise salva no histórico do paciente.");
    } catch (error) {
      if (accountEpoch.current !== epoch) return;
      const message = error instanceof Error ? error.message : "Não foi possível concluir a análise.";
      setAnalysisError(message); toast.error(message);
    } finally { setAnalyzing(false); }
  }
  const enterDashboard = () => { setStarted(true); requestAnimationFrame(() => { heading.current?.focus(); window.scrollTo({ top: 0, behavior: "instant" }); }); };
  if (loading) return <main className="gs-main" aria-live="polite">Carregando sua conta…</main>;
  if (!started) return <ProfessionalEntry initial={professional} onContinue={loadAccount} onLogout={logout} connectionError={connectionError} />;
  return <div className="app-shell"><a href="#page-heading" className="skip-link">Ir para o conteúdo</a><AppHeader view={view} navigate={navigate} professional={professional} count={patients.length} editProfessional={() => { setStarted(false); window.scrollTo({ top: 0, behavior: "instant" }); }} /><main className="gs-main">
    <div className="workspace-meta"><span>ÁREA PROFISSIONAL <span aria-hidden="true">/</span> {navItems.find(item => item.id === view)?.label}</span><span className="prototype-label"><i /> Banco local conectado</span></div>
    <div className="workspace"><div className="page-heading"><div><span className="eyebrow">{view === "inicio" ? "GRAFISENSE / VISÃO GERAL" : "GRAFISENSE / " + navItems.find(item => item.id === view)?.label.toLocaleUpperCase("pt-BR")}</span><h1 id="page-heading" ref={heading} tabIndex={-1}>{viewCopy[view].title}</h1><p>{viewCopy[view].description}</p></div>{view === "pacientes" && <Button className="action" onClick={addPatient}><Plus /> Cadastrar paciente</Button>}</div>
      {view === "inicio" && <Dashboard assessments={assessments} patients={patients} professional={professional} navigate={navigate} addPatient={addPatient} selectPatient={selectPatient} />}
      {view === "pacientes" && <PatientsView assessments={assessments} patients={patients} selectedId={selectedId} search={search} setSearch={setSearch} addPatient={addPatient} selectPatient={selectPatient} />}
      {["avaliacao", "resultados", "historico"].includes(view) && <PatientPicker patients={patients} selectedId={selectedId} onSelect={setSelectedId} addPatient={addPatient} />}
      {view === "avaliacao" && <AssessmentView selected={selected} draft={draft} updateDraft={value => { if (selectedId) setDrafts(current => ({ ...current, [selectedId]: value })); }} showResults={() => void analyze()} addPatient={addPatient} busy={analyzing} error={analysisError} />}
      {view === "resultados" && <ResultsView selected={selected} result={currentAssessment} navigate={navigate} />}
      {view === "historico" && <HistoryView key={selectedId} selected={selected} assessments={patientAssessments} navigate={navigate} openResult={id => { setAssessmentId(id); navigate("resultados"); }} />}
    </div></main><footer className="app-footer"><span>GrafiSense <span aria-hidden="true">·</span> Apoio ao profissional de TO</span><span><Info /> Cadastros armazenados na sua conta</span></footer>
  <Dialog open={dialog} onOpenChange={setDialog}><DialogContent className="gs-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar cadastro"><X /></Button></DialogClose><DialogHeader><span className="section-icon"><UserRound /></span><DialogTitle>Cadastrar paciente</DialogTitle><DialogDescription>Informe os dados essenciais para iniciar o acompanhamento.</DialogDescription></DialogHeader><form onSubmit={submitPatient} noValidate><PersonFields value={patientForm} onChange={setPatientForm} prefix="patient-" errors={errors} /><div className="demo-note"><ShieldCheck /><p>O paciente ficará vinculado à sua conta. Informe o contato do responsável para o acompanhamento.</p></div><DialogFooter><Button variant="outline" type="button" className="action secondary" onClick={() => setDialog(false)}>Cancelar</Button><Button type="submit" className="action" disabled={savingPatient}><Plus /> {savingPatient ? "Salvando…" : "Cadastrar paciente"}</Button></DialogFooter></form></DialogContent></Dialog><Toaster theme="light" position="top-right" closeButton />
  </div>;
}
