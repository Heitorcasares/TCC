# Vídeos: tamanho, duração e formatos

A versão 1.3.0 já vem com os limites ampliados e o front compilado. Para usar, abra `iniciar.bat` no Windows depois de atualizar os arquivos.

| Item | Limite atual |
| --- | --- |
| Tamanho do vídeo | 250 MB |
| Duração do vídeo enviado ou gravado | 5 minutos |
| Extensões aceitas para envio | MP4, WebM, MOV, AVI, MKV, M4V |
| Imagem da escrita | 10 MB |
| Quadros avaliados pelo detector | Até 60, selecionados ao longo do vídeo |
| Tempo de processamento | Até 120 segundos |

## Como saber o tipo do vídeo

Ao escolher o arquivo, a tela mostra seu nome e a extensão, por exemplo `atividade.mp4` / `Extensão: MP4`. Também mostra o tamanho e, quando o navegador consegue ler, a duração e a resolução. Se a prévia não for compatível, é possível tentar enviar: a leitura final acontece no servidor. Os resultados guardam a extensão, a resolução e a duração lida pela análise.

Extensão é o final do nome. O conteúdo precisa ter um codec que o leitor suporte. Renomear `video.avi` para `video.mp4` não converte o vídeo. Quando a leitura falhar, exporte o vídeo como MP4 com vídeo H.264 em seu editor. O programa não faz conversão automática.

## Como alterar novamente

Abra `config/media.json` em um editor de texto. Estes campos controlam os limites:

```json
{
  "maxVideoMB": 250,
  "maxVideoSeconds": 300,
  "maxImageMB": 10,
  "videoExtensions": ["mp4", "webm", "mov", "avi", "mkv", "m4v"],
  "maxSampledFrames": 60,
  "maxProcessingSeconds": 120,
  "thumbnailMaxSide": 640
}
```

- `maxVideoMB`: tamanho máximo em unidades de 1024 × 1024 bytes.
- `maxVideoSeconds`: duração máxima em segundos; 300 = 5 minutos.
- `videoExtensions`: extensões permitidas, em letras minúsculas e sem ponto. Acrescentar uma extensão à lista não instala codecs.
- `maxSampledFrames`: máximo de imagens analisadas; use inteiro de pelo menos 3. Aumentar esse valor exige mais memória e processamento.
- `maxProcessingSeconds`: prazo do processamento, separado da duração do vídeo.
- `thumbnailMaxSide`: lado máximo das imagens reduzidas usadas na amostragem.

Depois de alterar a configuração:

1. Feche o servidor com `Ctrl+C`.
2. Para recompilar a interface, com Node.js compatível instalado, execute na pasta do projeto:

   ```bat
   npm ci
   npm run build
   ```

3. Abra `iniciar.bat` novamente e recarregue o navegador com `Ctrl+Shift+R`.

A etapa de compilação é necessária porque a tela lê a configuração quando o front é compilado. Alterar só o JSON e reiniciar atualiza o servidor, mas deixa o front antigo com seus limites anteriores.

Vídeos longos são avaliados por amostragem. Isso serve para estimar uma postura predominante e pode não captar movimentos breves. A classificação palmar/pinça continua experimental; esta atualização amplia os arquivos aceitos e não mede clinicamente a flexibilidade dos dedos.

## Gravações WebM sem taxa de quadros confiável

A versão 1.2.1 corrige esse caso usando os tempos de cada quadro. Não é preciso converter a gravação apenas porque o campo FPS está ausente ou informa 1000. Na tela de resultados, a duração calculada por esse caminho é identificada como aproximada. A última fração de duração não é conhecida e é estimada pelos intervalos recentes. Se o arquivo também não tiver tempos utilizáveis, o sistema pedirá uma nova exportação em vez de inventar uma taxa.
