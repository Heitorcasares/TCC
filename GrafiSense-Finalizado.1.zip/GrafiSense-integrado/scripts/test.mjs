import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const python = path.join(root, process.platform === 'win32' ? '.venv/Scripts/python.exe' : '.venv/bin/python');
const child = spawn(python, ['-m', 'pytest', '-q', 'tests'], { cwd: root, stdio: 'inherit' });
child.on('error', () => { console.error('Instale requirements-dev.txt no ambiente .venv para testar.'); process.exitCode = 1; });
child.on('exit', code => { process.exitCode = code ?? 1; });
