@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
py -3.12 --version >nul 2>&1
if not errorlevel 1 (
  py -3.12 -m venv .venv
  goto check
)
py -3.11 --version >nul 2>&1
if not errorlevel 1 (
  py -3.11 -m venv .venv
  goto check
)
python --version >nul 2>&1
if errorlevel 1 goto missing
python -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,12) else 1)"
if errorlevel 1 goto missing
python -m venv .venv
:check
if not exist ".venv\Scripts\python.exe" goto failed
:install
echo Instalando dependencias. A primeira instalacao precisa de internet.
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Instalacao concluida. Agora abra iniciar.bat.
pause
exit /b 0
:missing
echo Instale Python 3.12 de 64 bits em https://www.python.org/downloads/
echo Marque Add Python to PATH. Depois execute este arquivo novamente.
pause
exit /b 1
:failed
echo A instalacao falhou. Confira a mensagem acima e a conexao com a internet.
pause
exit /b 1
