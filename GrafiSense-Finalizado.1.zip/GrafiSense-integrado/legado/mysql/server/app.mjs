import { createServer } from 'node:http';
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { HttpError, validatePerson, validatePassword } from './validation.mjs';
const scrypt = promisify(scryptCallback);
export async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, 64);
  return `scrypt$${salt}$${key.toString('hex')}`;
}
export async function verifyPassword(password, hash) {
  const [algorithm, salt, encoded] = hash.split('$');
  if (algorithm !== 'scrypt' || !salt || !encoded) return false;
  const key = await scrypt(password, salt, 64), stored = Buffer.from(encoded, 'hex');
  return stored.length === key.length && timingSafeEqual(key, stored);
}
const professionalDto = row => ({ id: String(row.id_profissional), name: row.nome, email: row.email, cpf: row.cpf || '', phone: row.telefone || '' });
const patientDto = row => ({ id: String(row.id_paciente), name: row.nome, cpf: row.cpf, phone: row.telefone_responsavel, email: row.email_responsavel });
async function readBody(req) {
  let body = '';
  for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 16384) throw new HttpError(413, 'Dados muito grandes.'); }
  try { return JSON.parse(body || '{}'); } catch { throw new HttpError(400, 'JSON inválido.'); }
}
export function createApp(db, { origin = 'http://localhost:5173', secure = false } = {}) {
  const sessions = new Map(), attempts = new Map();
  const cleaner = setInterval(() => {
    const now = Date.now();
    for (const [key, value] of sessions) if (value.expires <= now) sessions.delete(key);
    for (const [key, value] of attempts) if (value.until <= now) attempts.delete(key);
  }, 60000); cleaner.unref();
  const server = createServer(async (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    function send(status, data) { res.writeHead(status); res.end(JSON.stringify(data)); }
    const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')));
    const cookie = token => `grafisense_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${token ? 28800 : 0}${secure ? '; Secure' : ''}`;
    function startSession(id) {
      if (cookies.grafisense_session) sessions.delete(cookies.grafisense_session);
      const token = randomBytes(32).toString('hex'); sessions.set(token, { id, expires: Date.now() + 28800000 });
      res.setHeader('Set-Cookie', cookie(token));
    }
    try {
      const path = new URL(req.url, 'http://localhost').pathname;
      if (!['GET', 'POST', 'PUT', 'DELETE'].includes(req.method)) throw new HttpError(405, 'Método não permitido.');
      if (req.method !== 'GET' && req.headers.origin && req.headers.origin !== origin) throw new HttpError(403, 'Origem não autorizada.');
      if (req.method !== 'GET' && req.headers['content-type']?.split(';')[0] !== 'application/json') throw new HttpError(415, 'Envie application/json.');
      if (path === '/api/health' && req.method === 'GET') { await db.query('SELECT 1'); return send(200, { ok: true }); }
      if (['/api/auth/register', '/api/auth/login'].includes(path) && req.method === 'POST') {
        const key = req.socket.remoteAddress, now = Date.now();
        const attempt = attempts.get(key);
        if (attempt && attempt.until > now && attempt.count >= 20) throw new HttpError(429, 'Muitas tentativas. Aguarde 15 minutos.');
        attempts.set(key, { count: attempt?.until > now ? attempt.count + 1 : 1, until: attempt?.until > now ? attempt.until : now + 900000 });
        const body = await readBody(req);
        if (path.endsWith('register')) {
          const person = validatePerson(body); validatePassword(body.password);
          const hash = await hashPassword(body.password);
          const [result] = await db.execute('INSERT INTO profissional (nome,email,senha_hash,cpf,telefone) VALUES (?,?,?,?,?)', [person.name,person.email,hash,person.cpf,person.phone]);
          startSession(String(result.insertId)); return send(201, { ...person, cpf: person.cpf || '', phone: person.phone || '', id: String(result.insertId) });
        }
        const email = String(body.email || '').trim().toLowerCase();
        if (typeof body.password !== 'string' || body.password.length > 128) throw new HttpError(401, 'E-mail ou senha incorretos.');
        const [rows] = await db.execute('SELECT * FROM profissional WHERE email = ?', [email]);
        // A derivação também acontece quando o e-mail não existe.
        const hash = rows[0]?.senha_hash || `scrypt$00000000000000000000000000000000$${'00'.repeat(64)}`;
        const valid = await verifyPassword(body.password, hash);
        if (!rows[0] || !valid) throw new HttpError(401, 'E-mail ou senha incorretos.');
        startSession(String(rows[0].id_profissional)); return send(200, professionalDto(rows[0]));
      }
      const session = sessions.get(cookies.grafisense_session);
      if (!session || session.expires <= Date.now()) throw new HttpError(401, 'Entre na sua conta para continuar.');
      const id = session.id;
      if (path === '/api/auth/logout' && req.method === 'POST') { sessions.delete(cookies.grafisense_session); res.setHeader('Set-Cookie', cookie('')); return send(200, { ok: true }); }
      if (path === '/api/auth/me' && req.method === 'GET') {
        const [rows] = await db.execute('SELECT * FROM profissional WHERE id_profissional = ?', [id]);
        if (!rows[0]) throw new HttpError(401, 'Conta não encontrada.'); return send(200, professionalDto(rows[0]));
      }
      if (path === '/api/professional' && req.method === 'PUT') {
        const body = await readBody(req), person = validatePerson(body);
        await db.execute('UPDATE profissional SET nome=?,email=?,cpf=?,telefone=? WHERE id_profissional=?', [person.name,person.email,person.cpf,person.phone,id]);
        return send(200, { ...person, cpf: person.cpf || '', phone: person.phone || '', id });
      }
      if (path === '/api/patients' && req.method === 'GET') {
        const [rows] = await db.execute('SELECT * FROM paciente WHERE id_profissional=? ORDER BY criado_em,id_paciente', [id]); return send(200, rows.map(patientDto));
      }
      if (path === '/api/patients' && req.method === 'POST') {
        const person = validatePerson(await readBody(req), true);
        const [result] = await db.execute('INSERT INTO paciente (nome,cpf,telefone_responsavel,email_responsavel,id_profissional) VALUES (?,?,?,?,?)', [person.name,person.cpf,person.phone,person.email,id]);
        return send(201, { ...person, id: String(result.insertId) });
      }
      throw new HttpError(404, 'Rota não encontrada.');
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') return send(409, { message: 'E-mail ou CPF já cadastrado. Para pacientes, o CPF deve ser único na sua conta.' });
      if (error instanceof HttpError) return send(error.status, { message: error.message, fields: error.fields });
      console.error('Falha na API:', error.code || error.name);
      send(503, { message: 'Não foi possível acessar o banco de dados. Confira a conexão e tente novamente.' });
    }
  });
  server.on('close', () => clearInterval(cleaner));
  return server;
}
