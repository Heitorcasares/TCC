import mysql from 'mysql2/promise';
import { createApp } from './app.mjs';
const pool = mysql.createPool({ host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER || 'grafisense_app', password: process.env.DB_PASSWORD, database: process.env.DB_NAME || 'grafisense', connectionLimit: 10, supportBigNumbers: true, bigNumberStrings: true });
const server = createApp(pool, { origin: process.env.APP_ORIGIN || 'http://localhost:5173', secure: process.env.NODE_ENV === 'production' });
server.listen(Number(process.env.PORT || 3001), process.env.API_HOST || '127.0.0.1', () => console.log('API GrafiSense disponível na porta ' + (process.env.PORT || 3001)));
async function stop() { server.close(async () => { await pool.end(); process.exit(0); }); }
process.on('SIGINT', stop); process.on('SIGTERM', stop);
