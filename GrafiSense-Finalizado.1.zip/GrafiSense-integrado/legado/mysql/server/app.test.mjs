import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from './app.mjs';
import { validatePerson, validCpf } from './validation.mjs';
function database() {
  const professionals = [], patients = [];
  return { professionals, patients, query: async () => [[{ 1: 1 }]], execute: async (sql, args) => {
    if (sql.startsWith('INSERT INTO profissional')) {
      const [nome,email,senha_hash,cpf,telefone] = args;
      if (professionals.some(p => p.email === email || (cpf && p.cpf === cpf))) throw Object.assign(new Error(), { code: 'ER_DUP_ENTRY' });
      professionals.push({ id_profissional: String(professionals.length + 1),nome,email,senha_hash,cpf,telefone }); return [{ insertId: professionals.length }];
    }
    if (sql.startsWith('SELECT * FROM profissional')) return [professionals.filter(p => sql.includes('WHERE email') ? p.email === args[0] : p.id_profissional === args[0])];
    if (sql.startsWith('UPDATE profissional')) {
      const p = professionals.find(p => p.id_profissional === args[4]);
      Object.assign(p, { nome: args[0],email: args[1],cpf: args[2],telefone: args[3] }); return [{ affectedRows: 1 }];
    }
    if (sql.startsWith('INSERT INTO paciente')) {
      const [nome,cpf,telefone_responsavel,email_responsavel,id_profissional] = args;
      if (patients.some(p => p.cpf === cpf && p.id_profissional === id_profissional)) throw Object.assign(new Error(), { code: 'ER_DUP_ENTRY' });
      patients.push({ id_paciente: String(patients.length + 1),nome,cpf,telefone_responsavel,email_responsavel,id_profissional }); return [{ insertId: patients.length }];
    }
    if (sql.startsWith('SELECT * FROM paciente')) return [patients.filter(p => p.id_profissional === args[0])];
    throw new Error('Consulta inesperada: ' + sql);
  } };
}
test('validação de CPF e campos obrigatórios', () => {
  assert.equal(validCpf('529.982.247-25'), true);
  for (const cpf of ['11111111111', '52998224726', '']) assert.equal(validCpf(cpf), false);
  assert.throws(() => validatePerson({ name: 'João', email: 'inválido' }, true));
  assert.doesNotThrow(() => validatePerson({ name: 'João Silva', email: 'joao@example.com' }));
});
test('cadastros, autenticação, isolamento e erros da API', async t => {
  const db = database(), app = createApp(db);
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => { app.close(resolve); app.closeAllConnections(); }));
  const base = `http://127.0.0.1:${app.address().port}`;
  async function call(path, method = 'GET', body, cookie = '', origin) {
    const response = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', Cookie: cookie, ...(origin ? { Origin: origin } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) });
    return { status: response.status, data: await response.json(), cookie: response.headers.get('set-cookie')?.split(';')[0] };
  }
  assert.equal((await call('/api/patients')).status, 401);
  assert.equal((await call('/api/auth/register', 'POST', { name:'João Silva', email:'joao@example.com', password:'123' })).status, 422);
  const first = await call('/api/auth/register', 'POST', { name:'João Silva', email:'JOAO@example.com', password:'senha12345' });
  assert.equal(first.status, 201); assert.equal(first.data.email, 'joao@example.com'); assert.ok(first.cookie);
  assert.equal(first.data.senha_hash, undefined); assert.ok(db.professionals[0].senha_hash.startsWith('scrypt$')); assert.ok(!db.professionals[0].senha_hash.includes('senha12345'));
  assert.equal((await call('/api/auth/register', 'POST', { name:'João Silva', email:'joao@example.com', password:'senha12345' })).status, 409);
  assert.equal((await call('/api/auth/me', 'GET', undefined, first.cookie)).data.id, first.data.id);
  const patient = { name:'Maria Silva', cpf:'529.982.247-25', phone:'(11) 99999-9999', email:'responsavel@example.com', id_profissional: '999' };
  const saved = await call('/api/patients', 'POST', patient, first.cookie);
  assert.equal(saved.status, 201); assert.equal(saved.data.cpf, '52998224725'); assert.equal(db.patients[0].id_profissional, first.data.id);
  assert.equal((await call('/api/patients', 'POST', patient, first.cookie)).status, 409);
  assert.equal((await call('/api/patients', 'POST', { ...patient, cpf: '11111111111' }, first.cookie)).status, 422);
  assert.equal((await call('/api/patients', 'POST', patient, first.cookie, 'https://evil.example')).status, 403);
  const second = await call('/api/auth/register', 'POST', { name:'Ana Silva', email:'ana@example.com', password:'senha54321' });
  assert.deepEqual((await call('/api/patients', 'GET', undefined, second.cookie)).data, []);
  assert.equal((await call('/api/patients', 'POST', patient, second.cookie)).status, 201);
  assert.equal((await call('/api/patients', 'GET', undefined, first.cookie)).data.length, 1);
  assert.equal((await call('/api/professional', 'PUT', { name:'João Santos',email:'joao@example.com' }, first.cookie)).data.name, 'João Santos');
  assert.equal((await call('/api/auth/logout', 'POST', {}, first.cookie)).status, 200);
  assert.equal((await call('/api/auth/me', 'GET', undefined, first.cookie)).status, 401);
  assert.equal((await call('/api/auth/login', 'POST', { email:'joao@example.com',password:'errada' })).status, 401);
  const login = await call('/api/auth/login', 'POST', { email:'joao@example.com',password:'senha12345' });
  assert.equal(login.status, 200);
  assert.equal((await call('/api/patients', 'GET', undefined, login.cookie)).data[0].name, 'Maria Silva');
});
