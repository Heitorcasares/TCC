export class HttpError extends Error {
  constructor(status, message, fields) { super(message); this.status = status; this.fields = fields; }
}
export const digits = value => String(value ?? '').replace(/\D/g, '');
export function validCpf(value) {
  const cpf = digits(value);
  if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;
  return [9, 10].every(n => {
    const sum = [...cpf.slice(0, n)].reduce((acc, d, i) => acc + Number(d) * (n + 1 - i), 0);
    return Number(cpf[n]) === (sum * 10 % 11) % 10;
  });
}
export function validatePerson(body, patient = false) {
  const name = String(body.name ?? '').trim();
  const email = String(body.email ?? '').trim().toLowerCase();
  const cpf = digits(body.cpf), phone = digits(body.phone);
  const fields = {};
  if (name.length > 150 || name.split(/\s+/).length < 2) fields.name = 'Informe o nome completo (até 150 caracteres).';
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) fields.email = 'Informe um e-mail válido.';
  if ((patient || cpf) && !validCpf(cpf)) fields.cpf = 'Informe um CPF válido.';
  if ((patient || phone) && ![10, 11].includes(phone.length)) fields.phone = 'Informe DDD e telefone.';
  if (Object.keys(fields).length) throw new HttpError(422, 'Confira os campos do cadastro.', fields);
  return { name, email, cpf: cpf || null, phone: phone || null };
}
export function validatePassword(password) {
  if (typeof password !== 'string' || password.length < 8 || password.length > 128)
    throw new HttpError(422, 'Confira a senha.', { password: 'Use uma senha de 8 a 128 caracteres.' });
}
