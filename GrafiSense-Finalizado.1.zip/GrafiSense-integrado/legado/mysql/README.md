# GrafiSense — front, API e MySQL

Integração dos cadastros com o SQL enviado, seguindo RF01–RF03 da documentação e mantendo o visual original.

## Funcionalidades integradas

- Profissional: nome completo, e-mail, senha e confirmação; CPF e telefone opcionais. Login, edição do próprio cadastro e logout.
- Paciente: nome completo, CPF, telefone e e-mail do responsável.
- Lista, busca e seleção dos pacientes vinculados ao profissional autenticado. Os cadastros são recuperados do MySQL ao reabrir a aplicação.
- Validação no front e na API, incluindo dígitos verificadores do CPF, senha de 8–128 caracteres e erros de duplicidade.
- Senhas protegidas com scrypt e salt aleatório; sessão em cookie HttpOnly/SameSite=Strict; vínculos dos pacientes definidos pela sessão, nunca pelo identificador enviado pelo navegador.

A introdução da documentação e RF01 diferem nos campos do profissional. Foram usados nome/e-mail/senha como obrigatórios (RF01), com CPF/telefone opcionais conforme as colunas do SQL. Pacientes seguem RF02, incluindo o e-mail do responsável.

## Abrir com menos trabalho na inicialização

A tela de cadastro inclui a seção **Crie sua senha de acesso**, com os campos Criar senha e Confirmar senha, botões para mostrar/ocultar cada senha e mensagens quando as senhas diferem ou não têm de 8 a 128 caracteres. Você pode conferir esses campos e suas validações sem iniciar a API. O cadastro da conta no banco exige o back-end. A senha fica apenas no estado temporário do formulário até o envio; não é gravada em localStorage ou sessionStorage. A confirmação é validada no front e não é enviada à API.

Este ZIP inclui a pasta `dist` já compilada. Para abrir a interface, extraia o ZIP inteiro e, dentro da pasta `GrafiSense-front`, execute:

```bash
npm run dev:leve
```

Abra http://localhost:5173. Para esse modo, basta o Node.js instalado: não é necessário executar `npm install`, `npm ci` ou `npm run build`. O comando equivalente é `node visualizar.mjs`. Ele serve os arquivos prontos e não executa a compilação do Vite nem monitora alterações no código.

O formulário abre mesmo sem o back-end. Entrar na conta e salvar cadastros continua exigindo a API e o MySQL. Enquanto o back-end definitivo está em desenvolvimento, a API incluída é provisória. Para usá-la, siga a configuração abaixo. Não há salvamento fictício ou local simulando o banco.

`npm run dev` continua disponível para editar o código com atualização automática. Alterações no código-fonte só aparecem no modo leve depois de gerar um novo `dist` com `npm run build`. Esse build pode ser feito em outro computador e copiado para cá. O modo leve encaminha `/api` para `127.0.0.1:3001` e deve ser acessado pelo endereço `localhost` acima para coincidir com `APP_ORIGIN`.

Um desligamento completo do computador precisa de investigação própria; essa alternativa reduz o trabalho de inicialização, mas não determina nem corrige a causa de uma falha do Windows ou do hardware.

## Como executar

Requisitos: Node.js 22.13+ e MySQL 8.0.16+ (preferencialmente 8.4).

1. Abra o terminal na pasta deste projeto e execute `npm ci`.
2. Copie `.env.example` para `.env` e configure host, usuário e senha do banco. No Windows, pode copiar pelo Explorador de Arquivos. Não publique `.env`.
3. Importe `database/schema.sql` pelo MySQL Workbench ou terminal:

   ```bash
   mysql -u root -p < database/schema.sql
   ```

   O SQL cria o banco `grafisense`. Importe uma única vez em banco vazio. Se já possui essas mesmas tabelas, use-as sem reimportar. O arquivo não é uma migração de tabelas existentes.
4. Crie um usuário para a aplicação, substituindo a senha:

   ```sql
   CREATE USER 'grafisense_app'@'localhost' IDENTIFIED BY 'SUA_SENHA_LOCAL';
   GRANT SELECT, INSERT, UPDATE ON grafisense.* TO 'grafisense_app'@'localhost';
   ```

   Coloque essa senha em `DB_PASSWORD` no `.env`. Para MySQL remoto, configure o host do usuário conforme o ambiente.
5. No primeiro terminal execute `npm run api`.
6. No segundo terminal execute `npm run dev` e abra http://localhost:5173.
7. Crie uma conta, cadastre um paciente e atualize a página para conferir a persistência. Para sair, abra “Meu cadastro” no topo e clique em “Sair da conta”.

O Vite encaminha `/api` para `127.0.0.1:3001`. Se alterar a porta da API, ajuste `vite.config.ts`. Execute os dois servidores; abrir apenas `index.html` não funciona.

### Banco com Docker (alternativa)

Acrescente `MYSQL_ROOT_PASSWORD=uma_senha_forte_diferente` ao `.env`, configure `DB_PASSWORD` e execute:

```bash
docker compose up -d db
```

O Docker cria o usuário e importa o SQL na primeira inicialização do volume. Aguarde o banco ficar saudável; não faça a importação manual nessa opção. O volume `mysql_data` preserva os dados. Removê-lo apaga o banco.

## Verificação

```bash
npm test
npm run typecheck
npm run build
```

Os testes da API usam banco simulado e verificam validação, criação, duplicidade, autenticação, edição, logout e isolamento dos pacientes. Não substituem um teste com seu servidor MySQL. A compilação e checagem TypeScript verificam o front.

## Rotas

| Método | Rota | Função |
| --- | --- | --- |
| POST | /api/auth/register | Cadastro e início de sessão |
| POST | /api/auth/login | Login |
| GET | /api/auth/me | Profissional autenticado |
| POST | /api/auth/logout | Logout |
| PUT | /api/professional | Edição do próprio cadastro |
| GET | /api/patients | Pacientes da conta |
| POST | /api/patients | Cadastro vinculado à conta |
| GET | /api/health | Verificação de conexão com o banco |

## Escopo e implantação

As tabelas de avaliações, resultados e a view de histórico foram mantidas no SQL. Processamento de vídeo/escrita, gravação de avaliações e resultados/histórico ainda são etapas do protótipo. Não há resultados fictícios. Recuperação e alteração de senha não estão implementadas.

As sessões duram oito horas e ficam na memória da API. Reiniciar a API exige novo login, mas preserva os cadastros do MySQL. Para múltiplas instâncias, use armazenamento compartilhado de sessões e de limite de tentativas.

Para produção, sirva o build e `/api` na mesma origem por HTTPS, defina `APP_ORIGIN` para essa origem e `NODE_ENV=production` para cookies Secure. Configure conexão e acesso ao MySQL, backups e regras de tratamento dos dados dos pacientes. O Vite está configurado para desenvolvimento, não para servir a aplicação em produção.
